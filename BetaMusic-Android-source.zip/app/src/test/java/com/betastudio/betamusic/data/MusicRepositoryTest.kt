package com.betastudio.betamusic.data

import org.junit.Assert.assertEquals
import org.junit.Test

class MusicRepositoryTest {
    @Test
    fun formatsDurationInMinutesAndSeconds() {
        assertEquals("0:00", MusicRepository.formatDuration(0L))
        assertEquals("1:05", MusicRepository.formatDuration(65_000L))
        assertEquals("12:34", MusicRepository.formatDuration(754_000L))
    }
}

package com.betastudio.betamusic.data

import android.net.Uri

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val contentUri: Uri,
    val artworkUri: Uri?
)

data class EqBandUi(
    val index: Int,
    val frequencyHz: Int,
    val gainDb: Float,
    val minDb: Float,
    val maxDb: Float
)

data class AudioFxUiState(
    val available: Boolean = false,
    val equalizerAvailable: Boolean = false,
    val bassBoostAvailable: Boolean = false,
    val spatialAvailable: Boolean = false,
    val loudnessAvailable: Boolean = false,
    val equalizerEnabled: Boolean = false,
    val bassBoostPercent: Float = 0f,
    val spatialPercent: Float = 0f,
    val loudnessPercent: Float = 0f,
    val bands: List<EqBandUi> = emptyList(),
    val message: String = "Reproduce una canción para activar los efectos de audio."
)

enum class AppTab(val label: String) {
    LISTEN("Escuchar"), LIBRARY("Biblioteca"), SEARCH("Buscar"), AUDIO("Audio")
}

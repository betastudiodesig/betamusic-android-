package com.betastudio.betamusic

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.betastudio.betamusic.audio.AudioFxManager
import com.betastudio.betamusic.data.AppTab
import com.betastudio.betamusic.data.MusicViewModel
import com.betastudio.betamusic.data.Song

private val CanvasBlack = Color(0xFF0B0B10)
private val SurfaceDark = Color(0xFF17151D)
private val WhiteMain = Color(0xFFF8F5FA)
private val WhiteMuted = Color(0xFFBEB9C7)
private val Rose = Color(0xFFF05D87)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.rgb(11, 11, 16)
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        setContent { BetaMusicApp() }
    }
}

@Composable
private fun BetaMusicApp(vm: MusicViewModel = viewModel()) {
    val context = LocalContext.current
    val songs by vm.songs.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val currentSong by vm.currentSong.collectAsStateWithLifecycle()
    val isPlaying by vm.isPlaying.collectAsStateWithLifecycle()
    val position by vm.position.collectAsStateWithLifecycle()
    val duration by vm.duration.collectAsStateWithLifecycle()
    val dominantColor by vm.dominantColor.collectAsStateWithLifecycle()
    val loading by vm.isLoading.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    var selectedTab by rememberSaveable { mutableStateOf(AppTab.LISTEN.name) }
    var hasPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, audioPermission()) == PackageManager.PERMISSION_GRANTED)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasPermission = granted
        if (granted) vm.loadLibrary()
    }

    LaunchedEffect(Unit) {
        if (hasPermission) vm.loadLibrary() else permissionLauncher.launch(audioPermission())
    }
    LaunchedEffect(vm) {
        while (true) {
            vm.refreshProgress()
            kotlinx.coroutines.delay(500)
        }
    }

    val dynamic = Color(dominantColor)
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        dynamic.copy(alpha = 0.50f),
                        Color(0xFF17111D),
                        CanvasBlack,
                        CanvasBlack
                    )
                )
            )
    ) {
        // A pair of low-cost radial washes creates a soft glass-like atmosphere without a live blur pass.
        Box(
            Modifier
                .fillMaxWidth()
                .height(420.dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(dynamic.copy(alpha = 0.20f), Color.Transparent),
                        radius = 720f
                    )
                )
        )
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (AppTab.valueOf(selectedTab)) {
                    AppTab.LISTEN -> ListenScreen(
                        songs = songs,
                        favorites = favorites,
                        currentSong = currentSong,
                        isPlaying = isPlaying,
                        loading = loading,
                        message = message,
                        onPlay = vm::playSong,
                        onTogglePlay = vm::togglePlayPause,
                        onNext = vm::next,
                        onPrevious = vm::previous,
                        onFavorite = vm::toggleFavorite,
                        onLibrary = { selectedTab = AppTab.LIBRARY.name },
                        onRetry = { if (hasPermission) vm.loadLibrary() else permissionLauncher.launch(audioPermission()) }
                    )
                    AppTab.LIBRARY -> LibraryScreen(
                        songs = songs,
                        favorites = favorites,
                        currentSong = currentSong,
                        loading = loading,
                        message = message,
                        onPlay = vm::playSong,
                        onFavorite = vm::toggleFavorite,
                        onRetry = { if (hasPermission) vm.loadLibrary() else permissionLauncher.launch(audioPermission()) }
                    )
                    AppTab.SEARCH -> SearchScreen(
                        songs = songs,
                        favorites = favorites,
                        currentSong = currentSong,
                        onPlay = vm::playSong,
                        onFavorite = vm::toggleFavorite
                    )
                    AppTab.AUDIO -> AudioScreen()
                }
            }

            if (currentSong != null) {
                MiniPlayer(
                    song = currentSong!!,
                    isPlaying = isPlaying,
                    positionMs = position,
                    durationMs = duration,
                    onToggle = vm::togglePlayPause,
                    onNext = vm::next,
                    onOpenAudio = { selectedTab = AppTab.AUDIO.name }
                )
            }
            BottomDock(selected = AppTab.valueOf(selectedTab), onSelect = { selectedTab = it.name })
        }
    }
}

private fun audioPermission(): String = if (Build.VERSION.SDK_INT >= 33) {
    Manifest.permission.READ_MEDIA_AUDIO
} else {
    Manifest.permission.READ_EXTERNAL_STORAGE
}

@Composable
private fun ListenScreen(
    songs: List<Song>, favorites: Set<String>, currentSong: Song?, isPlaying: Boolean,
    loading: Boolean, message: String, onPlay: (Song) -> Unit, onTogglePlay: () -> Unit,
    onNext: () -> Unit, onPrevious: () -> Unit, onFavorite: (Song) -> Unit,
    onLibrary: () -> Unit, onRetry: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp)
    ) {
        AppHeader()
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("TU MÚSICA, A TU MANERA", color = Rose, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.2.sp)
            Text("Buenas vibras.\nSonido en primer plano.", color = WhiteMain, fontSize = 29.sp, lineHeight = 34.sp, fontWeight = FontWeight.SemiBold)
            Text("Una experiencia personal, creada para tu colección.", color = WhiteMuted, fontSize = 13.sp)
        }

        FeaturedPlayer(
            song = currentSong,
            isPlaying = isPlaying,
            onToggle = { if (currentSong == null && songs.isNotEmpty()) onPlay(songs.first()) else onTogglePlay() },
            onNext = onNext,
            onPrevious = onPrevious,
            isFavorite = currentSong?.let { favorites.contains(it.id.toString()) } ?: false,
            onFavorite = { currentSong?.let(onFavorite) }
        )

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Tu biblioteca", color = WhiteMain, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
                Text(if (songs.isEmpty()) "Tu colección aparecerá aquí" else "${songs.size} canciones en el dispositivo", color = WhiteMuted, fontSize = 12.sp)
            }
            Text("Ver todo  ›", color = Rose, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clip(CircleShape).clickable(onClick = onLibrary).padding(9.dp))
        }

        when {
            loading -> GlassSurface(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Rounded.MusicNote, null, tint = Rose)
                    Text("Leyendo tu música…", color = WhiteMuted, fontSize = 13.sp)
                }
            }
            songs.isEmpty() -> GlassSurface(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Rounded.LibraryMusic, null, tint = Rose, modifier = Modifier.size(28.dp))
                    Text("Tu música empieza aquí", color = WhiteMain, fontWeight = FontWeight.SemiBold)
                    Text(message, color = WhiteMuted, fontSize = 12.sp, lineHeight = 18.sp)
                    Button(onClick = onRetry, colors = ButtonDefaults.buttonColors(containerColor = Rose, contentColor = Color.White)) {
                        Text("Volver a comprobar")
                    }
                }
            }
            else -> Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                songs.take(5).forEach { song ->
                    SongRow(
                        song = song,
                        isPlaying = currentSong?.id == song.id && isPlaying,
                        isFavorite = favorites.contains(song.id.toString()),
                        onClick = { onPlay(song) },
                        onFavorite = { onFavorite(song) }
                    )
                }
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun AppHeader() {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(39.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Rose, Color(0xFF9D5CFF)))),
            contentAlignment = Alignment.Center
        ) {
            Text("ß", fontSize = 28.sp, lineHeight = 30.sp, color = Color.White, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(0.dp)) {
            Text("ẞetaMusic", color = WhiteMain, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("PERSONAL AUDIO", color = WhiteMuted, fontSize = 8.sp, letterSpacing = 2.sp)
        }
        Box(Modifier.size(39.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.065f)).border(1.dp, Color.White.copy(alpha = 0.09f), CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Headphones, null, tint = WhiteMain, modifier = Modifier.size(19.dp))
        }
    }
}

@Composable
private fun FeaturedPlayer(
    song: Song?, isPlaying: Boolean, onToggle: () -> Unit, onNext: () -> Unit, onPrevious: () -> Unit,
    isFavorite: Boolean, onFavorite: () -> Unit
) {
    GlassSurface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(30.dp), tint = Color.White.copy(alpha = 0.065f)) {
        Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("AHORA SONANDO", color = Rose, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text(if (song == null) "El siguiente capítulo" else "Tu momento, tu sonido", color = WhiteMuted, fontSize = 11.sp)
                }
                Text("ARTWORK COLOR", color = WhiteMuted.copy(alpha = 0.76f), fontSize = 8.sp, letterSpacing = 1.sp,
                    modifier = Modifier.border(1.dp, Color.White.copy(alpha = 0.13f), CircleShape).padding(horizontal = 9.dp, vertical = 6.dp))
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Artwork(song, Modifier.size(126.dp), rounded = 22.dp)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(song?.title ?: "Elige una canción", color = WhiteMain, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 22.sp)
                    Text(song?.artist ?: "Toda tu colección en un solo lugar", color = WhiteMuted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("COLECCIÓN LOCAL", color = WhiteMuted.copy(alpha = 0.75f), fontSize = 8.sp, letterSpacing = 1.sp)
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                GlassIconButton(icon = { Icon(if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null, tint = if (isFavorite) Rose else WhiteMain) }, onClick = onFavorite, enabled = song != null)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    IconButton(onClick = onPrevious, modifier = Modifier.size(38.dp)) { Icon(Icons.Rounded.SkipPrevious, null, tint = WhiteMain, modifier = Modifier.size(25.dp)) }
                    Box(Modifier.size(52.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Rose, Color(0xFFB34FF0)))), contentAlignment = Alignment.Center) {
                        IconButton(onClick = onToggle, modifier = Modifier.fillMaxSize()) {
                            Icon(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(29.dp))
                        }
                    }
                    IconButton(onClick = onNext, modifier = Modifier.size(38.dp)) { Icon(Icons.Rounded.SkipNext, null, tint = WhiteMain, modifier = Modifier.size(25.dp)) }
                }
                Spacer(Modifier.width(6.dp))
            }
        }
    }
}

@Composable
private fun LibraryScreen(
    songs: List<Song>, favorites: Set<String>, currentSong: Song?, loading: Boolean, message: String,
    onPlay: (Song) -> Unit, onFavorite: (Song) -> Unit, onRetry: () -> Unit
) {
    var filter by rememberSaveable { mutableStateOf("Todas") }
    val filtered = if (filter == "Favoritas") songs.filter { favorites.contains(it.id.toString()) } else songs
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        AppHeader()
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("COLECCIÓN", color = Rose, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text("Biblioteca", color = WhiteMain, fontSize = 31.sp, fontWeight = FontWeight.SemiBold)
            Text("La música que guardas en tu teléfono.", color = WhiteMuted, fontSize = 13.sp)
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Todas", "Favoritas").forEach { chip ->
                val active = filter == chip
                Text(chip, color = if (active) Color.White else WhiteMuted, fontSize = 12.sp, fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                    modifier = Modifier.clip(CircleShape).background(if (active) Rose.copy(alpha = 0.9f) else Color.White.copy(alpha = 0.06f))
                        .border(1.dp, if (active) Rose else Color.White.copy(alpha = 0.08f), CircleShape)
                        .clickable { filter = chip }.padding(horizontal = 16.dp, vertical = 9.dp))
            }
            Text("${filtered.size} pistas", color = WhiteMuted, fontSize = 11.sp, modifier = Modifier.padding(start = 5.dp, top = 9.dp))
        }
        if (loading) {
            GlassSurface(Modifier.fillMaxWidth()) { Text("Leyendo música…", color = WhiteMuted, modifier = Modifier.padding(18.dp)) }
        } else if (filtered.isEmpty()) {
            GlassSurface(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (filter == "Favoritas") "Todavía no hay favoritas" else "No se encontraron canciones", color = WhiteMain, fontWeight = FontWeight.SemiBold)
                    Text(if (filter == "Favoritas") "Marca una canción con el corazón para guardarla aquí." else message, color = WhiteMuted, fontSize = 12.sp)
                    Button(onClick = onRetry) { Text("Actualizar biblioteca") }
                }
            }
        } else {
            filtered.forEach { song ->
                SongRow(song, currentSong?.id == song.id, favorites.contains(song.id.toString()), { onPlay(song) }, { onFavorite(song) })
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun SearchScreen(
    songs: List<Song>, favorites: Set<String>, currentSong: Song?, onPlay: (Song) -> Unit, onFavorite: (Song) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = remember(songs, query) {
        val q = query.trim().lowercase()
        if (q.isBlank()) emptyList() else songs.filter {
            it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) || it.album.lowercase().contains(q)
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        AppHeader()
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("ENCUENTRA TU SONIDO", color = Rose, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text("Buscar", color = WhiteMain, fontSize = 31.sp, fontWeight = FontWeight.SemiBold)
        }
        GlassSurface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Rounded.Search, null, tint = WhiteMuted)
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(color = WhiteMain, fontSize = 14.sp),
                    cursorBrush = Brush.verticalGradient(listOf(Rose, Color(0xFFB34FF0))),
                    modifier = Modifier.weight(1f),
                    decorationBox = { inner ->
                        Box {
                            if (query.isEmpty()) Text("Canción, artista o álbum", color = WhiteMuted.copy(alpha = 0.72f), fontSize = 14.sp)
                            inner()
                        }
                    }
                )
            }
        }
        if (query.isBlank()) {
            GlassSurface(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(13.dp)) {
                    Box(Modifier.size(45.dp).clip(RoundedCornerShape(14.dp)).background(Rose.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Search, null, tint = Rose)
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Tu colección completa", color = WhiteMain, fontWeight = FontWeight.SemiBold)
                        Text("Busca por título, artista o nombre del álbum.", color = WhiteMuted, fontSize = 12.sp, lineHeight = 17.sp)
                    }
                }
            }
        } else if (filtered.isEmpty()) {
            Text("No hay coincidencias para «$query».", color = WhiteMuted, fontSize = 13.sp, modifier = Modifier.padding(4.dp))
        } else {
            Text("${filtered.size} resultados", color = WhiteMuted, fontSize = 12.sp)
            filtered.forEach { song ->
                SongRow(song, currentSong?.id == song.id, favorites.contains(song.id.toString()), { onPlay(song) }, { onFavorite(song) })
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun AudioScreen() {
    val state by AudioFxManager.state.collectAsState()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(17.dp)) {
        AppHeader()
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("PERSONALIZA TU SONIDO", color = Rose, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text("Audio Studio", color = WhiteMain, fontSize = 31.sp, fontWeight = FontWeight.SemiBold)
            Text("Efectos nativos aplicados a la sesión del reproductor.", color = WhiteMuted, fontSize = 12.sp, lineHeight = 17.sp)
        }

        GlassSurface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(43.dp).clip(RoundedCornerShape(14.dp)).background(Rose.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.GraphicEq, null, tint = Rose, modifier = Modifier.size(23.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("Ecualizador", color = WhiteMain, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        Text(if (state.available && state.bands.isNotEmpty()) "${state.bands.size} bandas disponibles en este dispositivo" else "Depende de los efectos del sistema", color = WhiteMuted, fontSize = 11.sp)
                    }
                    Switch(checked = state.equalizerEnabled, onCheckedChange = AudioFxManager::setEqualizerEnabled, enabled = state.equalizerAvailable)
                }
                if (state.bands.isNotEmpty()) {
                    state.bands.forEach { band ->
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(formatFrequency(band.frequencyHz), color = WhiteMain, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                Text("${if (band.gainDb > 0) "+" else ""}${"%.1f".format(java.util.Locale.US, band.gainDb)} dB", color = WhiteMuted, fontSize = 10.sp)
                            }
                            Slider(
                                value = band.gainDb,
                                onValueChange = { AudioFxManager.setBandGain(band.index, it) },
                                valueRange = band.minDb..band.maxDb,
                                enabled = state.equalizerEnabled,
                                colors = sliderColors()
                            )
                        }
                    }
                } else {
                    Text(state.message, color = WhiteMuted, fontSize = 12.sp, lineHeight = 18.sp)
                }
            }
        }

        AudioEffectSlider(
            title = "Bass Boost", subtitle = "Refuerzo de graves", value = state.bassBoostPercent,
            enabled = state.bassBoostAvailable, onChange = AudioFxManager::setBassBoost
        )
        AudioEffectSlider(
            title = "Amplitud espacial", subtitle = "Efecto virtual estéreo compatible con el dispositivo", value = state.spatialPercent,
            enabled = state.spatialAvailable, onChange = AudioFxManager::setSpatial
        )
        AudioEffectSlider(
            title = "Aumento de salida", subtitle = "Ajusta la ganancia del sistema; empieza en cero", value = state.loudnessPercent,
            enabled = state.loudnessAvailable, onChange = AudioFxManager::setLoudness
        )
        Text(state.message, color = WhiteMuted.copy(alpha = 0.78f), fontSize = 10.sp, lineHeight = 15.sp, modifier = Modifier.padding(horizontal = 3.dp))
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun AudioEffectSlider(title: String, subtitle: String, value: Float, enabled: Boolean, onChange: (Float) -> Unit) {
    GlassSurface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 13.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(title, color = WhiteMain, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text(subtitle, color = WhiteMuted, fontSize = 10.sp, lineHeight = 14.sp)
                }
                Text("${value.toInt()}%", color = Rose, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
            Slider(value = value, onValueChange = onChange, valueRange = 0f..100f, enabled = enabled, colors = sliderColors())
        }
    }
}

@Composable
private fun SongRow(song: Song, isPlaying: Boolean, isFavorite: Boolean, onClick: () -> Unit, onFavorite: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
            .background(if (isPlaying) Color.White.copy(alpha = 0.085f) else Color.Transparent)
            .clickable(onClick = onClick).padding(vertical = 8.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Artwork(song, Modifier.size(52.dp), rounded = 14.dp)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(song.title, color = if (isPlaying) Rose else WhiteMain, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${song.artist} · ${song.album}", color = WhiteMuted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (isPlaying) {
            Icon(Icons.Rounded.GraphicEq, null, tint = Rose, modifier = Modifier.size(17.dp))
        }
        IconButton(onClick = onFavorite, modifier = Modifier.size(34.dp)) {
            Icon(if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null, tint = if (isFavorite) Rose else WhiteMuted, modifier = Modifier.size(17.dp))
        }
    }
}

@Composable
private fun Artwork(song: Song?, modifier: Modifier = Modifier, rounded: Dp = 18.dp) {
    Box(modifier.clip(RoundedCornerShape(rounded)).background(Brush.linearGradient(listOf(Color(0xFF55314A), Color(0xFF23213C)))), contentAlignment = Alignment.Center) {
        if (song?.artworkUri != null) {
            AsyncImage(model = song.artworkUri, contentDescription = "Carátula de ${song.title}", modifier = Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
        } else {
            Icon(Icons.Rounded.MusicNote, null, tint = Color.White.copy(alpha = 0.78f), modifier = Modifier.size(30.dp))
        }
    }
}

@Composable
private fun MiniPlayer(song: Song, isPlaying: Boolean, positionMs: Long, durationMs: Long, onToggle: () -> Unit, onNext: () -> Unit, onOpenAudio: () -> Unit) {
    Column(Modifier.padding(horizontal = 14.dp, vertical = 5.dp)) {
        GlassSurface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), tint = Color.White.copy(alpha = 0.105f)) {
            Row(Modifier.padding(start = 10.dp, end = 7.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Artwork(song, Modifier.size(42.dp), rounded = 12.dp)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(song.title, color = WhiteMain, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(song.artist, color = WhiteMuted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = onOpenAudio, modifier = Modifier.size(33.dp)) { Icon(Icons.Rounded.Tune, null, tint = WhiteMuted, modifier = Modifier.size(18.dp)) }
                IconButton(onClick = onToggle, modifier = Modifier.size(36.dp)) { Icon(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = WhiteMain, modifier = Modifier.size(23.dp)) }
                IconButton(onClick = onNext, modifier = Modifier.size(32.dp)) { Icon(Icons.Rounded.SkipNext, null, tint = WhiteMain, modifier = Modifier.size(20.dp)) }
            }
        }
        val progress = if (durationMs > 0) (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f
        Box(Modifier.fillMaxWidth().height(2.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.08f))) {
            Box(Modifier.fillMaxWidth(progress).height(2.dp).background(Brush.horizontalGradient(listOf(Rose, Color(0xFFB34FF0)))))
        }
    }
}

@Composable
private fun BottomDock(selected: AppTab, onSelect: (AppTab) -> Unit) {
    GlassSurface(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp).padding(bottom = 7.dp).navigationBarsPadding(),
        shape = RoundedCornerShape(25.dp), tint = Color(0xD917151D)
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 5.dp, vertical = 7.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            AppTab.values().forEach { tab ->
                val active = selected == tab
                val icon = when (tab) {
                    AppTab.LISTEN -> Icons.Rounded.Home
                    AppTab.LIBRARY -> Icons.Rounded.LibraryMusic
                    AppTab.SEARCH -> Icons.Rounded.Search
                    AppTab.AUDIO -> Icons.Rounded.GraphicEq
                }
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).clickable { onSelect(tab) }
                        .background(if (active) Rose.copy(alpha = 0.15f) else Color.Transparent).padding(vertical = 7.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Icon(icon, null, tint = if (active) Rose else WhiteMuted, modifier = Modifier.size(20.dp))
                    Text(tab.label, color = if (active) WhiteMain else WhiteMuted, fontSize = 9.sp, fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal)
                }
            }
        }
    }
}

@Composable
private fun GlassIconButton(icon: @Composable () -> Unit, onClick: () -> Unit, enabled: Boolean = true) {
    Box(
        Modifier.size(39.dp).clip(CircleShape)
            .background(Color.White.copy(alpha = if (enabled) 0.075f else 0.035f))
            .border(1.dp, Color.White.copy(alpha = 0.09f), CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { icon() }
}

@Composable
private fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(22.dp),
    tint: Color = Color.White.copy(alpha = 0.065f),
    content: @Composable () -> Unit
) {
    Box(
        modifier.clip(shape)
            .background(Brush.verticalGradient(listOf(tint, Color.White.copy(alpha = tint.alpha * 0.58f))))
            .border(BorderStroke(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.17f), Color.White.copy(alpha = 0.035f)))), shape)
    ) { content() }
}

@Composable
private fun sliderColors() = SliderDefaults.colors(
    thumbColor = Color.White,
    activeTrackColor = Rose,
    inactiveTrackColor = Color.White.copy(alpha = 0.15f),
    activeTickColor = Color.Transparent,
    inactiveTickColor = Color.Transparent,
    disabledThumbColor = WhiteMuted.copy(alpha = 0.5f),
    disabledActiveTrackColor = Rose.copy(alpha = 0.35f),
    disabledInactiveTrackColor = Color.White.copy(alpha = 0.08f)
)

private fun formatFrequency(hz: Int): String = when {
    hz >= 1000 -> "${"%.1f".format(java.util.Locale.US, hz / 1000f)} kHz"
    else -> "$hz Hz"
}

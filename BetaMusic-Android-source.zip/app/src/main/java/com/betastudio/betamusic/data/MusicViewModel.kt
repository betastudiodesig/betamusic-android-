package com.betastudio.betamusic.data

import android.app.Application
import android.content.ComponentName
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.palette.graphics.Palette
import com.betastudio.betamusic.audio.AudioFxManager
import com.betastudio.betamusic.playback.MusicPlaybackService
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MusicViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = MusicRepository(application)
    private val preferences = application.getSharedPreferences("beta_music_library", Application.MODE_PRIVATE)

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()
    private val _favorites = MutableStateFlow(preferences.getStringSet("favorites", emptySet())?.toSet() ?: emptySet())
    val favorites: StateFlow<Set<String>> = _favorites.asStateFlow()
    private val _currentSong = MutableStateFlow<Song?>(null)
    val currentSong: StateFlow<Song?> = _currentSong.asStateFlow()
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()
    private val _position = MutableStateFlow(0L)
    val position: StateFlow<Long> = _position.asStateFlow()
    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration.asStateFlow()
    private val _dominantColor = MutableStateFlow(0xFF493052.toInt())
    val dominantColor: StateFlow<Int> = _dominantColor.asStateFlow()
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()
    private val _message = MutableStateFlow("Permite el acceso a la música para cargar tu biblioteca.")
    val message: StateFlow<String> = _message.asStateFlow()

    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null

    private val playerListener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = syncFromPlayer()
        override fun onIsPlayingChanged(isPlaying: Boolean) { _isPlaying.value = isPlaying }
        override fun onPlaybackStateChanged(playbackState: Int) = syncFromPlayer()
        override fun onEvents(player: Player, events: Player.Events) = syncFromPlayer()
    }

    init {
        AudioFxManager.initialize(application)
        connectController()
    }

    private fun connectController() {
        val app = getApplication<Application>()
        val token = SessionToken(app, ComponentName(app, MusicPlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        controllerFuture = future
        future.addListener({
            runCatching { future.get() }.onSuccess { mediaController ->
                controller = mediaController
                mediaController.addListener(playerListener)
                syncFromPlayer()
            }
        }, ContextCompat.getMainExecutor(app))
    }

    fun loadLibrary() {
        viewModelScope.launch {
            _isLoading.value = true
            val result = runCatching { withContext(Dispatchers.IO) { repository.loadSongs() } }
            result.onSuccess { list ->
                _songs.value = list
                _message.value = if (list.isEmpty()) {
                    "No se encontraron canciones locales. Comprueba que haya archivos de audio en el teléfono."
                } else {
                    "${list.size} canciones disponibles en tu biblioteca."
                }
                syncFromPlayer()
            }.onFailure {
                _message.value = "No se pudo leer la biblioteca. Comprueba el permiso de audio y vuelve a intentarlo."
            }
            _isLoading.value = false
        }
    }

    fun playSong(song: Song) {
        val player = controller ?: run {
            _message.value = "El reproductor se está iniciando. Vuelve a tocar la canción en un instante."
            return
        }
        val list = _songs.value
        val index = list.indexOfFirst { it.id == song.id }
        if (index < 0) return
        val items = list.map { item ->
            MediaItem.Builder()
                .setMediaId(item.id.toString())
                .setUri(item.contentUri)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(item.title)
                        .setArtist(item.artist)
                        .setAlbumTitle(item.album)
                        .setArtworkUri(item.artworkUri)
                        .build()
                )
                .build()
        }
        runCatching {
            player.setMediaItems(items, index, 0L)
            player.prepare()
            player.play()
            _currentSong.value = song
            updateDominantColor(song.artworkUri)
            syncFromPlayer()
        }.onFailure {
            _message.value = "No se pudo reproducir esta canción. Puede que el archivo ya no esté disponible."
        }
    }

    fun togglePlayPause() {
        val player = controller ?: return
        if (player.isPlaying) player.pause() else {
            if (player.mediaItemCount == 0 && _songs.value.isNotEmpty()) playSong(_songs.value.first())
            else player.play()
        }
        _isPlaying.value = player.isPlaying
    }

    fun next() { controller?.seekToNextMediaItem() }
    fun previous() {
        val player = controller ?: return
        if (player.currentPosition > 3500L) player.seekTo(0L) else player.seekToPreviousMediaItem()
    }
    fun seekTo(positionMs: Long) { controller?.seekTo(positionMs.coerceAtLeast(0L)) }

    fun refreshProgress() {
        controller?.let { player ->
            _position.value = player.currentPosition.coerceAtLeast(0L)
            _duration.value = player.duration.takeIf { it != C.TIME_UNSET && it > 0L } ?: (_currentSong.value?.durationMs ?: 0L)
            _isPlaying.value = player.isPlaying
        }
    }

    fun toggleFavorite(song: Song) {
        val id = song.id.toString()
        val updated = _favorites.value.toMutableSet()
        if (!updated.add(id)) updated.remove(id)
        _favorites.value = updated
        preferences.edit().putStringSet("favorites", updated.toSet()).apply()
    }

    fun isFavorite(song: Song): Boolean = _favorites.value.contains(song.id.toString())

    private fun syncFromPlayer() {
        val player = controller ?: return
        val id = player.currentMediaItem?.mediaId?.toLongOrNull()
        val found = _songs.value.firstOrNull { it.id == id }
        if (found != null && _currentSong.value?.id != found.id) {
            _currentSong.value = found
            updateDominantColor(found.artworkUri)
        }
        _isPlaying.value = player.isPlaying
        _position.value = player.currentPosition.coerceAtLeast(0L)
        _duration.value = player.duration.takeIf { it != C.TIME_UNSET && it > 0L } ?: (_currentSong.value?.durationMs ?: 0L)
    }

    private fun updateDominantColor(uri: Uri?) {
        if (uri == null) {
            _dominantColor.value = 0xFF493052.toInt()
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val color = runCatching {
                val bitmap = getApplication<Application>().contentResolver.openInputStream(uri)?.use { stream ->
                    val options = BitmapFactory.Options().apply { inSampleSize = 4 }
                    BitmapFactory.decodeStream(stream, null, options)
                }
                if (bitmap != null) {
                    val palette = Palette.from(bitmap).generate()
                    val result = palette.darkVibrantSwatch?.rgb
                        ?: palette.vibrantSwatch?.rgb
                        ?: palette.dominantSwatch?.rgb
                        ?: 0xFF493052.toInt()
                    bitmap.recycle()
                    result
                } else 0xFF493052.toInt()
            }.getOrDefault(0xFF493052.toInt())
            _dominantColor.value = color
        }
    }

    override fun onCleared() {
        controller?.removeListener(playerListener)
        controllerFuture?.let { runCatching { MediaController.releaseFuture(it) } }
        controller = null
        super.onCleared()
    }
}

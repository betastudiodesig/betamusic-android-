package com.betastudio.betamusic.audio

import android.content.Context
import android.content.SharedPreferences
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import com.betastudio.betamusic.data.AudioFxUiState
import com.betastudio.betamusic.data.EqBandUi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.roundToInt

/**
 * Uses the Android audio effects attached to Media3's current audio session.
 * Capabilities vary by phone/ROM, so the UI always reports what is actually available.
 */
object AudioFxManager {
    private var prefs: SharedPreferences? = null
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var activeSessionId: Int = 0

    private val _state = MutableStateFlow(AudioFxUiState())
    val state: StateFlow<AudioFxUiState> = _state.asStateFlow()

    fun initialize(context: Context) {
        if (prefs != null) return
        prefs = context.applicationContext.getSharedPreferences("beta_audio_fx", Context.MODE_PRIVATE)
        val saved = prefs!!
        _state.value = AudioFxUiState(
            equalizerEnabled = saved.getBoolean("eq_enabled", false),
            bassBoostPercent = saved.getInt("bass", 0).toFloat(),
            spatialPercent = saved.getInt("spatial", 0).toFloat(),
            loudnessPercent = saved.getInt("loudness", 0).toFloat(),
            message = "Inicia una canción para conectar los controles de audio."
        )
    }

    @Synchronized
    fun attach(sessionId: Int) {
        if (sessionId <= 0 || sessionId == activeSessionId) return
        releaseEffects()
        activeSessionId = sessionId

        equalizer = runCatching { Equalizer(0, sessionId) }.getOrNull()
        bassBoost = runCatching { BassBoost(0, sessionId) }.getOrNull()
        virtualizer = runCatching { Virtualizer(0, sessionId) }.getOrNull()
        loudnessEnhancer = runCatching { LoudnessEnhancer(sessionId) }.getOrNull()

        val currentPrefs = prefs
        val bandList = mutableListOf<EqBandUi>()
        val eq = equalizer
        if (eq != null) {
            runCatching {
                val limits = eq.bandLevelRange
                val savedLevels = currentPrefs?.getString("band_levels", null)
                    ?.split(",")?.mapNotNull { it.toFloatOrNull() }
                val count = eq.numberOfBands.toInt()
                for (index in 0 until count) {
                    val freqHz = (eq.getCenterFreq(index.toShort()) / 1000).coerceAtLeast(1)
                    val minDb = limits[0].toFloat() / 100f
                    val maxDb = limits[1].toFloat() / 100f
                    val requested = savedLevels?.getOrNull(index) ?: eq.getBandLevel(index.toShort()).toFloat() / 100f
                    val clamped = requested.coerceIn(minDb, maxDb)
                    eq.setBandLevel(index.toShort(), (clamped * 100f).roundToInt().toShort())
                    bandList += EqBandUi(index, freqHz, clamped, minDb, maxDb)
                }
                eq.enabled = currentPrefs?.getBoolean("eq_enabled", false) ?: false
            }
        }

        runCatching {
            bassBoost?.let { effect ->
                effect.setStrength(((currentPrefs?.getInt("bass", 0) ?: 0) * 10).coerceIn(0, 1000).toShort())
                effect.enabled = (currentPrefs?.getInt("bass", 0) ?: 0) > 0
            }
        }
        runCatching {
            virtualizer?.let { effect ->
                effect.setStrength(((currentPrefs?.getInt("spatial", 0) ?: 0) * 10).coerceIn(0, 1000).toShort())
                effect.enabled = (currentPrefs?.getInt("spatial", 0) ?: 0) > 0
            }
        }
        runCatching {
            loudnessEnhancer?.let { effect ->
                effect.setTargetGain(((currentPrefs?.getInt("loudness", 0) ?: 0) * 6).coerceIn(0, 600))
                effect.enabled = (currentPrefs?.getInt("loudness", 0) ?: 0) > 0
            }
        }

        val available = equalizer != null || bassBoost != null || virtualizer != null || loudnessEnhancer != null
        _state.value = _state.value.copy(
            available = available,
            equalizerAvailable = equalizer != null && bandList.isNotEmpty(),
            bassBoostAvailable = bassBoost != null,
            spatialAvailable = virtualizer != null,
            loudnessAvailable = loudnessEnhancer != null,
            equalizerEnabled = runCatching { equalizer?.enabled ?: false }.getOrDefault(false),
            bands = bandList,
            message = if (available) {
                "Efectos disponibles para la sesión de audio actual. Las opciones dependen del dispositivo."
            } else {
                "Este dispositivo no expone efectos de audio compatibles para la sesión actual."
            }
        )
    }

    @Synchronized
    fun setEqualizerEnabled(enabled: Boolean) {
        runCatching { equalizer?.enabled = enabled }
        prefs?.edit()?.putBoolean("eq_enabled", enabled)?.apply()
        _state.value = _state.value.copy(equalizerEnabled = enabled)
    }

    @Synchronized
    fun setBandGain(index: Int, gainDb: Float) {
        val current = _state.value.bands.getOrNull(index) ?: return
        val value = gainDb.coerceIn(current.minDb, current.maxDb)
        runCatching { equalizer?.setBandLevel(index.toShort(), (value * 100f).roundToInt().toShort()) }
        val updated = _state.value.bands.map { if (it.index == index) it.copy(gainDb = value) else it }
        _state.value = _state.value.copy(bands = updated)
        prefs?.edit()?.putString("band_levels", updated.joinToString(",") { it.gainDb.toString() })?.apply()
    }

    @Synchronized
    fun setBassBoost(percent: Float) {
        val value = percent.coerceIn(0f, 100f)
        runCatching {
            bassBoost?.let {
                it.setStrength((value * 10f).roundToInt().coerceIn(0, 1000).toShort())
                it.enabled = value > 0f
            }
        }
        prefs?.edit()?.putInt("bass", value.roundToInt())?.apply()
        _state.value = _state.value.copy(bassBoostPercent = value)
    }

    @Synchronized
    fun setSpatial(percent: Float) {
        val value = percent.coerceIn(0f, 100f)
        runCatching {
            virtualizer?.let {
                it.setStrength((value * 10f).roundToInt().coerceIn(0, 1000).toShort())
                it.enabled = value > 0f
            }
        }
        prefs?.edit()?.putInt("spatial", value.roundToInt())?.apply()
        _state.value = _state.value.copy(spatialPercent = value)
    }

    @Synchronized
    fun setLoudness(percent: Float) {
        val value = percent.coerceIn(0f, 100f)
        runCatching {
            loudnessEnhancer?.let {
                it.setTargetGain((value * 6f).roundToInt().coerceIn(0, 600))
                it.enabled = value > 0f
            }
        }
        prefs?.edit()?.putInt("loudness", value.roundToInt())?.apply()
        _state.value = _state.value.copy(loudnessPercent = value)
    }

    @Synchronized
    fun release() {
        releaseEffects()
        _state.value = _state.value.copy(
            available = false,
            equalizerAvailable = false,
            bassBoostAvailable = false,
            spatialAvailable = false,
            loudnessAvailable = false,
            bands = emptyList(),
            message = "Los controles de audio se conectarán cuando comience la reproducción."
        )
    }

    private fun releaseEffects() {
        activeSessionId = 0
        runCatching { equalizer?.release() }
        runCatching { bassBoost?.release() }
        runCatching { virtualizer?.release() }
        runCatching { loudnessEnhancer?.release() }
        equalizer = null
        bassBoost = null
        virtualizer = null
        loudnessEnhancer = null
    }
}

# Lista de pruebas para la primera APK

Esta lista debe completarse después de que GitHub Actions genere el APK y se instale en el Samsung. No se marca como superada antes de ejecutarla en un dispositivo real.

- [ ] La aplicación solicita permiso de audio y muestra la biblioteca local.
- [ ] Tocar una canción inicia la reproducción y actualiza título, artista y carátula.
- [ ] Cambiar de canción también cambia el color ambiental del fondo.
- [ ] La reproducción continúa al poner la aplicación en segundo plano.
- [ ] Los controles multimedia del sistema cambian pista y pausan/reanudan.
- [ ] El buscador encuentra títulos, artistas y álbumes.
- [ ] Los favoritos permanecen después de cerrar y volver a abrir la aplicación.
- [ ] Los efectos de audio se activan solo si el dispositivo los admite; las opciones no disponibles aparecen deshabilitadas.
- [ ] La interfaz no se traba al recorrer una biblioteca grande.
- [ ] No se producen fallos, cortes de audio ni consumo de memoria anormal.

Si alguno falla, conserva el ZIP original y reporta qué paso ocurrió, el mensaje de error y el modelo/versión de Android. No reemplaces la instalación estable de Windows: este es un proyecto Android separado.

# ẞetaMusic Android — Glass Edition (Alpha)

Proyecto Android nativo separado de la aplicación de Windows. Interfaz original de ẞetaMusic con inspiración visual en los reproductores premium: fondo que toma su tono de la carátula, superficies translúcidas ligeras, esquinas suaves y navegación táctil. No copia recursos ni marcas gráficas de Apple Music.

## Estado de esta entrega

Incluye una primera base instalable con:

- Biblioteca local mediante MediaStore y permiso de audio de Android.
- Reproducción con AndroidX Media3 / ExoPlayer y `MediaSessionService` para reproducción en segundo plano y controles del sistema.
- Título, artista, álbum, duración y carátula de los archivos que exponga MediaStore.
- Buscador por canción, artista y álbum.
- Favoritos guardados localmente.
- Minirreproductor con reproducción/pausa y saltos de pista.
- Fondo tonal que cambia con la carátula. La extracción del color se hace en segundo plano.
- Pantalla Audio Studio que intenta conectarse a los efectos nativos de la sesión: ecualizador, Bass Boost, virtualizador estéreo y compensación de nivel. La cantidad de bandas y la disponibilidad real dependen del hardware y del software del teléfono; la app muestra el estado y no inventa controles cuando el efecto no existe.
- Superficies tipo glass ligeras: transparencia y gradientes sin desenfoque de pantalla constante, para no cargar innecesariamente el Galaxy A07.
- GitHub Actions para compilar el APK de depuración en la nube.

Esta es una versión alfa funcional en desarrollo, no una declaración de que todas las funciones avanzadas de la versión Windows ya se hayan portado. Las listas de reproducción editables, escaneo de carpetas, edición de etiquetas, motor DSP propio de 10/20 bandas, crossfade y una suite de efectos independiente todavía requieren etapas posteriores.

## Cómo compilar automáticamente desde GitHub

### Opción recomendada si solo tienes el teléfono

1. Extrae el archivo ZIP en el teléfono para poder acceder a su contenido.
2. En GitHub crea un repositorio nuevo llamado `betamusic-android`. Puedes hacerlo privado durante las pruebas.
3. En el repositorio, crea el archivo `.github/workflows/android-apk.yml` con el contenido del archivo homónimo de este proyecto. GitHub permite crearlo con **Add file → Create new file**; escribe la ruta completa en el nombre.
4. Sube los archivos del proyecto a la raíz del repositorio (deben quedar `settings.gradle.kts`, `build.gradle.kts`, `app/` y `gradle.properties` en la raíz). No subas la carpeta contenedora externa del ZIP.
5. Abre la pestaña **Actions** y selecciona **Build ẞetaMusic Android APK**. Si no se ejecutó al subir los archivos, usa **Run workflow**.
6. Cuando termine en verde, abre esa ejecución, baja hasta **Artifacts** y descarga `betamusic-android-debug-apk`.
7. Extrae ese ZIP en el teléfono y toca `app-debug.apk` para instalarlo. Android puede pedir que autorices la instalación desde el navegador o gestor de archivos que utilices.

La primera compilación necesita conexión a Internet para descargar Gradle, el Android SDK y las bibliotecas. GitHub Actions realiza el trabajo pesado en la nube; el teléfono no compila el proyecto.

### Compilación local (opcional)

Con JDK 17, Android SDK API 36 y Gradle 8.13 instalados, desde la raíz del proyecto:

```bash
gradle testDebugUnitTest assembleDebug
```

El APK de depuración queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Requisitos y limitaciones

- Android 8.0 (API 26) o posterior.
- La primera apertura solicita permiso para leer audio local.
- Las canciones deben estar indexadas por MediaStore. Algunos archivos de carpetas protegidas o proveedores externos pueden no aparecer.
- Los efectos de `android.media.audiofx` dependen del fabricante, de la versión de Android y de la ruta de salida. En algunos dispositivos pueden no estar disponibles o no afectar a todos los auriculares.
- La interfaz utiliza el color dominante de la portada, no un filtro de desenfoque continuo. Esto consigue el estilo ambiental dinámico con menor coste de GPU.
- El arte de portada se carga solo como imagen de interfaz. No se alteran los archivos musicales originales.
- El identificador del paquete de prueba es `com.betastudio.betamusic.debug`; la app estable de Windows no se modifica.

## Estructura

```text
BetaMusic-Android/
├── .github/workflows/android-apk.yml
├── app/
│   └── src/main/
│       ├── AndroidManifest.xml
│       └── java/com/betastudio/betamusic/
├── build.gradle.kts
├── gradle.properties
└── settings.gradle.kts
```

## Versiones principales

- Kotlin 2.2.20
- Android Gradle Plugin 8.13.2
- Gradle 8.13 (instalado por el workflow)
- AndroidX Media3 1.10.1
- Jetpack Compose BOM 2025.12.00
- Java 17

La compilación debe confirmarse en la primera ejecución de GitHub Actions. Este entorno de preparación no dispone de Android SDK ni acceso de red para ejecutar la compilación Android completa.

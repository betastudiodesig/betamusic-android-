# Auditoría y plan aplicado — ẞetaMusic Android 3.0.0

Fecha: 26 de octubre de 2026

## Objetivo

Reorganizar ẞetaMusic como un reproductor local de uso directo y navegación por categorías, inspirado en Samsung Music y en la estética reportada para el reproductor del sistema de One UI 9, sin perder el motor de reproducción del proyecto nativo existente.

## Hallazgos iniciales

1. El proyecto es Kotlin + Jetpack Compose + AndroidX Media3; `PlaybackService.kt` ya contiene `ExoPlayer` y `MediaSession`.
2. `MainActivity.kt` concentraba navegación, pantallas, listas y controles en un solo archivo. Para reducir riesgo en este cambio se preservó la arquitectura existente; una extracción posterior a componentes separados debe hacerse con pruebas.
3. El archivo `REFERENCIA-INTERFAZ.jpg` mostraba un concepto llamado Amplify y no una captura fiable de Samsung Music. Se retiró para no tratarlo como referencia de Samsung.
4. El fallo reportado en GitHub (`LibraryTabs` sin resolver) correspondía a un estado distinto al ZIP Fix1, donde el componente sí está definido. Ese error debe volver a comprobarse con el ZIP actual cargado al repositorio.
5. El workflow de GitHub del repositorio actual esperaba en la raíz un ZIP denominado `BetaMusic-Android-Fase2-Completo.zip`; cuando falta, la acción falla antes de compilar. El proyecto no puede compilar si el repositorio solo contiene el workflow y no contiene ni fuentes ni el ZIP esperado.

## Cambios principales incluidos en este paquete

### Biblioteca
- Navegación superior por categorías: Listas, Canciones, Álbumes, Artistas, Géneros, Compositores, Carpetas, Favoritos y Descargas.
- Orden visual neutro negro/grises, acento azul configurable y menos decoración neón.
- Búsqueda por canción, artista o álbum.
- Acciones por canción: reproducir a continuación, añadir a lista y administrar favorito.
- Lectura de género y compositor desde MediaStore cuando esos metadatos están registrados.
- Descargas muestra un estado vacío cuando no encuentra música en una carpeta de descargas, en vez de repetir incorrectamente toda la biblioteca.

### Reproducción
- Se conserva Media3 y el servicio de reproducción en segundo plano.
- El reproductor usa controles más compactos, portada grande y esquinas menos exageradas.
- El color dominante de la portada puede teñir los controles y la barra de progreso.
- Se conserva doble toque para reproducir/pausar y deslizamiento horizontal para avanzar/retroceder, con transición animada de portada.
- La barra de progreso presenta barras estilizadas tipo onda, inspiradas visualmente en One UI 9; no representan datos reales del audio.
- El reproductor expone título, artista, álbum y URI de portada a MediaSession para que Android/One UI tenga metadatos suficientes en los controles del sistema.
- El fondo desenfocado queda desactivado por defecto por coste visual/perfomance y puede activarse en Apariencia.

### Cola y listas
- Se añadió la acción real `Reproducir a continuación`, que inserta una pista justo detrás de la actual.
- Cola reordenable con pulsación larga y arrastre mientras el aleatorio está desactivado.
- Añadir una canción a una lista desde el reproductor o el menú contextual de cada pista; se puede elegir una lista existente o crear una que incluya esa canción.
- Se conservan las listas en preferencias locales.

### Apariencia y navegación
- El tema se basa en negro AMOLED con superficies grises y azul One UI como acento por defecto.
- Las secciones se abren desde el menú superior; la biblioteca es el destino inicial.
- Los ajustes se agrupan bajo «Apariencia» y conservan las preferencias persistentes.

## Aún pendiente de verificación funcional

- Compilar `assembleDebug` con Android SDK instalado.
- Instalar el APK y revisar en un Galaxy A07 el tamaño de las portadas, recortes, tipografía, controles y gestos.
- Probar permisos en Android 13+ y Android 12 o anterior.
- Probar la lectura de géneros en versiones distintas de MediaStore; si el proveedor no expone géneros, la pestaña mostrará «Género desconocido».
- Probar reordenamiento real de la cola, incluyendo la cola en modo aleatorio y repetición.
- Confirmar que la notificación/lockscreen muestra la carátula completa y controles correctos.
- Medir rendimiento en bibliotecas grandes y comprobar que el difuminado opcional no se activa de forma accidental.

No se declara ninguna de estas verificaciones como completada hasta ejecutar la app o una compilación real.

## Referencias consultadas

- Samsung Music en Google Play (Samsung Electronics): https://play.google.com/store/apps/details?id=com.sec.android.app.music
  - Describe reproducción local y categorías por pista, álbum, artista, género, carpeta y compositor.
- Página de soporte oficial Samsung Music: https://www.samsung.com/us/support/owners/app/samsung-music
- SamMobile, reporte sobre el reproductor del sistema en One UI 9: https://www.sammobile.com/news/one-ui-9-lock-screen-media-player-widget/
- Android Authority, información sobre el reproductor dinámico de One UI 9 (4 de mayo de 2026): https://www.androidauthority.com/samsung-one-ui-9-media-player-redesign-3663128/

Las noticias de One UI 9 informan principalmente sobre la interfaz del sistema (pantalla de bloqueo/panel rápido). Se tratan como referencia visual reportada, no como contrato de API para que una aplicación fuerce el aspecto del sistema.

# ẞetaMusic Android 3.0.3 — Biblioteca, letras y cristal

Esta revisión parte del proyecto 3.0.2 Stability Fix. Los cambios se mantienen en el proyecto Android nativo Kotlin/Compose/Media3; no se han copiado pantallas ni código de una versión 2.x.

## Cambios implementados

- Persistencia de la cola, canción actual, posición, repetición y aleatorio. La sesión se restaura en pausa para no iniciar sonido inesperadamente; el usuario puede continuar con Reproducir.
- Navegación entre categorías basada en `HorizontalPager`, por lo que el contenido de la biblioteca sigue el gesto mientras se desliza. El indicador/etiqueta cambia al desplazarse entre páginas.
- Vista de letras desde la portada del reproductor con toque simple y doble toque para reproducción/pausa. Lee archivos `.lrc` sincronizados o `.txt` locales, permite seleccionar un archivo y buscar letras en línea a petición del usuario mediante LRCLIB; los resultados se guardan localmente por canción para evitar consultas repetidas.
- Estado de desplazamiento conservado por separado para las vistas de lista y cuadrícula de Canciones, además de estados propios de búsqueda, favoritos y descargas.
- Menús de canciones con reproducir después, añadir a lista, favoritos, ir al álbum, ver artista y editar metadatos.
- Portadas de listas de reproducción personalizadas, persistentes y visibles en la vista de detalle encima de sus canciones.
- Ajustes de lista/cuadrícula para canciones, álbumes, listas y favoritos.
- Índice alfabético lateral en la vista de lista cuando hay al menos 24 canciones.
- Mejoras de carga y caché de portadas con tamaños separados para miniaturas, cuadrícula y reproductor (hasta 1024 px).
- Barra de progreso dibujada como forma de onda con búsqueda táctil.
- Ajuste Liquid Glass con superficies translúcidas y brillos en tarjetas, controles, menús, ajustes y cola; el ajuste permite volver al estilo sólido.
- Botones de reproducción actualizados y animación de escala/rotación para aleatorio y repetir.
- Título y artista centrados opcionalmente.
- Acceso a Configuración mediante engranaje; la cabecera no muestra acceso a Perfil.
- La portada del reproductor se desplaza junto con el gesto y muestra parcialmente la portada anterior o siguiente durante el arrastre.
- Tirador inferior que abre la cola en una hoja emergente y permite reordenarla arrastrando en tiempo real.
- Toque en la portada de una canción de la biblioteca para abrir su álbum.
- Guardado periódico del estado de reproducción limitado a cambios de segundo (en lugar de escribir en preferencias cada 100 ms).

## Límites conocidos

- La búsqueda de letras en línea es opcional y se inicia al pulsar el botón; utiliza el endpoint público `https://lrclib.net/api/get` y requiere conexión a Internet. Se prefiere la letra sincronizada y se usa la letra simple como alternativa. El resultado positivo se guarda por canción; no se hacen búsquedas en segundo plano ni de forma automática al entrar a cada canción.
- La edición actual solicita permiso de escritura de Android y actualiza los campos de MediaStore (título, artista y álbum). No reescribe de forma genérica los bloques ID3/Vorbis dentro de cada archivo de audio.
- La opción de transición aplica fundido de volumen al final/inicio de pistas. **No es un crossfade real con dos canciones sonando simultáneamente**.
- Liquid Glass usa superficies translúcidas y reflejos; no aplica desenfoque pesado detrás de todos los elementos, para evitar castigar el rendimiento.

## Verificación de esta entrega

Se comprobaron la integridad del proyecto fuente, el balance sintáctico de delimitadores Kotlin, las rutas de las funciones principales y la integridad del ZIP final. En este entorno no están disponibles Android SDK ni Gradle y no hay acceso de red para instalarlos, por lo que no se pudo ejecutar una compilación Android completa ni una prueba en dispositivo. La ausencia de errores de sintaxis detectados no equivale a una compilación confirmada.

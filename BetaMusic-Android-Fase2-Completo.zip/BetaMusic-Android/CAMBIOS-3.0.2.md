# ẞetaMusic Android 3.0.1 — cambios sobre la base 3.0.0

Esta entrega se preparó directamente a partir de `BetaMusic-Android-3.0.0-OneUI9.zip`.

## Cambios de interfaz y uso

1. Deslizar hacia izquierda o derecha sobre el contenido de la biblioteca cambia entre pestañas visibles con una transición lateral suave.
2. Se reforzó la lectura de carátulas: se consulta primero el proveedor de portadas de álbum y se usa la miniatura del audio como alternativa. El color extraído se aplica al reproductor y al acento global de la app mientras hay una pista activa.
3. Se retiró el botón de tres puntos de la cabecera del reproductor; la cola sigue accesible desde la acción inferior «Cola».
4. La cola reordena al cruzar cada fila durante el arrastre, con desplazamiento del elemento y animación de colocación.
5. Ajustes permite mostrar u ocultar las pestañas de la biblioteca y mantiene al menos una visible.
6. Se eliminó la cifra de cantidad de canciones de la cabecera de la vista principal de Canciones.
7. Se añadió ordenación persistente por nombre, artista, álbum, fecha de añadido y duración. Se incorpora `DATE_ADDED` de MediaStore al modelo.
8. El borde animado del buscador tiene un pulso más visible; la animación viene habilitada por defecto si nunca se había configurado.
9. Los controles de aleatorio, anterior, siguiente, repetir y reproducir/pausar recibieron superficies circulares translúcidas con contorno y reflejo.
10. Los menús de opciones de la cabecera y de cada canción usan superficies oscuras semitransparentes, esquinas redondeadas y más elevación.
11. «Tu espacio» fue rediseñado con una tarjeta de cabecera, resumen de biblioteca, estadísticas e items de ajustes de apariencia iOS-inspirados.

## Validación

- Se comprobó que el ZIP original se puede abrir y que el proyecto contiene `versionName = 3.0.0`; el proyecto editado sube a `3.0.1` para diferenciarlo de la base.
- Se hizo una comprobación estática de sintaxis del código Kotlin.
- No se pudo ejecutar `assembleDebug` porque el entorno de edición no tiene Android SDK ni Gradle instalado. Por eso esta entrega no se anuncia como APK compilada ni como validada en dispositivo.

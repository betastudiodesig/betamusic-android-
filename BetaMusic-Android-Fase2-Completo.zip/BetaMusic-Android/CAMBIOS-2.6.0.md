# ẞetaMusic Android 2.6.0 — notas de cambios

## Navegación
- Deslizamiento horizontal entre pestañas de Biblioteca, con animación de entrada y salida.
- Lista de pestañas configurables desde Perfil → Ajustes.
- Nueva pestaña Canciones.

## Personalización y carátulas
- Lectura de carátula priorizando el URI de portada del álbum de MediaStore y usando el thumbnail de audio como alternativa.
- El color dominante se propaga al acento general de la aplicación mientras está activada la opción de color dinámico.
- Borde animado del buscador con más contraste y movimiento más rápido.

## Reproductor y cola
- Eliminado el menú de tres puntos del encabezado superior del reproductor.
- Controles circulares translúcidos con reflejo suave, borde luminoso y degradado.
- Reordenamiento por arrastre de la cola con desplazamiento inmediato y animación de posición.

## Biblioteca
- Orden persistente por nombre ascendente/descendente, artista, álbum, fecha añadida y duración.
- Menú contextual con superficie oscura translúcida y borde fino en cada pista.
- Eliminados contadores generales de canciones en la vista de canciones y búsqueda.

## Perfil
- Nueva cabecera, panel de estadísticas y agrupación de acciones con estética inspirada en interfaces móviles de iOS.

## Validación
- ZIP generado a partir de la base `BetaMusic-Android-Fase5.1-Fix-Compilacion.zip`.
- No se ejecutó una compilación Android en este entorno porque no están instalados Gradle ni el Android SDK.

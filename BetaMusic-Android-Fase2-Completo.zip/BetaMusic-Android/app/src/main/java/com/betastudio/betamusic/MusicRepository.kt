package com.betastudio.betamusic

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import java.util.Locale

class MusicRepository(private val context: Context) {
    fun loadSongs(): List<Song> {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.COMPOSER,
            MediaStore.Audio.Media.IS_MUSIC
        )
        val result = mutableListOf<Song>()
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        context.contentResolver.query(collection, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val composerCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.COMPOSER)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val path = cursor.getString(dataCol).orEmpty()
                result += Song(
                    id = id,
                    title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() } ?: "Sin título",
                    artist = cursor.getString(artistCol)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Artista desconocido",
                    album = cursor.getString(albumCol)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Álbum desconocido",
                    durationMs = cursor.getLong(durationCol),
                    uri = ContentUris.withAppendedId(collection, id),
                    albumId = cursor.getLong(albumIdCol),
                    folder = path.substringBeforeLast('/', "Almacenamiento"),
                    composer = cursor.getString(composerCol)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Compositor desconocido"
                )
            }
        }
        val genresBySong = loadGenreMap()
        return result.map { song -> song.copy(genre = genresBySong[song.id] ?: "Género desconocido") }
    }

    /** Genre membership is stored in MediaStore's separate Genres/Members tables. */
    private fun loadGenreMap(): Map<Long, String> = runCatching {
        val bySong = mutableMapOf<Long, LinkedHashSet<String>>()
        val genresUri = MediaStore.Audio.Genres.getContentUri("external")
        context.contentResolver.query(
            genresUri,
            arrayOf(MediaStore.Audio.Genres._ID, MediaStore.Audio.Genres.NAME),
            null,
            null,
            MediaStore.Audio.Genres.NAME
        )?.use { genres ->
            val idColumn = genres.getColumnIndexOrThrow(MediaStore.Audio.Genres._ID)
            val nameColumn = genres.getColumnIndexOrThrow(MediaStore.Audio.Genres.NAME)
            while (genres.moveToNext()) {
                val genreId = genres.getLong(idColumn)
                val genreName = genres.getString(nameColumn)?.trim().orEmpty()
                if (genreName.isBlank()) continue
                val membersUri = MediaStore.Audio.Genres.Members.getContentUri("external", genreId)
                context.contentResolver.query(
                    membersUri,
                    arrayOf(MediaStore.Audio.Genres.Members.AUDIO_ID),
                    null,
                    null,
                    null
                )?.use { members ->
                    val audioIdColumn = members.getColumnIndex(MediaStore.Audio.Genres.Members.AUDIO_ID)
                    while (members.moveToNext()) {
                        val audioId = members.getLong(audioIdColumn)
                        bySong.getOrPut(audioId) { linkedSetOf() }.add(genreName)
                    }
                }
            }
        }
        bySong.mapValues { (_, names) -> names.joinToString(", ") }
    }.getOrDefault(emptyMap())

    companion object {
        fun normalize(value: String) = value.trim().lowercase(Locale.getDefault())
    }
}

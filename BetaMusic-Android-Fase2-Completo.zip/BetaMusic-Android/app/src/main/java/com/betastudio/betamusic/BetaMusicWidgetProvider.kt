package com.betastudio.betamusic

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.RemoteViews
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import java.util.concurrent.ExecutionException

/** Home-screen playback widget. Uses the same Media3 session as the app. */
class BetaMusicWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        WidgetUpdater.updateAll(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_PLAY_PAUSE, ACTION_NEXT, ACTION_PREVIOUS -> WidgetActionReceiver.handle(context, intent.action!!)
            Intent.ACTION_LOCALE_CHANGED -> WidgetUpdater.updateAll(context)
        }
    }

    companion object {
        const val ACTION_PLAY_PAUSE = "com.betastudio.betamusic.widget.PLAY_PAUSE"
        const val ACTION_NEXT = "com.betastudio.betamusic.widget.NEXT"
        const val ACTION_PREVIOUS = "com.betastudio.betamusic.widget.PREVIOUS"
    }
}

object WidgetUpdater {
    fun hasWidgets(context: Context): Boolean = AppWidgetManager.getInstance(context)
        .getAppWidgetIds(ComponentName(context, BetaMusicWidgetProvider::class.java)).isNotEmpty()

    fun updateAll(context: Context, player: Player? = null) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, BetaMusicWidgetProvider::class.java))
        ids.forEach { id -> manager.updateAppWidget(id, createViews(context, player)) }
    }

    private fun createViews(context: Context, player: Player?): RemoteViews {
        val views = RemoteViews(context.packageName, R.layout.widget_music_player)
        val metadata = player?.mediaMetadata
        val prefs = context.getSharedPreferences("betamusic_widget", Context.MODE_PRIVATE)
        val title = metadata?.title?.toString()?.takeIf { it.isNotBlank() }
            ?: prefs.getString("title", null) ?: "ẞetaMusic"
        val artist = metadata?.artist?.toString()?.takeIf { it.isNotBlank() }
            ?: prefs.getString("artist", null) ?: "Tu música, siempre contigo"
        val duration = (player?.duration ?: 0L).coerceAtLeast(0L)
        val position = (player?.currentPosition ?: 0L).coerceIn(0L, duration.coerceAtLeast(1L))
        views.setTextViewText(R.id.widget_title, title)
        views.setTextViewText(R.id.widget_artist, artist)
        views.setTextViewText(R.id.widget_elapsed, format(position))
        views.setTextViewText(R.id.widget_remaining, if (duration > 0) "-${format(duration - position)}" else "--:--")
        views.setProgressBar(R.id.widget_progress, 1000, if (duration > 0) (position * 1000 / duration).toInt() else 0, false)
        views.setTextViewText(R.id.widget_play_pause, if (player?.isPlaying == true) "Ⅱ" else "▶")
        val artwork = runCatching {
            val data = metadata?.artworkData
            if (data != null && data.isNotEmpty()) BitmapFactory.decodeByteArray(data, 0, data.size)
            else {
                val uri = metadata?.artworkUri
                if (uri != null) context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                else null
            }
        }.getOrNull()
        if (artwork != null) views.setImageViewBitmap(R.id.widget_artwork, artwork)
        else views.setImageViewResource(R.id.widget_artwork, R.drawable.widget_artwork_placeholder)

        views.setOnClickPendingIntent(R.id.widget_root, PendingIntent.getActivity(
            context, 4100, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        ))
        views.setOnClickPendingIntent(R.id.widget_previous, actionIntent(context, BetaMusicWidgetProvider.ACTION_PREVIOUS, 4101))
        views.setOnClickPendingIntent(R.id.widget_play_pause, actionIntent(context, BetaMusicWidgetProvider.ACTION_PLAY_PAUSE, 4102))
        views.setOnClickPendingIntent(R.id.widget_next, actionIntent(context, BetaMusicWidgetProvider.ACTION_NEXT, 4103))
        return views
    }

    private fun actionIntent(context: Context, action: String, requestCode: Int): PendingIntent {
        val intent = Intent(context, WidgetActionReceiver::class.java).setAction(action)
        return PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun format(ms: Long): String {
        val seconds = (ms / 1000).coerceAtLeast(0)
        return "%d:%02d".format(seconds / 60, seconds % 60)
    }
}

class WidgetActionReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        handle(context, action)
    }

    companion object {
        fun handle(context: Context, action: String) {
            val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
            val future = MediaController.Builder(context, token).buildAsync()
            future.addListener({
                try {
                    val controller = future.get()
                    when (action) {
                        BetaMusicWidgetProvider.ACTION_PLAY_PAUSE -> if (controller.isPlaying) controller.pause() else controller.play()
                        BetaMusicWidgetProvider.ACTION_NEXT -> controller.seekToNextMediaItem()
                        BetaMusicWidgetProvider.ACTION_PREVIOUS -> controller.seekToPreviousMediaItem()
                    }
                    WidgetUpdater.updateAll(context, controller)
                    MediaController.releaseFuture(future)
                } catch (_: Exception) {
                    MediaController.releaseFuture(future)
                }
            }, ContextCompat.getMainExecutor(context))
        }
    }
}

package com.betastudio.betamusic

import android.Manifest
import android.content.ComponentName
import android.content.ContentResolver
import android.content.Intent
import android.content.ContentUris
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.LruCache
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.Image as BitmapImage
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.roundToInt
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

// ───────────────────────── Identidad visual ẞetaMusic ─────────────────────────
private val Bg = Color(0xFF080711)
private val SurfaceDark = Color(0xFF11101B)
private val SurfaceLight = Color(0xFF1B1730)
private val appAccentState = mutableStateOf(Color(0xFFF454B8))
private val Lime: Color get() = appAccentState.value
private val OnLime = Color(0xFF160B19)
private val TextMain = Color(0xFFF8F5FB)
private val TextMuted = Color(0xFFA9A1B7)
private val NeonViolet = Color(0xFF7147F5)
private val NeonPink = Color(0xFFF454B8)

private val ArtBase: Uri = Uri.parse("content://media/external/audio/albumart")

private const val SECTION_HOME = "home"
private const val SECTION_SEARCH = "search"
private const val SECTION_PROFILE = "profile"
private const val SECTION_LIBRARY = "library"
private const val SECTION_FAVORITES = "favorites"
private const val SECTION_QUEUE = "queue"
private const val SECTION_PLAYLISTS = "playlists"
private const val SECTION_SETTINGS = "settings"
private const val PREFS_SETTINGS = "betamusic_settings"
private const val PREF_ACCENT = "accent_color"
private const val PREF_SEARCH_ANIMATION = "search_animation_enabled"
private const val PREF_DYNAMIC_PLAYER_COLOR = "dynamic_player_color_enabled"
private const val PREF_BLUR_PLAYER_BACKGROUND = "blur_player_background_enabled"
private const val PREF_LIBRARY_TABS = "visible_library_tabs"
private const val PREF_SONG_SORT = "song_sort_mode"
private val defaultLibraryTabs = listOf("Listas", "Artistas", "Álbumes", "Canciones", "Descargas")
private val songSortOptions = listOf("Nombre (A–Z)", "Nombre (Z–A)", "Artista", "Álbum", "Fecha añadida · nuevas", "Fecha añadida · antiguas", "Duración · mayor", "Duración · menor")

private fun readVisibleLibraryTabs(context: android.content.Context): List<String> {
    val saved = context.getSharedPreferences(PREFS_SETTINGS, android.content.Context.MODE_PRIVATE)
        .getStringSet(PREF_LIBRARY_TABS, null)
    return defaultLibraryTabs.filter { saved == null || it in saved }.ifEmpty { defaultLibraryTabs }
}

private val searchAnimationState = mutableStateOf(true)
private val dynamicPlayerColorState = mutableStateOf(true)
private val blurPlayerBackgroundState = mutableStateOf(true)

private data class LibraryGroup(
    val id: String,
    val title: String,
    val subtitle: String,
    val songs: List<Song>
) {
    val coverSong: Song? get() = songs.firstOrNull()
}

private data class MusicPlaylist(val id: String, val name: String, val songIds: List<Long>)

private data class AccentChoice(val name: String, val color: Color)

private val accentChoices = listOf(
    AccentChoice("Rosa neón", Color(0xFFF454B8)),
    AccentChoice("Violeta", Color(0xFF9B6BFF)),
    AccentChoice("Azul", Color(0xFF5487FF)),
    AccentChoice("Cian", Color(0xFF35D7E8)),
    AccentChoice("Coral", Color(0xFFFF796D)),
    AccentChoice("Ámbar", Color(0xFFFFC857)),
    AccentChoice("Lima", Color(0xFFB7F34A))
)

private fun readPlaylists(context: android.content.Context): List<MusicPlaylist> = runCatching {
    val json = context.getSharedPreferences("betamusic", android.content.Context.MODE_PRIVATE)
        .getString("playlists_json", "[]") ?: "[]"
    val array = JSONArray(json)
    buildList {
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val ids = item.optJSONArray("songIds") ?: JSONArray()
            add(MusicPlaylist(
                id = item.optString("id", System.currentTimeMillis().toString() + i),
                name = item.optString("name", "Lista ${i + 1}"),
                songIds = buildList { for (j in 0 until ids.length()) ids.optLong(j).takeIf { it > 0L }?.let { add(it) } }.distinct()
            ))
        }
    }
}.getOrDefault(emptyList())

private fun savePlaylists(context: android.content.Context, playlists: List<MusicPlaylist>) {
    val array = JSONArray()
    playlists.forEach { playlist ->
        val ids = JSONArray()
        playlist.songIds.forEach(ids::put)
        array.put(JSONObject().put("id", playlist.id).put("name", playlist.name).put("songIds", ids))
    }
    context.getSharedPreferences("betamusic", android.content.Context.MODE_PRIVATE)
        .edit().putString("playlists_json", array.toString()).apply()
}

internal data class QueueEntry(val index: Int, val song: Song)

internal data class UiState(
    val songs: List<Song>,
    val loading: Boolean,
    val hasPermission: Boolean,
    val error: String?,
    val favorites: Set<Long>,
    val currentId: Long?,
    val isPlaying: Boolean,
    val duration: Long,
    val shuffle: Boolean,
    val repeatMode: Int,
    val queueVersion: Int,
    val message: String?
)

internal class UiActions(
    val requestPermission: () -> Unit,
    val refresh: () -> Unit,
    val play: (Song, List<Song>) -> Unit,
    val togglePlay: () -> Unit,
    val next: () -> Unit,
    val previous: () -> Unit,
    val seek: (Long) -> Unit,
    val toggleFavorite: (Song) -> Unit,
    val toggleShuffle: () -> Unit,
    val cycleRepeat: () -> Unit,
    val playQueueItem: (Int) -> Unit,
    val moveQueueItem: (Int, Int) -> Unit,
    val readQueue: (Map<Long, Song>) -> List<QueueEntry>,
    val dismissMessage: () -> Unit
)

// ───────────────────────────── Actividad ─────────────────────────────
class MainActivity : ComponentActivity() {
    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var loadJob: Job? = null
    private var errorStreak = 0

    private val songsState = mutableStateOf<List<Song>>(emptyList())
    private val permissionState = mutableStateOf(false)
    private val loadingState = mutableStateOf(true)
    private val errorState = mutableStateOf<String?>(null)
    private val favoritesState = mutableStateOf<Set<Long>>(emptySet())
    private val currentIdState = mutableStateOf<Long?>(null)
    private val playingState = mutableStateOf(false)
    private val durationState = mutableLongStateOf(0L)
    private val positionState = mutableLongStateOf(0L)
    private val shuffleState = mutableStateOf(false)
    private val repeatState = mutableIntStateOf(Player.REPEAT_MODE_OFF)
    private val queueVersionState = mutableIntStateOf(0)
    private val messageState = mutableStateOf<String?>(null)

    private val audioPermission: String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            permissionState.value = granted
            if (granted) loadLibrary() else loadingState.value = false
        }

    private val notificationLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* sin acción: la reproducción no depende de ello */ }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            playingState.value = isPlaying
            if (isPlaying) errorStreak = 0
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            currentIdState.value = mediaItem?.mediaId?.toLongOrNull()
            syncPlayerState()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            syncPlayerState()
        }

        override fun onTimelineChanged(timeline: Timeline, reason: Int) {
            queueVersionState.intValue++
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            shuffleState.value = shuffleModeEnabled
            queueVersionState.intValue++
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            repeatState.intValue = repeatMode
        }

        override fun onPlayerError(error: PlaybackException) {
            val player = controller ?: return
            val title = player.currentMediaItem?.mediaMetadata?.title?.toString() ?: "la canción"
            errorStreak++
            messageState.value = "No se pudo reproducir «$title». Puede estar dañado o haber sido movido."
            // Se salta al siguiente archivo, con un límite para no entrar en un bucle si todos fallan.
            if (errorStreak <= 5 && player.hasNextMediaItem()) {
                player.seekToNextMediaItem()
                player.prepare()
                player.play()
            }
        }
    }

    private val actions = UiActions(
        requestPermission = { permissionLauncher.launch(audioPermission) },
        refresh = { refreshLibrary() },
        play = { song, list -> playSong(song, list) },
        togglePlay = { togglePlay() },
        next = { controller?.seekToNext() },
        previous = { controller?.seekToPrevious() },
        seek = { ms ->
            controller?.seekTo(ms)
            positionState.longValue = ms
        },
        toggleFavorite = { toggleFavorite(it) },
        toggleShuffle = {
            controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
        },
        cycleRepeat = {
            controller?.let {
                it.repeatMode = when (it.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
            }
        },
        playQueueItem = { index ->
            controller?.let {
                it.seekTo(index, 0L)
                if (it.playbackState == Player.STATE_IDLE) it.prepare()
                it.play()
            }
        },
        moveQueueItem = { from, to ->
            controller?.let { player ->
                if (from in 0 until player.mediaItemCount && to in 0 until player.mediaItemCount && from != to) {
                    player.moveMediaItem(from, to)
                    queueVersionState.intValue++
                }
            }
        },
        readQueue = { byId -> readQueue(byId) },
        dismissMessage = { messageState.value = null }
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val savedAccent = getSharedPreferences(PREFS_SETTINGS, MODE_PRIVATE)
            .getInt(PREF_ACCENT, Color(0xFFF454B8).toArgb())
        appAccentState.value = Color(savedAccent)
        val appearancePrefs = getSharedPreferences(PREFS_SETTINGS, MODE_PRIVATE)
        searchAnimationState.value = appearancePrefs.getBoolean(PREF_SEARCH_ANIMATION, true)
        dynamicPlayerColorState.value = appearancePrefs.getBoolean(PREF_DYNAMIC_PLAYER_COLOR, true)
        blurPlayerBackgroundState.value = appearancePrefs.getBoolean(PREF_BLUR_PLAYER_BACKGROUND, true)

        favoritesState.value =
            getSharedPreferences("betamusic", MODE_PRIVATE)
                .getStringSet("favorites", emptySet())
                ?.mapNotNull { it.toLongOrNull() }
                ?.toSet() ?: emptySet()

        if (ContextCompat.checkSelfPermission(this, audioPermission) == PackageManager.PERMISSION_GRANTED) {
            permissionState.value = true
            loadLibrary()
        } else {
            loadingState.value = false
            permissionLauncher.launch(audioPermission)
        }

        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener({
                try {
                    controller = future.get()
                    controller?.addListener(playerListener)
                    syncPlayerState()
                    queueVersionState.intValue++
                } catch (_: Exception) {
                    messageState.value = "No se pudo conectar con el servicio de reproducción."
                }
            }, ContextCompat.getMainExecutor(this))
        }

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Lime,
                    onPrimary = OnLime,
                    background = Bg,
                    surface = SurfaceDark,
                    onBackground = TextMain,
                    onSurface = TextMain
                )
            ) {
                val ui = UiState(
                    songs = songsState.value,
                    loading = loadingState.value,
                    hasPermission = permissionState.value,
                    error = errorState.value,
                    favorites = favoritesState.value,
                    currentId = currentIdState.value,
                    isPlaying = playingState.value,
                    duration = durationState.longValue,
                    shuffle = shuffleState.value,
                    repeatMode = repeatState.intValue,
                    queueVersion = queueVersionState.intValue,
                    message = messageState.value
                )
                BetaMusicScreen(
                    ui = ui,
                    position = { positionState.longValue },
                    a = actions
                )
            }
        }

        // El avance de la barra solo se actualiza mientras la app está visible y suena música.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                syncPlayerState()
                while (true) {
                    val player = controller
                    if (player != null && player.isPlaying) {
                        val pos = player.currentPosition.coerceAtLeast(0L)
                        if (pos != positionState.longValue) positionState.longValue = pos
                    }
                    delay(500)
                }
            }
        }
    }

    private fun refreshLibrary() {
        if (ContextCompat.checkSelfPermission(this, audioPermission) == PackageManager.PERMISSION_GRANTED) {
            permissionState.value = true
            loadLibrary()
        } else {
            permissionLauncher.launch(audioPermission)
        }
    }

    private fun loadLibrary() {
        loadJob?.cancel()
        loadingState.value = true
        errorState.value = null
        loadJob = lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching { MusicRepository(this@MainActivity).loadSongs() }
            }
            result
                .onSuccess { songsState.value = it }
                .onFailure {
                    errorState.value = it.message ?: "Error desconocido al leer la biblioteca."
                }
            loadingState.value = false
        }
    }

    private fun buildItem(song: Song): MediaItem {
        val metadata = MediaMetadata.Builder()
            .setTitle(song.title)
            .setArtist(song.artist)
            .setAlbumTitle(song.album)
        if (song.albumId > 0) {
            metadata.setArtworkUri(ContentUris.withAppendedId(ArtBase, song.albumId))
        }
        return MediaItem.Builder()
            .setMediaId(song.id.toString())
            .setUri(song.uri)
            .setMediaMetadata(metadata.build())
            .build()
    }

    /** La cola es la lista desde la que se tocó la canción (álbum, artista, carpeta, favoritos o búsqueda). */
    private fun playSong(song: Song, context: List<Song>) {
        val player = controller
        if (player == null) {
            messageState.value = "El reproductor se está iniciando. Inténtalo de nuevo en un momento."
            return
        }
        val list = if (context.any { it.id == song.id }) context else listOf(song)
        askNotificationsOnce()
        lifecycleScope.launch {
            val items = withContext(Dispatchers.Default) { list.map { buildItem(it) } }
            val index = list.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
            errorStreak = 0
            player.setMediaItems(items, index, 0L)
            player.prepare()
            player.play()
            currentIdState.value = song.id
        }
    }

    private fun askNotificationsOnce() {
        if (Build.VERSION.SDK_INT < 33) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        ) return
        val prefs = getSharedPreferences("betamusic", MODE_PRIVATE)
        if (prefs.getBoolean("asked_notifications", false)) return
        prefs.edit().putBoolean("asked_notifications", true).apply()
        notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun togglePlay() {
        val player = controller ?: return
        if (player.mediaItemCount == 0) {
            songsState.value.firstOrNull()?.let { playSong(it, songsState.value) }
            return
        }
        if (player.isPlaying) {
            player.pause()
        } else {
            when (player.playbackState) {
                Player.STATE_IDLE -> player.prepare()
                Player.STATE_ENDED -> player.seekToDefaultPosition(0)
                else -> Unit
            }
            player.play()
        }
    }

    private fun readQueue(byId: Map<Long, Song>): List<QueueEntry> {
        val player = controller ?: return emptyList()
        val timeline = player.currentTimeline
        if (timeline.isEmpty) return emptyList()
        val out = ArrayList<QueueEntry>(timeline.windowCount)
        for (i in 0 until timeline.windowCount) {
            val song = player.getMediaItemAt(i).mediaId.toLongOrNull()?.let { byId[it] }
            if (song != null) out.add(QueueEntry(i, song))
        }
        return out
    }

    private fun syncPlayerState() {
        val player = controller ?: return
        playingState.value = player.isPlaying
        durationState.longValue = player.duration.takeIf { it > 0 } ?: 0L
        positionState.longValue = player.currentPosition.coerceAtLeast(0L)
        currentIdState.value = player.currentMediaItem?.mediaId?.toLongOrNull()
        shuffleState.value = player.shuffleModeEnabled
        repeatState.intValue = player.repeatMode
    }

    private fun toggleFavorite(song: Song) {
        val next = favoritesState.value.toMutableSet().apply {
            if (!add(song.id)) remove(song.id)
        }.toSet()
        favoritesState.value = next
        getSharedPreferences("betamusic", MODE_PRIVATE)
            .edit()
            .putStringSet("favorites", next.map { it.toString() }.toSet())
            .apply()
    }

    override fun onDestroy() {
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }
}

// ───────────────────────────── Pantalla principal ─────────────────────────────
@Composable
private fun BetaMusicScreen(ui: UiState, position: () -> Long, a: UiActions) {
    var query by rememberSaveable { mutableStateOf("") }
    var section by rememberSaveable { mutableStateOf(SECTION_HOME) }
    val context = LocalContext.current
    val settingsPrefs = remember(context) { context.getSharedPreferences(PREFS_SETTINGS, android.content.Context.MODE_PRIVATE) }
    val tabSwipeThresholdPx = with(LocalDensity.current) { 68.dp.toPx() }
    var visibleTabs by remember { mutableStateOf(readVisibleLibraryTabs(context)) }
    var tab by rememberSaveable { mutableStateOf(readVisibleLibraryTabs(context).firstOrNull() ?: "Listas") }
    var sortMode by rememberSaveable { mutableStateOf(settingsPrefs.getString(PREF_SONG_SORT, songSortOptions.first()) ?: songSortOptions.first()) }
    var selectedGroupId by rememberSaveable { mutableStateOf<String?>(null) }
    var showPlayer by rememberSaveable { mutableStateOf(false) }
    var selectedPlaylistId by rememberSaveable { mutableStateOf<String?>(null) }
    var showCreatePlaylist by rememberSaveable { mutableStateOf(false) }
    var showAddSongs by rememberSaveable { mutableStateOf(false) }
    var playlists by remember { mutableStateOf(readPlaylists(context)) }
    val persistPlaylists: (List<MusicPlaylist>) -> Unit = { updated ->
        playlists = updated
        savePlaylists(context, updated)
    }

    val songs = ui.songs
    val songsById = remember(songs) { songs.associateBy { it.id } }
    val current = ui.currentId?.let { songsById[it] }
    val dominantCoverColor by rememberDominantCoverColor(current)
    LaunchedEffect(current?.id, dynamicPlayerColorState.value, dominantCoverColor) {
        if (dynamicPlayerColorState.value && current != null) {
            appAccentState.value = dominantCoverColor
        } else if (!dynamicPlayerColorState.value) {
            appAccentState.value = Color(settingsPrefs.getInt(PREF_ACCENT, Color(0xFFF454B8).toArgb()))
        }
    }
    val sortedSongs = remember(songs, sortMode) {
        when (sortMode) {
            "Nombre (Z–A)" -> songs.sortedByDescending { it.title.lowercase(Locale.getDefault()) }
            "Artista" -> songs.sortedWith(compareBy<Song> { it.artist.lowercase(Locale.getDefault()) }.thenBy { it.title.lowercase(Locale.getDefault()) })
            "Álbum" -> songs.sortedWith(compareBy<Song> { it.album.lowercase(Locale.getDefault()) }.thenBy { it.title.lowercase(Locale.getDefault()) })
            "Fecha añadida · nuevas" -> songs.sortedByDescending { it.dateAddedSeconds }
            "Fecha añadida · antiguas" -> songs.sortedBy { it.dateAddedSeconds }
            "Duración · mayor" -> songs.sortedByDescending { it.durationMs }
            "Duración · menor" -> songs.sortedBy { it.durationMs }
            else -> songs.sortedBy { it.title.lowercase(Locale.getDefault()) }
        }
    }
    val selectedPlaylist = playlists.firstOrNull { it.id == selectedPlaylistId }
    val playlistSongs = selectedPlaylist?.songIds.orEmpty().mapNotNull(songsById::get)
    val groups = remember(sortedSongs, tab) {
        when (tab) {
            "Artistas" -> buildGroups(sortedSongs, "Artistas")
            "Álbumes" -> buildGroups(sortedSongs, "Álbumes")
            else -> emptyList()
        }
    }
    val selectedGroup = groups.firstOrNull { it.id == selectedGroupId }
    val filteredGroups = remember(groups, query) {
        groups.filter { group -> query.isBlank() || group.title.contains(query, true) || group.subtitle.contains(query, true) || group.songs.any { songMatches(it, query) } }
    }
    val baseSongs = selectedGroup?.songs ?: sortedSongs
    val filteredSongs = remember(baseSongs, query) { baseSongs.filter { songMatches(it, query) } }
    val downloadSongs = remember(filteredSongs) {
        filteredSongs.filter { it.folder.contains("/download", true) || it.folder.endsWith("download", true) }
    }
    val favoriteSongs = remember(sortedSongs, ui.favorites, query) { sortedSongs.filter { it.id in ui.favorites && songMatches(it, query) } }
    val homeSongs = remember(songs, ui.currentId) {
        buildList {
            current?.let { add(it) }
            songs.filterNot { it.id == ui.currentId }.take(8).forEach(::add)
        }.take(8)
    }
    val personalMix = remember(songs, ui.favorites, ui.currentId) {
        buildPersonalMix(songs, ui.favorites, current)
    }

    LaunchedEffect(current == null) { if (current == null) showPlayer = false }
    LaunchedEffect(ui.message) {
        if (ui.message != null) {
            delay(3500)
            a.dismissMessage()
        }
    }

    BackHandler(enabled = showPlayer && current != null) { showPlayer = false }
    BackHandler(enabled = !showPlayer && section == SECTION_PLAYLISTS && selectedPlaylistId != null) {
        selectedPlaylistId = null
        section = SECTION_LIBRARY
        tab = if ("Listas" in visibleTabs) "Listas" else visibleTabs.first()
    }
    BackHandler(enabled = !showPlayer && section == SECTION_LIBRARY && selectedGroup != null) { selectedGroupId = null }
    BackHandler(enabled = !showPlayer && section == SECTION_LIBRARY && selectedPlaylistId != null) { selectedPlaylistId = null }
    BackHandler(enabled = !showPlayer && section == SECTION_LIBRARY && selectedGroup == null && selectedPlaylistId == null) { section = SECTION_HOME }
    BackHandler(enabled = !showPlayer && section in listOf(SECTION_FAVORITES, SECTION_QUEUE, SECTION_SETTINGS)) { section = SECTION_PROFILE }
    BackHandler(enabled = !showPlayer && section in listOf(SECTION_SEARCH, SECTION_PROFILE, SECTION_PLAYLISTS)) {
        section = if (section == SECTION_PLAYLISTS) SECTION_LIBRARY else SECTION_HOME
        selectedPlaylistId = null
    }

    Column(
        Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()
    ) {
        if (showPlayer && current != null) {
            NowPlayingScreen(
                song = current,
                isPlaying = ui.isPlaying,
                isFavorite = current.id in ui.favorites,
                shuffle = ui.shuffle,
                repeatMode = ui.repeatMode,
                position = position,
                duration = ui.duration,
                onBack = { showPlayer = false },
                onTogglePlay = a.togglePlay,
                onPrevious = a.previous,
                onNext = a.next,
                onSeek = a.seek,
                onToggleFavorite = { a.toggleFavorite(current) },
                onToggleShuffle = a.toggleShuffle,
                onCycleRepeat = a.cycleRepeat,
                onOpenQueue = { showPlayer = false; section = SECTION_QUEUE },
                onOpenPlaylists = { showPlayer = false; section = SECTION_LIBRARY; tab = if ("Listas" in visibleTabs) "Listas" else visibleTabs.first() },
                dynamicColors = dynamicPlayerColorState.value,
                blurBackground = blurPlayerBackgroundState.value
            )
        } else {
            TopHeader(
                onSearch = { section = SECTION_SEARCH },
                onProfile = { section = SECTION_PROFILE }
            )

            Box(Modifier.weight(1f).fillMaxWidth()) {
                Crossfade(targetState = section, animationSpec = tween(durationMillis = 230), label = "sectionTransition") { visibleSection ->
                when (visibleSection) {
                    SECTION_HOME -> HomePane(
                        songs = homeSongs,
                        allSongs = songs,
                        personalMix = personalMix,
                        mixUsesFavorites = songs.any { it.id in ui.favorites },
                        playlists = playlists,
                        songsById = songsById,
                        onPlay = { song, source -> a.play(song, source); showPlayer = true },
                        onOpenAll = { section = SECTION_SEARCH; query = "" },
                        onOpenLibrary = { section = SECTION_LIBRARY; tab = if ("Álbumes" in visibleTabs) "Álbumes" else visibleTabs.first() },
                        onOpenPlaylist = { playlist -> selectedPlaylistId = playlist.id; section = SECTION_PLAYLISTS }
                    )

                    SECTION_SEARCH -> Column(Modifier.fillMaxSize()) {
                        SearchField(query, animated = searchAnimationState.value) { query = it }
                        SortModeRow(sortMode = sortMode, onSelect = { next ->
                            sortMode = next
                            settingsPrefs.edit().putString(PREF_SONG_SORT, next).apply()
                        })
                        when {
                            !ui.hasPermission -> EmptyState("Permiso necesario", "Permite el acceso al audio para buscar en tu biblioteca.", "Conceder permiso", a.requestPermission)
                            ui.loading -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Lime) }
                            filteredSongs.isEmpty() -> EmptyState("No se encontraron canciones", "Prueba otro título, artista o álbum.", if (query.isNotBlank()) "Limpiar búsqueda" else null, { query = "" })
                            else -> SongList(filteredSongs, ui.currentId, ui.isPlaying, ui.favorites, { song -> a.play(song, filteredSongs); showPlayer = true }, a.toggleFavorite, Modifier.weight(1f))
                        }
                    }

                    SECTION_PROFILE -> ProfilePane(
                        songCount = songs.size,
                        favoritesCount = ui.favorites.size,
                        playlistCount = playlists.size,
                        onFavorites = { section = SECTION_FAVORITES },
                        onQueue = { section = SECTION_QUEUE },
                        onSettings = { section = SECTION_SETTINGS },
                        onRefresh = a.refresh
                    )

                    SECTION_FAVORITES -> Column(Modifier.fillMaxSize()) {
                        SearchField(query, animated = searchAnimationState.value) { query = it }
                        CountHeader("TUS FAVORITOS", if (ui.loading) "Leyendo música…" else "${favoriteSongs.size} pistas")
                        if (favoriteSongs.isEmpty()) {
                            EmptyState(if (ui.favorites.isEmpty()) "Aún no hay favoritos" else "Sin resultados", if (ui.favorites.isEmpty()) "Toca el corazón de una canción para guardarla aquí." else "Prueba otra búsqueda.", if (query.isNotEmpty()) "Limpiar búsqueda" else null) { query = "" }
                        } else {
                            SongList(favoriteSongs, ui.currentId, ui.isPlaying, ui.favorites, { song -> a.play(song, favoriteSongs); showPlayer = true }, a.toggleFavorite, Modifier.weight(1f))
                        }
                    }

                    SECTION_QUEUE -> QueuePane(ui = ui, songsById = songsById, a = a)

                    SECTION_PLAYLISTS -> {
                        if (selectedPlaylist == null) {
                            PlaylistsPane(playlists, songsById, { showCreatePlaylist = true }, { selectedPlaylistId = it.id }, Modifier.fillMaxSize())
                        } else {
                            PlaylistDetailPane(
                                playlist = selectedPlaylist,
                                songs = playlistSongs,
                                currentId = ui.currentId,
                                isPlaying = ui.isPlaying,
                                onBack = { selectedPlaylistId = null; section = SECTION_LIBRARY; tab = if ("Listas" in visibleTabs) "Listas" else visibleTabs.first() },
                                onAddSongs = { showAddSongs = true },
                                onPlay = { song -> a.play(song, playlistSongs); showPlayer = true },
                                onRemove = { song -> persistPlaylists(playlists.map { item -> if (item.id == selectedPlaylist.id) item.copy(songIds = item.songIds.filterNot { it == song.id }) else item }) },
                                onDelete = { persistPlaylists(playlists.filterNot { it.id == selectedPlaylist.id }); selectedPlaylistId = null; section = SECTION_LIBRARY; tab = if ("Listas" in visibleTabs) "Listas" else visibleTabs.first() },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }

                    SECTION_SETTINGS -> SettingsPane(
                        selectedAccent = appAccentState.value,
                        onSelectAccent = { color ->
                            appAccentState.value = color
                            context.getSharedPreferences(PREFS_SETTINGS, android.content.Context.MODE_PRIVATE).edit().putInt(PREF_ACCENT, color.toArgb()).apply()
                        },
                        searchAnimationEnabled = searchAnimationState.value,
                        onSearchAnimationChange = { enabled ->
                            searchAnimationState.value = enabled
                            context.getSharedPreferences(PREFS_SETTINGS, android.content.Context.MODE_PRIVATE).edit().putBoolean(PREF_SEARCH_ANIMATION, enabled).apply()
                        },
                        dynamicPlayerColorEnabled = dynamicPlayerColorState.value,
                        onDynamicPlayerColorChange = { enabled ->
                            dynamicPlayerColorState.value = enabled
                            context.getSharedPreferences(PREFS_SETTINGS, android.content.Context.MODE_PRIVATE).edit().putBoolean(PREF_DYNAMIC_PLAYER_COLOR, enabled).apply()
                        },
                        blurPlayerBackgroundEnabled = blurPlayerBackgroundState.value,
                        onBlurPlayerBackgroundChange = { enabled ->
                            blurPlayerBackgroundState.value = enabled
                            context.getSharedPreferences(PREFS_SETTINGS, android.content.Context.MODE_PRIVATE).edit().putBoolean(PREF_BLUR_PLAYER_BACKGROUND, enabled).apply()
                        },
                        visibleTabs = visibleTabs,
                        onToggleLibraryTab = { label, enabled ->
                            val updated = if (enabled) defaultLibraryTabs.filter { it in visibleTabs || it == label } else visibleTabs.filterNot { it == label }
                            if (updated.isNotEmpty()) {
                                visibleTabs = updated
                                settingsPrefs.edit().putStringSet(PREF_LIBRARY_TABS, updated.toSet()).apply()
                                if (tab !in updated) tab = updated.first()
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )

                    else -> Column(Modifier.fillMaxSize()) {
                        LibraryTabs(
                            selectedTab = tab,
                            visibleTabs = visibleTabs,
                            onSelect = { next -> tab = next; selectedGroupId = null; query = "" },
                            sortMode = sortMode,
                            onSortSelect = { next -> sortMode = next; settingsPrefs.edit().putString(PREF_SONG_SORT, next).apply() }
                        )
                        AnimatedContent(
                            targetState = tab,
                            transitionSpec = {
                                val forward = defaultLibraryTabs.indexOf(targetState) >= defaultLibraryTabs.indexOf(initialState)
                                val sign = if (forward) 1 else -1
                                (slideInHorizontally(tween(230)) { sign * it / 4 } + fadeIn(tween(180))) togetherWith
                                    (slideOutHorizontally(tween(190)) { -sign * it / 5 } + fadeOut(tween(150)))
                            },
                            label = "libraryTabTransition",
                            modifier = Modifier.weight(1f).fillMaxWidth().pointerInput(visibleTabs, tab) {
                                var totalDrag = 0f
                                detectHorizontalDragGestures(
                                    onDragStart = { totalDrag = 0f },
                                    onHorizontalDrag = { change, dragAmount ->
                                        totalDrag += dragAmount
                                        change.consume()
                                    },
                                    onDragEnd = {
                                        if (kotlin.math.abs(totalDrag) > tabSwipeThresholdPx && visibleTabs.size > 1) {
                                            val currentIndex = visibleTabs.indexOf(tab).coerceAtLeast(0)
                                            val nextIndex = if (totalDrag < 0f) (currentIndex + 1).coerceAtMost(visibleTabs.lastIndex) else (currentIndex - 1).coerceAtLeast(0)
                                            if (nextIndex != currentIndex) {
                                                tab = visibleTabs[nextIndex]
                                                selectedGroupId = null
                                                selectedPlaylistId = null
                                                query = ""
                                            }
                                        }
                                    },
                                    onDragCancel = { totalDrag = 0f }
                                )
                            }
                        ) { visibleTab ->
                            if (visibleTab != tab) {
                                // La capa saliente solo mantiene el contenido durante la transición.
                            }
                            when {
                                selectedGroup != null && visibleTab == tab -> {
                                    Column(Modifier.fillMaxSize()) {
                                        Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 20.dp, top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                            IconButton(onClick = { selectedGroupId = null }) { Icon(Icons.Default.ArrowBack, "Volver", tint = Lime) }
                                            Column(Modifier.weight(1f)) {
                                                Text(selectedGroup.title, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                Text(selectedGroup.subtitle, color = TextMuted, fontSize = 12.sp)
                                            }
                                        }
                                        SongList(filteredSongs, ui.currentId, ui.isPlaying, ui.favorites, { song -> a.play(song, filteredSongs); showPlayer = true }, a.toggleFavorite, Modifier.weight(1f))
                                    }
                                }
                                !ui.hasPermission -> EmptyState("Permiso necesario", "Permite el acceso al audio para mostrar tu biblioteca.", "Conceder permiso", a.requestPermission)
                                ui.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Lime) }
                                ui.error != null -> EmptyState("No se pudo leer la biblioteca", ui.error, "Reintentar", a.refresh)
                                visibleTab == "Listas" -> PlaylistsPane(
                                    playlists = playlists,
                                    songsById = songsById,
                                    onCreate = { showCreatePlaylist = true },
                                    onOpen = { selectedPlaylistId = it.id; section = SECTION_PLAYLISTS },
                                    modifier = Modifier.fillMaxSize()
                                )
                                visibleTab == "Artistas" || visibleTab == "Álbumes" -> {
                                    Column(Modifier.fillMaxSize()) {
                                        CountHeader(if (visibleTab == "Artistas") "TUS ARTISTAS" else "TUS ÁLBUMES", "${filteredGroups.size} ${if (visibleTab == "Artistas") "artistas" else "álbumes"}")
                                        if (filteredGroups.isEmpty()) EmptyState("No hay elementos", "No se encontraron resultados en tu biblioteca.", null, {})
                                        else GroupList(filteredGroups, { selectedGroupId = it.id }, Modifier.weight(1f))
                                    }
                                }
                                else -> {
                                    val isDownloads = visibleTab == "Descargas"
                                    val shownSongs = if (isDownloads && downloadSongs.isNotEmpty()) downloadSongs else filteredSongs
                                    Column(Modifier.fillMaxSize()) {
                                        SortModeRow(
                                            sortMode = sortMode,
                                            title = if (isDownloads) "Descargas" else "Canciones",
                                            onSelect = { next -> sortMode = next; settingsPrefs.edit().putString(PREF_SONG_SORT, next).apply() }
                                        )
                                        if (shownSongs.isEmpty()) EmptyState("No hay canciones", "Añade archivos de música al teléfono y actualiza la biblioteca.", "Actualizar", a.refresh)
                                        else SongList(shownSongs, ui.currentId, ui.isPlaying, ui.favorites, { song -> a.play(song, shownSongs); showPlayer = true }, a.toggleFavorite, Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                }
                }

                ui.message?.let { message ->
                    Box(Modifier.align(Alignment.BottomCenter).padding(12.dp).clip(RoundedCornerShape(14.dp)).background(SurfaceLight).border(1.dp, NeonViolet.copy(alpha = .35f), RoundedCornerShape(14.dp)).padding(horizontal = 16.dp, vertical = 12.dp)) {
                        Text(message, color = TextMain, fontSize = 13.sp)
                    }
                }
            }

            if (current != null) {
                MiniPlayer(
                    song = current,
                    isPlaying = ui.isPlaying,
                    position = position,
                    duration = ui.duration,
                    onOpen = { showPlayer = true },
                    onPrevious = a.previous,
                    onTogglePlay = a.togglePlay,
                    onNext = a.next
                )
            }
            BottomBar(section) { destination ->
                section = destination
                if (destination != SECTION_PLAYLISTS) selectedPlaylistId = null
                if (destination == SECTION_LIBRARY) { selectedGroupId = null; query = "" }
                if (destination == SECTION_SEARCH) query = ""
            }
        }

        if (showCreatePlaylist) {
            CreatePlaylistDialog(
                onDismiss = { showCreatePlaylist = false },
                onCreate = { name ->
                    val playlist = MusicPlaylist(System.currentTimeMillis().toString(), name, emptyList())
                    persistPlaylists(playlists + playlist)
                    selectedPlaylistId = playlist.id
                    section = SECTION_PLAYLISTS
                    showCreatePlaylist = false
                }
            )
        }
        if (showAddSongs && selectedPlaylist != null) {
            AddSongsDialog(
                songs = songs,
                selectedIds = selectedPlaylist.songIds.toSet(),
                onDismiss = { showAddSongs = false },
                onConfirm = { ids ->
                    persistPlaylists(playlists.map { item -> if (item.id == selectedPlaylist.id) item.copy(songIds = ids.toList()) else item })
                    showAddSongs = false
                }
            )
        }
    }
}

@Composable
private fun HomePane(
    songs: List<Song>,
    allSongs: List<Song>,
    personalMix: List<Song>,
    mixUsesFavorites: Boolean,
    playlists: List<MusicPlaylist>,
    songsById: Map<Long, Song>,
    onPlay: (Song, List<Song>) -> Unit,
    onOpenAll: () -> Unit,
    onOpenLibrary: () -> Unit,
    onOpenPlaylist: (MusicPlaylist) -> Unit
) {
    val featured = personalMix.firstOrNull() ?: songs.firstOrNull()
    val displaySongs = songs.take(4)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 12.dp)) {
        Row(Modifier.fillMaxWidth().padding(start = 22.dp, end = 22.dp, top = 18.dp, bottom = 9.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Vuelve a escuchar", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = onOpenAll, contentPadding = PaddingValues(horizontal = 2.dp)) { Text("Ver todo  ›", color = Lime, fontSize = 12.sp) }
        }
        if (displaySongs.isEmpty()) {
            EmptyState("Tu música te espera", "Añade archivos al teléfono y actualiza la biblioteca para empezar.", null, {})
        } else {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                displaySongs.forEach { song ->
                    Column(Modifier.width(84.dp).clickable { onPlay(song, allSongs) }) {
                        AlbumArtwork(song, Modifier.size(84.dp).clip(RoundedCornerShape(13.dp)), 30.dp)
                        Spacer(Modifier.height(7.dp))
                        Text(song.title, color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(song.artist, color = TextMuted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(start = 22.dp, end = 22.dp, top = 23.dp, bottom = 11.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Hecho para ti", color = TextMain, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("Mix personal", color = TextMuted, fontSize = 11.sp)
        }
        if (featured != null) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp).clip(RoundedCornerShape(17.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF4F1E76), Color(0xFF17133C), Color(0xFF1C1431))))
                    .border(1.dp, NeonPink.copy(alpha = .22f), RoundedCornerShape(17.dp)).clickable { onPlay(featured, personalMix.ifEmpty { allSongs }) }.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AlbumArtwork(featured, Modifier.size(112.dp).clip(RoundedCornerShape(13.dp)), 34.dp, 320)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(featured.title, color = TextMain, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(4.dp))
                    Text(featured.artist, color = Color(0xFFD8C9E9), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (mixUsesFavorites) "Mix basado en tus favoritos"
                        else "Marca canciones con ♥ para personalizar este mix",
                        color = TextMuted, fontSize = 10.sp, maxLines = 2
                    )
                    Spacer(Modifier.height(9.dp))
                    Box(Modifier.clip(RoundedCornerShape(30.dp)).background(Brush.horizontalGradient(listOf(NeonPink, NeonViolet))).clickable { onPlay(featured, personalMix.ifEmpty { allSongs }) }.padding(horizontal = 18.dp, vertical = 8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Reproducir", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(start = 22.dp, end = 22.dp, top = 23.dp, bottom = 11.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Listas por estado de ánimo", color = TextMain, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = onOpenAll, contentPadding = PaddingValues(horizontal = 2.dp)) { Text("Ver todo  ›", color = Lime, fontSize = 12.sp) }
        }
        val moodItems = playlists.take(4)
        if (moodItems.isNotEmpty()) {
            moodItems.chunked(2).forEach { rowItems ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    rowItems.forEach { playlist ->
                        val coverSong = playlist.songIds.firstNotNullOfOrNull { songsById[it] }
                        Row(Modifier.weight(1f).height(84.dp).clip(RoundedCornerShape(13.dp)).background(SurfaceDark).clickable { onOpenPlaylist(playlist) }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (coverSong != null) AlbumArtwork(coverSong, Modifier.size(62.dp).clip(RoundedCornerShape(9.dp)), 22.dp)
                            else Box(Modifier.size(62.dp).clip(RoundedCornerShape(9.dp)).background(Brush.linearGradient(listOf(NeonViolet, NeonPink))), contentAlignment = Alignment.Center) { Icon(Icons.Default.QueueMusic, null, tint = Color.White) }
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(playlist.name, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(songsLabel(playlist.songIds.size), color = TextMuted, fontSize = 9.sp)
                            }
                        }
                    }
                    if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("Chill", "Focus").forEachIndexed { index, label ->
                    val song = displaySongs.getOrNull(index)
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(13.dp)).background(SurfaceDark).clickable { if (song != null) onPlay(song, allSongs) else onOpenLibrary() }.padding(9.dp)) {
                        if (song != null) AlbumArtwork(song, Modifier.fillMaxWidth().height(96.dp).clip(RoundedCornerShape(9.dp)), 28.dp)
                        else Box(Modifier.fillMaxWidth().height(96.dp).clip(RoundedCornerShape(9.dp)).background(Brush.linearGradient(listOf(NeonViolet, NeonPink))), contentAlignment = Alignment.Center) { Icon(Icons.Default.GraphicEq, null, tint = Color.White, modifier = Modifier.size(34.dp)) }
                        Spacer(Modifier.height(7.dp))
                        Text(label, color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Selección ẞeta", color = TextMuted, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfilePane(
    songCount: Int,
    favoritesCount: Int,
    playlistCount: Int,
    onFavorites: () -> Unit,
    onQueue: () -> Unit,
    onSettings: () -> Unit,
    onRefresh: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 12.dp)) {
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                .background(Brush.linearGradient(listOf(Lime.copy(alpha = .22f), Color(0xFF202038), Color(0xFF151421))))
                .border(1.dp, Color.White.copy(alpha = .12f), RoundedCornerShape(28.dp))
                .padding(horizontal = 18.dp, vertical = 20.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(76.dp).clip(CircleShape)
                            .background(Brush.linearGradient(listOf(Color.White.copy(alpha = .23f), Lime.copy(alpha = .48f), NeonViolet.copy(alpha = .65f))))
                            .border(1.5.dp, Color.White.copy(alpha = .35f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Person, null, tint = Color.White, modifier = Modifier.size(40.dp))
                    }
                    Spacer(Modifier.width(15.dp))
                    Column(Modifier.weight(1f)) {
                        Text("TU CUENTA", color = Lime, fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.8.sp)
                        Spacer(Modifier.height(4.dp))
                        Text("Tu espacio", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = (-.6).sp)
                        Text("Tu música, a tu manera", color = TextMuted, fontSize = 12.sp)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = TextMuted, modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.height(20.dp))
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                        .background(Color.Black.copy(alpha = .20f))
                        .padding(vertical = 13.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    ProfileStat("Canciones", songCount.toString(), Icons.Default.LibraryMusic, Modifier.weight(1f))
                    Box(Modifier.width(1.dp).height(38.dp).background(Color.White.copy(alpha = .10f)))
                    ProfileStat("Favoritos", favoritesCount.toString(), Icons.Default.Favorite, Modifier.weight(1f))
                    Box(Modifier.width(1.dp).height(38.dp).background(Color.White.copy(alpha = .10f)))
                    ProfileStat("Listas", playlistCount.toString(), Icons.Default.QueueMusic, Modifier.weight(1f))
                }
            }
        }
        Spacer(Modifier.height(25.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Tu biblioteca", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("ẞetaMusic", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.height(9.dp))
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                .background(Color.White.copy(alpha = .045f))
                .border(1.dp, Color.White.copy(alpha = .09f), RoundedCornerShape(22.dp))
                .padding(horizontal = 12.dp, vertical = 3.dp)
        ) {
            ProfileAction(Icons.Default.FavoriteBorder, "Tus favoritos", "$favoritesCount canciones guardadas", onFavorites, Color(0xFFFF6B91))
            HorizontalDivider(Modifier.padding(start = 54.dp), color = Color.White.copy(alpha = .075f))
            ProfileAction(Icons.Default.QueueMusic, "Cola de reproducción", "Gestiona lo que sonará después", onQueue, Color(0xFF8D8BFF))
            HorizontalDivider(Modifier.padding(start = 54.dp), color = Color.White.copy(alpha = .075f))
            ProfileAction(Icons.Default.Refresh, "Actualizar biblioteca", "Volver a buscar archivos locales", onRefresh, Color(0xFF65DCC4))
        }
        Spacer(Modifier.height(22.dp))
        Text("Personalización", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(9.dp))
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                .background(Color.White.copy(alpha = .045f))
                .border(1.dp, Color.White.copy(alpha = .09f), RoundedCornerShape(22.dp))
                .padding(horizontal = 12.dp, vertical = 3.dp)
        ) {
            ProfileAction(Icons.Default.Palette, "Apariencia y ajustes", "Colores, efectos y pestañas visibles", onSettings, Lime)
        }
        Spacer(Modifier.height(22.dp))
        Text("Diseñado para tu música", color = TextMuted, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun ProfileStat(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = Lime, modifier = Modifier.size(17.dp))
        Spacer(Modifier.height(5.dp))
        Text(value, color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Black)
        Text(label, color = TextMuted, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun ProfileAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    tint: Color = Lime
) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).clickable(onClick = onClick)
            .padding(horizontal = 3.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(40.dp).clip(RoundedCornerShape(13.dp))
                .background(Brush.linearGradient(listOf(tint.copy(alpha = .26f), tint.copy(alpha = .09f))))
                .border(1.dp, tint.copy(alpha = .16f), RoundedCornerShape(13.dp)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = tint, modifier = Modifier.size(20.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = TextMain, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(3.dp))
            Text(subtitle, color = TextMuted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Default.ChevronRight, null, tint = TextMuted.copy(alpha = .75f), modifier = Modifier.size(21.dp))
    }
}

private fun buildPersonalMix(songs: List<Song>, favorites: Set<Long>, current: Song?): List<Song> {
    if (songs.isEmpty()) return emptyList()
    val likedSongs = songs.filter { it.id in favorites }
    val seeds = likedSongs.ifEmpty { listOfNotNull(current) }
    val artists = seeds.map { it.artist.trim().lowercase(Locale.ROOT) }.filter { it.isNotBlank() }.groupingBy { it }.eachCount()
    val albums = seeds.map { it.album.trim().lowercase(Locale.ROOT) }.filter { it.isNotBlank() }.groupingBy { it }.eachCount()
    val currentArtist = current?.artist?.trim()?.lowercase(Locale.ROOT)
    val currentAlbum = current?.album?.trim()?.lowercase(Locale.ROOT)
    return songs.sortedWith(
        compareByDescending<Song> { song ->
            val artist = song.artist.trim().lowercase(Locale.ROOT)
            val album = song.album.trim().lowercase(Locale.ROOT)
            (if (song.id in favorites) 1000 else 0) +
                (if (song.id == current?.id) 100 else 0) +
                (artists[artist] ?: 0) * 35 +
                (albums[album] ?: 0) * 16 +
                (if (artist.isNotBlank() && artist == currentArtist) 22 else 0) +
                (if (album.isNotBlank() && album == currentAlbum) 10 else 0)
        }.thenBy { song -> song.title.lowercase(Locale.ROOT) }
    )
}

private fun songMatches(song: Song, query: String): Boolean =
    query.isBlank() || listOf(song.title, song.artist, song.album, song.folder).any { it.contains(query, true) }

private fun songsLabel(n: Int) = if (n == 1) "1 canción" else "$n canciones"

private fun buildGroups(songs: List<Song>, tab: String): List<LibraryGroup> {
    val byTitle = compareBy<Song> { it.title.lowercase(Locale.getDefault()) }
    val grouped: List<LibraryGroup> = when (tab) {
        "Artistas" -> songs.groupBy { it.artist }.map { (name, list) ->
            val tracks = list.sortedWith(byTitle)
            LibraryGroup("artist:$name", name, songsLabel(tracks.size), tracks)
        }
        "Álbumes" -> songs.groupBy { "${it.albumId}:${it.album}" }.map { (key, list) ->
            val tracks = list.sortedWith(byTitle)
            val first = tracks.first()
            LibraryGroup("album:$key", first.album, "${first.artist} · ${songsLabel(tracks.size)}", tracks)
        }
        "Carpetas" -> songs.groupBy { it.folder }.map { (folder, list) ->
            val tracks = list.sortedWith(byTitle)
            LibraryGroup(
                "folder:$folder",
                folder.substringAfterLast('/').ifBlank { "Almacenamiento" },
                songsLabel(tracks.size),
                tracks
            )
        }
        else -> emptyList()
    }
    return grouped.sortedBy { it.title.lowercase(Locale.getDefault()) }
}

// ───────────────────────────── Componentes ─────────────────────────────
@Composable
private fun TopHeader(onSearch: () -> Unit, onProfile: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(start = 19.dp, end = 17.dp, top = 9.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(30.dp).clip(RoundedCornerShape(10.dp)).background(Brush.linearGradient(listOf(NeonPink, NeonViolet))), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.GraphicEq, null, tint = Color.White, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(8.dp))
        Text("ẞetaMusic", color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Black, letterSpacing = (-.8).sp)
        Spacer(Modifier.weight(1f))
        Box(Modifier.size(39.dp).clip(CircleShape).background(SurfaceDark).clickable(onClick = onSearch), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Search, "Buscar", tint = TextMain, modifier = Modifier.size(21.dp))
        }
        Spacer(Modifier.width(10.dp))
        Box(Modifier.size(36.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF5A286E), Color(0xFF32245F)))).border(1.dp, NeonPink.copy(alpha = .45f), CircleShape).clickable(onClick = onProfile), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Person, "Perfil", tint = Color(0xFFF7D9EE), modifier = Modifier.size(21.dp))
        }
    }
}

@Composable
private fun SearchField(query: String, animated: Boolean = true, onChange: (String) -> Unit) {
    val rotation = if (animated) {
        val transition = rememberInfiniteTransition(label = "searchGlow")
        val angle by transition.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(animation = tween(durationMillis = 3400, easing = LinearEasing)),
            label = "searchGlowRotation"
        )
        angle
    } else 0f
    val shape = RoundedCornerShape(15.dp)
    val animatedRing = if (animated) {
        Modifier.drawWithContent {
            drawContent()
            rotate(rotation, pivot = center) {
                drawRoundRect(
                    brush = Brush.sweepGradient(listOf(Color.Transparent, NeonViolet, NeonPink, Lime, Color.White.copy(alpha = .92f), Color.Transparent)),
                    topLeft = Offset(0.8.dp.toPx(), 0.8.dp.toPx()),
                    size = androidx.compose.ui.geometry.Size(size.width - 1.6.dp.toPx(), size.height - 1.6.dp.toPx()),
                    cornerRadius = CornerRadius(15.dp.toPx()),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.05.dp.toPx())
                )
            }
        }
    } else {
        Modifier.border(1.dp, NeonViolet.copy(alpha = .24f), shape)
    }
    Row(
        Modifier.padding(horizontal = 18.dp).fillMaxWidth().height(45.dp)
            .clip(shape).background(SurfaceDark).then(animatedRing).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Search, null, tint = TextMuted, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        BasicTextField(
            value = query,
            onValueChange = onChange,
            modifier = Modifier.weight(1f).fillMaxHeight(),
            textStyle = TextStyle(color = TextMain, fontSize = 13.sp),
            cursorBrush = SolidColor(Lime),
            singleLine = true,
            decorationBox = { innerTextField ->
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.CenterStart) {
                    if (query.isEmpty()) Text("Canciones, artistas, álbumes", color = TextMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    innerTextField()
                }
            }
        )
        if (query.isNotEmpty()) {
            IconButton(onClick = { onChange("") }, modifier = Modifier.size(30.dp)) {
                Icon(Icons.Default.Close, "Limpiar búsqueda", tint = TextMuted, modifier = Modifier.size(17.dp))
            }
        }
    }
}

@Composable
private fun LibraryTabs(
    selectedTab: String,
    visibleTabs: List<String>,
    onSelect: (String) -> Unit,
    sortMode: String,
    onSortSelect: (String) -> Unit
) {
    Row(
        Modifier.fillMaxWidth().padding(start = 12.dp, end = 8.dp, top = 1.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            Modifier.weight(1f).horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            visibleTabs.forEach { item ->
                val selected = selectedTab == item
                Column(
                    Modifier.widthIn(min = 58.dp).clip(RoundedCornerShape(12.dp))
                        .clickable(role = Role.Tab) { onSelect(item) }
                        .padding(horizontal = 7.dp, vertical = 9.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(item, color = if (selected) TextMain else TextMuted, fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(7.dp))
                    Box(Modifier.width(if (selected) 27.dp else 0.dp).height(3.dp).clip(RoundedCornerShape(5.dp)).background(Brush.horizontalGradient(listOf(NeonPink, NeonViolet))))
                }
            }
        }
        var expanded by remember { mutableStateOf(false) }
        Box {
            IconButton(
                onClick = { expanded = true },
                modifier = Modifier.size(40.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Color.White.copy(alpha = .10f), Color.White.copy(alpha = .035f))))
                    .border(1.dp, Color.White.copy(alpha = .12f), CircleShape)
            ) { Icon(Icons.Default.MoreVert, "Opciones de biblioteca", tint = TextMain, modifier = Modifier.size(20.dp)) }
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
                modifier = Modifier.widthIn(min = 238.dp).clip(RoundedCornerShape(20.dp))
                    .background(Brush.linearGradient(listOf(Color(0xF522202D), Color(0xF5151420))))
                    .border(1.dp, Color.White.copy(alpha = .13f), RoundedCornerShape(20.dp)),
                containerColor = Color(0xF5191724),
                tonalElevation = 0.dp,
                shadowElevation = 18.dp
            ) {
                Text("ORDENAR CANCIONES", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, modifier = Modifier.padding(start = 16.dp, top = 13.dp, bottom = 6.dp))
                songSortOptions.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option, color = if (option == sortMode) Lime else TextMain, fontSize = 13.sp, fontWeight = if (option == sortMode) FontWeight.Bold else FontWeight.Normal) },
                        leadingIcon = { Icon(if (option == sortMode) Icons.Default.CheckCircle else Icons.Default.Circle, null, tint = if (option == sortMode) Lime else TextMuted.copy(alpha = .55f), modifier = Modifier.size(17.dp)) },
                        onClick = { onSortSelect(option); expanded = false },
                        modifier = Modifier.padding(horizontal = 5.dp).clip(RoundedCornerShape(12.dp))
                    )
                }
            }
        }
    }
}

@Composable
private fun SortModeRow(
    sortMode: String,
    title: String = "Canciones",
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().padding(start = 20.dp, end = 14.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = TextMain, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Box {
            Row(
                Modifier.clip(RoundedCornerShape(22.dp))
                    .background(Brush.linearGradient(listOf(Color.White.copy(alpha = .10f), Color.White.copy(alpha = .035f))))
                    .border(1.dp, Color.White.copy(alpha = .12f), RoundedCornerShape(22.dp))
                    .clickable { expanded = true }.padding(horizontal = 11.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Sort, null, tint = Lime, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Ordenar", color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.width(2.dp))
                Icon(Icons.Default.ExpandMore, null, tint = TextMuted, modifier = Modifier.size(16.dp))
            }
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
                modifier = Modifier.widthIn(min = 235.dp).clip(RoundedCornerShape(20.dp))
                    .border(1.dp, Color.White.copy(alpha = .13f), RoundedCornerShape(20.dp)),
                containerColor = Color(0xF5191724),
                tonalElevation = 0.dp,
                shadowElevation = 18.dp
            ) {
                Text("ORDEN DE LA BIBLIOTECA", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp, modifier = Modifier.padding(start = 16.dp, top = 13.dp, bottom = 6.dp))
                songSortOptions.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option, color = if (option == sortMode) Lime else TextMain, fontSize = 13.sp) },
                        leadingIcon = { Icon(if (option == sortMode) Icons.Default.CheckCircle else Icons.Default.Circle, null, tint = if (option == sortMode) Lime else TextMuted.copy(alpha = .55f), modifier = Modifier.size(17.dp)) },
                        onClick = { onSelect(option); expanded = false },
                        modifier = Modifier.padding(horizontal = 5.dp).clip(RoundedCornerShape(12.dp))
                    )
                }
            }
        }
    }
}

@Composable
private fun CountHeader(overline: String, count: String) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 14.dp)) {
        Text(overline, color = TextMuted, fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
        Text(count, color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SongList(
    songs: List<Song>,
    currentId: Long?,
    isPlaying: Boolean,
    favorites: Set<Long>,
    onPlay: (Song) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    modifier: Modifier = Modifier
) {
    var menuSongId by remember { mutableStateOf<Long?>(null) }
    LazyColumn(
        modifier,
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        items(songs, key = { it.id }) { song ->
            val active = song.id == currentId
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                    .background(if (active) SurfaceLight else Color.Transparent)
                    .clickable { onPlay(song) }
                    .padding(start = 10.dp, top = 7.dp, bottom = 7.dp, end = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AlbumArtwork(song, Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)), 23.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(song.title, color = if (active) Lime else TextMain, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                    Spacer(Modifier.height(3.dp))
                    Text("${song.artist} · ${song.album}", color = TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
                }
                if (active && isPlaying) {
                    Icon(Icons.Default.GraphicEq, "Sonando", tint = Lime, modifier = Modifier.padding(horizontal = 4.dp).size(18.dp))
                }
                Text(formatTime(song.durationMs), color = TextMuted, fontSize = 11.sp)
                IconButton(onClick = { onToggleFavorite(song) }) {
                    val fav = song.id in favorites
                    Icon(
                        if (fav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        if (fav) "Quitar de favoritos" else "Añadir a favoritos",
                        tint = if (fav) Lime else TextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Box {
                    IconButton(onClick = { menuSongId = if (menuSongId == song.id) null else song.id }, modifier = Modifier.size(38.dp)) {
                        Icon(Icons.Default.MoreVert, "Opciones de ${song.title}", tint = TextMuted, modifier = Modifier.size(20.dp))
                    }
                    DropdownMenu(
                        expanded = menuSongId == song.id,
                        onDismissRequest = { menuSongId = null },
                        modifier = Modifier.widthIn(min = 220.dp).clip(RoundedCornerShape(20.dp))
                            .border(1.dp, Color.White.copy(alpha = .14f), RoundedCornerShape(20.dp)),
                        containerColor = Color(0xF51A1825),
                        tonalElevation = 0.dp,
                        shadowElevation = 20.dp
                    ) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            AlbumArtwork(song, Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)), 18.dp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(song.title, color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(song.artist, color = TextMuted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        HorizontalDivider(color = Color.White.copy(alpha = .08f))
                        DropdownMenuItem(
                            text = { Text("Reproducir ahora", color = TextMain, fontSize = 13.sp) },
                            leadingIcon = { Icon(Icons.Default.PlayArrow, null, tint = Lime) },
                            onClick = { menuSongId = null; onPlay(song) },
                            modifier = Modifier.padding(horizontal = 5.dp).clip(RoundedCornerShape(12.dp))
                        )
                        DropdownMenuItem(
                            text = { Text(if (song.id in favorites) "Quitar de favoritos" else "Añadir a favoritos", color = TextMain, fontSize = 13.sp) },
                            leadingIcon = { Icon(if (song.id in favorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (song.id in favorites) Lime else TextMuted) },
                            onClick = { menuSongId = null; onToggleFavorite(song) },
                            modifier = Modifier.padding(horizontal = 5.dp).clip(RoundedCornerShape(12.dp))
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GroupList(groups: List<LibraryGroup>, onOpen: (LibraryGroup) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(
        modifier,
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        items(groups, key = { it.id }) { group ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp))
                    .background(SurfaceDark).clickable { onOpen(group) }
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AlbumArtwork(group.coverSong, Modifier.size(58.dp).clip(RoundedCornerShape(12.dp)), 25.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(group.title, color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(4.dp))
                    Text(group.subtitle, color = TextMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Icon(Icons.Default.ChevronRight, null, tint = Lime)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun QueuePane(ui: UiState, songsById: Map<Long, Song>, a: UiActions) {
    val entries = remember(ui.queueVersion, songsById) { a.readQueue(songsById) }
    var orderedEntries by remember { mutableStateOf(entries) }
    var draggedSongId by remember { mutableStateOf<Long?>(null) }
    var dragOffset by remember { mutableFloatStateOf(0f) }
    val listState = rememberLazyListState()
    val rowHeightPx = with(LocalDensity.current) { 70.dp.toPx() }
    LaunchedEffect(entries) {
        if (draggedSongId == null) orderedEntries = entries
    }
    LaunchedEffect(entries.size) {
        val idx = entries.indexOfFirst { it.song.id == ui.currentId }
        if (idx > 0) listState.scrollToItem(idx)
    }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(if (ui.shuffle) "COLA DE REPRODUCCIÓN" else "ORDEN DE REPRODUCCIÓN", color = TextMuted, fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
                Text(songsLabel(entries.size), color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            Text("Mantén y arrastra para ordenar", color = TextMuted, fontSize = 10.sp)
        }
        if (orderedEntries.isEmpty()) {
            EmptyState(
                title = "La cola está vacía",
                message = "Toca una canción de tu biblioteca para empezar a reproducir.",
                action = null,
                onAction = {}
            )
        } else {
            LazyColumn(
                Modifier.weight(1f),
                state = listState,
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(orderedEntries, key = { it.song.id }) { entry ->
                    val active = entry.song.id == ui.currentId
                    val isDragging = draggedSongId == entry.song.id
                    Row(
                        Modifier.fillMaxWidth()
                            .animateItemPlacement()
                            .offset { IntOffset(0, if (isDragging) dragOffset.roundToInt() else 0) }
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                if (isDragging) Brush.linearGradient(listOf(Lime.copy(alpha = .22f), SurfaceLight.copy(alpha = .95f)))
                                else Brush.linearGradient(listOf((if (active) Lime else Color.White).copy(alpha = if (active) .11f else .045f), Color.White.copy(alpha = .018f)))
                            )
                            .border(if (isDragging) 1.3.dp else .7.dp, if (isDragging) Lime.copy(alpha = .85f) else Color.White.copy(alpha = .07f), RoundedCornerShape(16.dp))
                            .pointerInput(entry.song.id) {
                                detectDragGestures(
                                    onDragStart = {
                                        draggedSongId = entry.song.id
                                        dragOffset = 0f
                                    },
                                    onDragEnd = {
                                        val originalIndex = entries.indexOfFirst { it.song.id == entry.song.id }
                                        val destinationIndex = orderedEntries.indexOfFirst { it.song.id == entry.song.id }
                                        if (originalIndex >= 0 && destinationIndex >= 0 && originalIndex != destinationIndex) {
                                            a.moveQueueItem(originalIndex, destinationIndex)
                                        }
                                        draggedSongId = null
                                        dragOffset = 0f
                                    },
                                    onDragCancel = {
                                        draggedSongId = null
                                        dragOffset = 0f
                                        orderedEntries = entries
                                    },
                                    onDrag = { change, amount ->
                                        change.consume()
                                        if (draggedSongId == entry.song.id) {
                                            dragOffset += amount.y
                                            while (dragOffset > rowHeightPx) {
                                                val idx = orderedEntries.indexOfFirst { it.song.id == entry.song.id }
                                                if (idx < 0 || idx >= orderedEntries.lastIndex) break
                                                orderedEntries = orderedEntries.toMutableList().apply { add(idx + 1, removeAt(idx)) }
                                                dragOffset -= rowHeightPx
                                            }
                                            while (dragOffset < -rowHeightPx) {
                                                val idx = orderedEntries.indexOfFirst { it.song.id == entry.song.id }
                                                if (idx <= 0) break
                                                orderedEntries = orderedEntries.toMutableList().apply { add(idx - 1, removeAt(idx)) }
                                                dragOffset += rowHeightPx
                                            }
                                        }
                                    }
                                )
                            }
                            .clickable { if (draggedSongId == null) a.playQueueItem(entry.index) }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AlbumArtwork(entry.song, Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)), 20.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(entry.song.title, color = if (active) Lime else TextMain, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                            Text(entry.song.artist, color = TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
                        }
                        if (active) Icon(Icons.Default.GraphicEq, "Sonando ahora", tint = Lime, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(7.dp))
                        Icon(Icons.Default.DragHandle, "Arrastrar para reordenar", tint = if (isDragging) Lime else TextMuted.copy(alpha = .7f), modifier = Modifier.size(22.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomBar(section: String, onSelect: (String) -> Unit) {
    val selectedDestination = when (section) {
        SECTION_HOME -> SECTION_HOME
        SECTION_SEARCH -> SECTION_SEARCH
        SECTION_LIBRARY, SECTION_PLAYLISTS -> SECTION_LIBRARY
        else -> SECTION_PROFILE
    }
    Row(
        Modifier.fillMaxWidth().background(Bg).border(width = 0.5.dp, color = Color.White.copy(alpha = .05f)).padding(horizontal = 7.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        listOf(
            Triple(SECTION_HOME, Icons.Default.Home, "Inicio"),
            Triple(SECTION_SEARCH, Icons.Default.Search, "Songs"),
            Triple(SECTION_LIBRARY, Icons.Default.Equalizer, "Biblioteca"),
            Triple(SECTION_PROFILE, Icons.Default.Person, "Perfil")
        ).forEach { (id, icon, label) ->
            val selected = selectedDestination == id
            val navTint by animateColorAsState(
                targetValue = if (selected) Lime else TextMuted,
                animationSpec = tween(durationMillis = 180),
                label = "navTint_$id"
            )
            val markerWidth by animateDpAsState(
                targetValue = if (selected) 17.dp else 0.dp,
                animationSpec = tween(durationMillis = 220),
                label = "navMarker_$id"
            )
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable { onSelect(id) }.padding(top = 5.dp, bottom = 3.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(icon, contentDescription = label, tint = navTint, modifier = Modifier.size(23.dp))
                Spacer(Modifier.height(3.dp))
                Text(label, color = navTint, fontSize = 9.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                Spacer(Modifier.height(4.dp))
                Box(Modifier.width(markerWidth).height(2.dp).clip(CircleShape).background(Brush.horizontalGradient(listOf(NeonPink, NeonViolet))))
            }
        }
    }
}

// ───────────────────────────── Portadas ─────────────────────────────
private object ArtCache {
    private val cache = object : LruCache<Long, Bitmap>(((Runtime.getRuntime().maxMemory() / 1024) / 12).toInt()) {
        override fun sizeOf(key: Long, value: Bitmap): Int = value.byteCount / 1024
    }
    private val withoutArt: MutableSet<Long> = ConcurrentHashMap.newKeySet()

    private fun key(song: Song, px: Int): Long = song.id or (px.toLong() shl 40)

    fun get(song: Song, px: Int): Bitmap? = cache.get(key(song, px))
    fun put(song: Song, px: Int, bitmap: Bitmap) { cache.put(key(song, px), bitmap) }
    fun hasNoArt(song: Song): Boolean = song.id in withoutArt
    fun markNoArt(song: Song) { withoutArt.add(song.id) }
}

@RequiresApi(29)
private fun loadThumbnail(resolver: ContentResolver, uri: Uri, px: Int): Bitmap? =
    runCatching { resolver.loadThumbnail(uri, Size(px, px), null) }.getOrNull()

@Composable
private fun AlbumArtwork(song: Song?, modifier: Modifier = Modifier, iconSize: Dp = 28.dp, px: Int = 256) {
    val context = LocalContext.current
    val bitmap by produceState<Bitmap?>(
        song?.let { ArtCache.get(it, px) },
        song?.id,
        px
    ) {
        val s = song
        if (s == null || Build.VERSION.SDK_INT < 29) {
            value = null
            return@produceState
        }
        val cached = ArtCache.get(s, px)
        if (cached != null) {
            value = cached
            return@produceState
        }
        if (!ArtCache.hasNoArt(s)) {
            val bmp = withContext(Dispatchers.IO) { loadThumbnail(context.contentResolver, s.uri, px) }
            if (bmp != null) {
                ArtCache.put(s, px, bmp)
                value = bmp
            } else {
                ArtCache.markNoArt(s)
            }
        }
    }
    // En Android 8 y 9 se usa el proveedor clásico de carátulas de álbum.
    val legacyUri = remember(song?.albumId) {
        if (Build.VERSION.SDK_INT < 29) {
            song?.albumId?.takeIf { it > 0 }?.let { ContentUris.withAppendedId(ArtBase, it) }
        } else null
    }
    Box(modifier.background(SurfaceDark), contentAlignment = Alignment.Center) {
        Icon(Icons.Default.Album, contentDescription = null, tint = Lime, modifier = Modifier.size(iconSize))
        val bmp = bitmap
        if (bmp != null) {
            BitmapImage(
                bitmap = bmp.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else if (legacyUri != null) {
            AsyncImage(
                model = legacyUri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

// ───────────────────────────── Reproductor ─────────────────────────────
@Composable
private fun MiniPlayer(
    song: Song,
    isPlaying: Boolean,
    position: () -> Long,
    duration: Long,
    onOpen: () -> Unit,
    onPrevious: () -> Unit,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit
) {
    val fraction = if (duration > 0) (position().toFloat() / duration).coerceIn(0f, 1f) else 0f
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp)
            .clip(RoundedCornerShape(17.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF24152F), Color(0xFF17152B), Color(0xFF1B153A))))
            .border(1.dp, Brush.horizontalGradient(listOf(NeonPink.copy(alpha = .48f), NeonViolet.copy(alpha = .48f))), RoundedCornerShape(17.dp))
    ) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(start = 8.dp, top = 7.dp, end = 7.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AlbumArtwork(song, Modifier.size(43.dp).clip(RoundedCornerShape(9.dp)), 20.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(song.title, color = TextMain, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
                Text(song.artist, color = TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 10.sp)
            }
            IconButton(onClick = onTogglePlay, modifier = Modifier.size(40.dp)) {
                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, if (isPlaying) "Pausar" else "Reproducir", tint = Color.White, modifier = Modifier.size(25.dp))
            }
            IconButton(onClick = onOpen, modifier = Modifier.size(33.dp)) {
                Icon(Icons.Default.KeyboardArrowUp, "Abrir reproductor", tint = TextMuted, modifier = Modifier.size(22.dp))
            }
        }
        Canvas(Modifier.fillMaxWidth().height(2.dp)) {
            drawLine(SurfaceLight, Offset(0f, size.height / 2), Offset(size.width, size.height / 2), size.height)
            val endX = size.width * fraction
            if (endX > 0f) drawLine(Brush.horizontalGradient(listOf(NeonPink, NeonViolet)), Offset(0f, size.height / 2), Offset(endX, size.height / 2), size.height)
        }
    }
}

@Composable
private fun ProgressSection(position: () -> Long, duration: Long, onSeek: (Long) -> Unit, accent: Color = Lime) {
    var dragValue by remember { mutableStateOf<Float?>(null) }
    val current = position().coerceIn(0L, duration.coerceAtLeast(0L)).toFloat()
    val shown = (dragValue ?: current).coerceIn(0f, duration.coerceAtLeast(0L).toFloat())
    Column(Modifier.fillMaxWidth()) {
        Canvas(
            Modifier.fillMaxWidth().height(32.dp)
                .pointerInput(duration) {
                    detectTapGestures { offset ->
                        if (duration > 0 && size.width > 0) {
                            onSeek((duration * (offset.x / size.width.toFloat()).coerceIn(0f, 1f)).toLong())
                        }
                    }
                }
                .pointerInput(duration) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            if (duration > 0 && size.width > 0) dragValue = duration * (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                        },
                        onDragEnd = {
                            dragValue?.let { onSeek(it.toLong()) }
                            dragValue = null
                        },
                        onDragCancel = { dragValue = null }
                    ) { change, _ ->
                        change.consume()
                        if (duration > 0 && size.width > 0) dragValue = duration * (change.position.x / size.width.toFloat()).coerceIn(0f, 1f)
                    }
                }
        ) {
            val centerY = size.height / 2f
            val barHeight = 7.dp.toPx()
            val fraction = if (duration > 0L) (shown / duration.toFloat()).coerceIn(0f, 1f) else 0f
            val endX = size.width * fraction
            drawLine(SurfaceLight, Offset(0f, centerY), Offset(size.width, centerY), barHeight, cap = StrokeCap.Round)
            if (endX > 0f) drawLine(Brush.horizontalGradient(listOf(accent, blendColors(accent, NeonViolet, 0.42f))), Offset(0f, centerY), Offset(endX, centerY), barHeight, cap = StrokeCap.Round)
            drawCircle(accent.copy(alpha = 0.20f), radius = 12.dp.toPx(), center = Offset(endX, centerY))
            drawCircle(accent, radius = 7.dp.toPx(), center = Offset(endX, centerY))
            drawCircle(Color.White, radius = 2.3.dp.toPx(), center = Offset(endX, centerY))
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(shown.toLong()), color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            Text(formatTime(duration), color = TextMuted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun NowPlayingScreen(
    song: Song,
    isPlaying: Boolean,
    isFavorite: Boolean,
    shuffle: Boolean,
    repeatMode: Int,
    position: () -> Long,
    duration: Long,
    onBack: () -> Unit,
    onTogglePlay: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onSeek: (Long) -> Unit,
    onToggleFavorite: () -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onOpenQueue: () -> Unit,
    onOpenPlaylists: () -> Unit,
    dynamicColors: Boolean,
    blurBackground: Boolean
) {
    val context = LocalContext.current
    val dominantAccent by rememberDominantCoverColor(song)
    val playerAccent = if (dynamicColors) dominantAccent else Lime
    BoxWithConstraints(Modifier.fillMaxSize().background(Bg)) {
        if (blurBackground) {
            AlbumArtwork(song, Modifier.matchParentSize().blur(34.dp).alpha(0.52f), iconSize = 1.dp, px = 320)
            Box(Modifier.matchParentSize().background(Brush.verticalGradient(listOf(Bg.copy(alpha = 0.20f), Bg.copy(alpha = 0.62f), Bg.copy(alpha = 0.96f)))))
        } else {
            CoverGradientBackground(song, Modifier.matchParentSize())
        }
        val cover = minOf(maxWidth - 52.dp, maxOf(210.dp, maxHeight * 0.43f), 350.dp)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 5.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth().height(43.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Default.KeyboardArrowDown, "Cerrar reproductor", tint = TextMain, modifier = Modifier.size(28.dp))
                }
                Spacer(Modifier.weight(1f))
                Text("REPRODUCIENDO", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
                Spacer(Modifier.weight(1f))
                Spacer(Modifier.size(40.dp))
            }

            Spacer(Modifier.height(12.dp))
            AlbumArtwork(
                song = song,
                modifier = Modifier.size(cover).clip(RoundedCornerShape(24.dp)).border(1.dp, Color.White.copy(alpha = .08f), RoundedCornerShape(24.dp)),
                iconSize = 72.dp,
                px = 640
            )
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(song.title, color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis, letterSpacing = (-.25).sp)
                    Spacer(Modifier.height(4.dp))
                    Text(song.artist, color = TextMuted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = onToggleFavorite, modifier = Modifier.size(46.dp)) {
                    Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, if (isFavorite) "Quitar de favoritos" else "Añadir a favoritos", tint = if (isFavorite) playerAccent else TextMuted, modifier = Modifier.size(27.dp))
                }
            }
            Spacer(Modifier.height(14.dp))
            ProgressSection(position, duration, onSeek, playerAccent)
            Spacer(Modifier.height(12.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                GlassPlayerControl(
                    icon = Icons.Default.Shuffle,
                    description = if (shuffle) "Aleatorio activado" else "Aleatorio desactivado",
                    tint = if (shuffle) playerAccent else TextMuted,
                    size = 44.dp,
                    selected = shuffle,
                    accent = playerAccent,
                    onClick = onToggleShuffle
                )
                GlassPlayerControl(Icons.Default.SkipPrevious, "Anterior", TextMain, 52.dp, false, playerAccent, onPrevious, iconSize = 31.dp)
                Box(
                    Modifier.size(76.dp).clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Color.White.copy(alpha = .31f), playerAccent.copy(alpha = .96f), blendColors(playerAccent, NeonViolet, .58f), Color.White.copy(alpha = .12f))))
                        .border(1.5.dp, Color.White.copy(alpha = .48f), CircleShape)
                        .clickable(onClick = onTogglePlay),
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.align(Alignment.TopCenter).fillMaxWidth().height(27.dp).clip(RoundedCornerShape(topStart = 40.dp, topEnd = 40.dp)).background(Brush.verticalGradient(listOf(Color.White.copy(alpha = .24f), Color.Transparent))))
                    Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, if (isPlaying) "Pausar" else "Reproducir", tint = Color.White, modifier = Modifier.size(38.dp))
                }
                GlassPlayerControl(Icons.Default.SkipNext, "Siguiente", TextMain, 52.dp, false, playerAccent, onNext, iconSize = 31.dp)
                GlassPlayerControl(
                    icon = if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                    description = when (repeatMode) { Player.REPEAT_MODE_ONE -> "Repetir una canción"; Player.REPEAT_MODE_ALL -> "Repetir toda la cola"; else -> "Repetición desactivada" },
                    tint = if (repeatMode == Player.REPEAT_MODE_OFF) TextMuted else playerAccent,
                    size = 44.dp,
                    selected = repeatMode != Player.REPEAT_MODE_OFF,
                    accent = playerAccent,
                    onClick = onCycleRepeat
                )
            }
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth().padding(bottom = 7.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                PlayerAction(Icons.Default.FavoriteBorder, "Me gusta", onToggleFavorite, if (isFavorite) playerAccent else TextMuted)
                PlayerAction(Icons.Default.PlaylistAdd, "Añadir", onOpenPlaylists, TextMuted)
                PlayerAction(Icons.Default.Share, "Compartir", {
                    runCatching {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, song.title)
                            putExtra(Intent.EXTRA_TEXT, "${song.title} — ${song.artist}")
                        }
                        context.startActivity(Intent.createChooser(send, "Compartir canción"))
                    }
                }, TextMuted)
                PlayerAction(Icons.Default.QueueMusic, "Cola", onOpenQueue, TextMuted)
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun GlassPlayerControl(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    tint: Color,
    size: Dp,
    selected: Boolean,
    accent: Color,
    onClick: () -> Unit,
    iconSize: Dp = 21.dp
) {
    Box(
        Modifier.size(size).clip(CircleShape)
            .background(
                Brush.linearGradient(
                    listOf(
                        Color.White.copy(alpha = if (selected) .22f else .14f),
                        accent.copy(alpha = if (selected) .20f else .07f),
                        Color.White.copy(alpha = .025f)
                    )
                )
            )
            .border(1.dp, (if (selected) accent else Color.White).copy(alpha = if (selected) .64f else .22f), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.align(Alignment.TopCenter).fillMaxWidth().height(size * .42f).background(Brush.verticalGradient(listOf(Color.White.copy(alpha = .11f), Color.Transparent))))
        Icon(icon, description, tint = tint, modifier = Modifier.size(iconSize))
    }
}

@Composable
private fun PlayerAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit, tint: Color) {
    Column(Modifier.width(58.dp).clip(RoundedCornerShape(13.dp)).clickable(onClick = onClick).padding(vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(SurfaceDark.copy(alpha = .78f)), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(21.dp))
        }
        Spacer(Modifier.height(4.dp))
        Text(label, color = TextMuted, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun PlaylistsPane(
    playlists: List<MusicPlaylist>,
    songsById: Map<Long, Song>,
    onCreate: () -> Unit,
    onOpen: (MusicPlaylist) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("TU MÚSICA, A TU MANERA", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                Text("Listas de reproducción", color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("${playlists.size} listas guardadas", color = TextMuted, fontSize = 12.sp)
            }
            FilledTonalIconButton(onClick = onCreate, colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = Lime, contentColor = OnLime)) {
                Icon(Icons.Default.Add, "Crear lista")
            }
        }
        if (playlists.isEmpty()) {
            EmptyState(
                title = "Crea tu primera lista",
                message = "Agrupa las canciones que te gustan y reprodúcelas en el orden que prefieras.",
                action = "Crear lista",
                onAction = onCreate
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                items(playlists, key = { it.id }) { playlist ->
                    val firstSong = playlist.songIds.firstNotNullOfOrNull { id -> songsById[id] }
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(SurfaceDark)
                            .border(1.dp, Color.White.copy(alpha = .035f), RoundedCornerShape(15.dp)).clickable { onOpen(playlist) }.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (firstSong != null) {
                            AlbumArtwork(firstSong, Modifier.size(70.dp).clip(RoundedCornerShape(12.dp)), 26.dp)
                        } else {
                            Box(Modifier.size(70.dp).clip(RoundedCornerShape(12.dp)).background(SurfaceLight), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.QueueMusic, null, tint = Lime, modifier = Modifier.size(30.dp))
                            }
                        }
                        Spacer(Modifier.width(13.dp))
                        Column(Modifier.weight(1f)) {
                            Text(playlist.name, color = TextMain, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.height(4.dp))
                            Text(songsLabel(playlist.songIds.count { it in songsById }), color = TextMuted, fontSize = 12.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Lime)
                    }
                }
            }
        }
    }
}

@Composable
private fun PlaylistDetailPane(
    playlist: MusicPlaylist,
    songs: List<Song>,
    currentId: Long?,
    isPlaying: Boolean,
    onBack: () -> Unit,
    onAddSongs: () -> Unit,
    onPlay: (Song) -> Unit,
    onRemove: (Song) -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    var confirmDelete by remember(playlist.id) { mutableStateOf(false) }
    Column(modifier) {
        Row(
            Modifier.fillMaxWidth().padding(start = 8.dp, end = 12.dp, top = 6.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver a las listas", tint = Lime) }
            Column(Modifier.weight(1f)) {
                Text(playlist.name, color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(songsLabel(songs.size), color = TextMuted, fontSize = 12.sp)
            }
            IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Default.DeleteOutline, "Eliminar lista", tint = TextMuted) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = onAddSongs,
                colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = OnLime),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.PlaylistAdd, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(7.dp))
                Text("Añadir canciones", maxLines = 1)
            }
            FilledTonalIconButton(
                onClick = { songs.firstOrNull()?.let(onPlay) },
                enabled = songs.isNotEmpty(),
                colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = SurfaceLight, contentColor = Lime)
            ) { Icon(Icons.Default.PlayArrow, "Reproducir lista") }
        }
        if (songs.isEmpty()) {
            EmptyState(
                title = "Esta lista está vacía",
                message = "Añade canciones de tu biblioteca para crear tu propia selección.",
                action = "Añadir canciones",
                onAction = onAddSongs
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 14.dp, end = 12.dp, top = 8.dp, bottom = 14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(songs, key = { it.id }) { song ->
                    val active = song.id == currentId
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                            .background(if (active) SurfaceLight else Color.Transparent)
                            .clickable { onPlay(song) }.padding(start = 8.dp, end = 2.dp, top = 7.dp, bottom = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AlbumArtwork(song, Modifier.size(48.dp).clip(RoundedCornerShape(11.dp)), 22.dp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(song.title, color = if (active) Lime else TextMain, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(song.artist, color = TextMuted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (active && isPlaying) Icon(Icons.Default.GraphicEq, "Sonando", tint = Lime, modifier = Modifier.size(17.dp))
                        IconButton(onClick = { onRemove(song) }) { Icon(Icons.Default.Close, "Quitar de la lista", tint = TextMuted, modifier = Modifier.size(18.dp)) }
                    }
                }
            }
        }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("¿Eliminar esta lista?") },
            text = { Text("Se eliminará «${playlist.name}». Las canciones originales no se borrarán del teléfono.") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("Eliminar", color = Color(0xFFFF7777)) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar", color = TextMuted) } },
            containerColor = SurfaceDark,
            titleContentColor = TextMain,
            textContentColor = TextMuted
        )
    }
}

@Composable
private fun CreatePlaylistDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nueva lista de reproducción") },
        text = {
            Column {
                Text("Ponle un nombre a tu selección.", color = TextMuted, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(48) },
                    singleLine = true,
                    placeholder = { Text("Ej. Favoritas de noche") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Lime, focusedLabelColor = Lime, cursorColor = Lime)
                )
            }
        },
        confirmButton = { TextButton(onClick = { name.trim().takeIf { it.isNotEmpty() }?.let(onCreate) }, enabled = name.isNotBlank()) { Text("Crear", color = Lime) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar", color = TextMuted) } },
        containerColor = SurfaceDark,
        titleContentColor = TextMain,
        textContentColor = TextMuted
    )
}

@Composable
private fun AddSongsDialog(
    songs: List<Song>,
    selectedIds: Set<Long>,
    onDismiss: () -> Unit,
    onConfirm: (List<Long>) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    val selected = remember(selectedIds) { mutableStateOf(selectedIds.toMutableSet()) }
    val filtered = remember(songs, query) { songs.filter { songMatches(it, query) } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Añadir canciones") },
        text = {
            Column(Modifier.fillMaxWidth()) {
                TextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Buscar en la biblioteca", fontSize = 13.sp) },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = SurfaceLight,
                        unfocusedContainerColor = SurfaceLight,
                        focusedIndicatorColor = Lime,
                        unfocusedIndicatorColor = Color.Transparent,
                        cursorColor = Lime
                    )
                )
                Spacer(Modifier.height(8.dp))
                Text("${selected.value.size} seleccionadas", color = TextMuted, fontSize = 12.sp)
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 360.dp)) {
                    items(filtered, key = { it.id }) { song ->
                        val checked = song.id in selected.value
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                selected.value = selected.value.toMutableSet().apply {
                                    if (contains(song.id)) remove(song.id) else add(song.id)
                                }
                            }.padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AlbumArtwork(song, Modifier.size(38.dp).clip(RoundedCornerShape(8.dp)), 18.dp)
                            Spacer(Modifier.width(9.dp))
                            Column(Modifier.weight(1f)) {
                                Text(song.title, color = TextMain, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(song.artist, color = TextMuted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Checkbox(checked = checked, onCheckedChange = { isChecked ->
                                selected.value = selected.value.toMutableSet().apply { if (isChecked) add(song.id) else remove(song.id) }
                            }, colors = CheckboxDefaults.colors(checkedColor = Lime, checkmarkColor = OnLime))
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(selected.value.toList()) }) { Text("Guardar", color = Lime) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar", color = TextMuted) } },
        containerColor = SurfaceDark,
        titleContentColor = TextMain,
        textContentColor = TextMuted
    )
}

@Composable
private fun SettingsPane(
    selectedAccent: Color,
    onSelectAccent: (Color) -> Unit,
    searchAnimationEnabled: Boolean,
    onSearchAnimationChange: (Boolean) -> Unit,
    dynamicPlayerColorEnabled: Boolean,
    onDynamicPlayerColorChange: (Boolean) -> Unit,
    blurPlayerBackgroundEnabled: Boolean,
    onBlurPlayerBackgroundChange: (Boolean) -> Unit,
    visibleTabs: List<String>,
    onToggleLibraryTab: (String, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 12.dp)) {
        Text("PERSONALIZACIÓN", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(6.dp))
        Text("Dale tu color a ẞetaMusic", color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text("El color se aplica a botones, controles, selección y detalles de la interfaz.", color = TextMuted, fontSize = 13.sp, lineHeight = 19.sp)
        Spacer(Modifier.height(22.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Palette, null, tint = Lime, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(9.dp))
            Text("Color de acento", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(6.dp))
        Text("Selecciona una paleta", color = TextMuted, fontSize = 12.sp)
        Spacer(Modifier.height(15.dp))
        accentChoices.chunked(4).forEach { rowChoices ->
            Row(Modifier.fillMaxWidth().padding(bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                rowChoices.forEach { choice ->
                    val chosen = selectedAccent == choice.color
                    Column(
                        Modifier.weight(1f).clickable { onSelectAccent(choice.color) },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier.size(48.dp).border(if (chosen) 3.dp else 1.dp, if (chosen) Color.White else SurfaceLight, CircleShape)
                                .padding(if (chosen) 4.dp else 0.dp).clip(CircleShape).background(choice.color),
                            contentAlignment = Alignment.Center
                        ) {
                            if (chosen) Icon(Icons.Default.Check, null, tint = Color(0xFF101010), modifier = Modifier.size(21.dp))
                        }
                        Spacer(Modifier.height(7.dp))
                        Text(choice.name, color = if (chosen) TextMain else TextMuted, fontSize = 11.sp, fontWeight = if (chosen) FontWeight.Bold else FontWeight.Normal)
                    }
                }
                repeat((4 - rowChoices.size).coerceAtLeast(0)) { Spacer(Modifier.weight(1f)) }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(SurfaceDark).padding(15.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(selectedAccent), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.GraphicEq, null, tint = OnLime, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Vista previa", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Tu color se guarda automáticamente", color = TextMuted, fontSize = 11.sp)
            }
            Box(Modifier.size(42.dp).clip(CircleShape).background(selectedAccent), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Check, null, tint = OnLime, modifier = Modifier.size(22.dp))
            }
        }
        Spacer(Modifier.height(25.dp))
        Text("EXPERIENCIA DEL REPRODUCTOR", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(8.dp))
        PreferenceToggle(
            title = "Animación del buscador",
            subtitle = "Borde neón animado, inspirado en ẞetaMusic para PC",
            checked = searchAnimationEnabled,
            onCheckedChange = onSearchAnimationChange
        )
        PreferenceToggle(
            title = "Colores según la portada",
            subtitle = "Adapta botones, pestañas y detalles al color dominante de la portada",
            checked = dynamicPlayerColorEnabled,
            onCheckedChange = onDynamicPlayerColorChange
        )
        PreferenceToggle(
            title = "Fondo desenfocado",
            subtitle = "Usa la portada ampliada y difuminada tras el reproductor",
            checked = blurPlayerBackgroundEnabled,
            onCheckedChange = onBlurPlayerBackgroundChange
        )
        Spacer(Modifier.height(25.dp))
        Text("PESTAÑAS DE BIBLIOTECA", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(5.dp))
        Text("Elige qué secciones aparecen en la biblioteca. Debe quedar visible al menos una pestaña.", color = TextMuted, fontSize = 12.sp, lineHeight = 17.sp)
        Spacer(Modifier.height(8.dp))
        defaultLibraryTabs.forEach { label ->
            PreferenceToggle(
                title = label,
                subtitle = when (label) {
                    "Listas" -> "Tus listas de reproducción"
                    "Artistas" -> "Agrupar por intérprete"
                    "Álbumes" -> "Explorar por álbum"
                    "Canciones" -> "Toda tu colección musical"
                    else -> "Archivos locales descargados"
                },
                checked = label in visibleTabs,
                onCheckedChange = { enabled -> onToggleLibraryTab(label, enabled) }
            )
        }
        Spacer(Modifier.height(18.dp))
        Text("Los cambios se guardan automáticamente", color = TextMuted, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(8.dp))
        Text("ẞetaMusic · Android", color = TextMuted, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
private fun PreferenceToggle(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(16.dp))
            .background(SurfaceDark).padding(start = 14.dp, end = 10.dp, top = 12.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(3.dp))
            Text(subtitle, color = TextMuted, fontSize = 11.sp, lineHeight = 15.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Lime,
                checkedBorderColor = Lime,
                uncheckedThumbColor = TextMuted,
                uncheckedTrackColor = SurfaceLight
            )
        )
    }
}

private fun blendColors(start: Color, end: Color, fraction: Float): Color {
    val f = fraction.coerceIn(0f, 1f)
    return Color(
        red = start.red + (end.red - start.red) * f,
        green = start.green + (end.green - start.green) * f,
        blue = start.blue + (end.blue - start.blue) * f,
        alpha = start.alpha + (end.alpha - start.alpha) * f
    )
}

@Composable
private fun rememberDominantCoverColor(song: Song?): State<Color> {
    val context = LocalContext.current
    return produceState(initialValue = Color(0xFF7042D8), key1 = song?.id) {
        val requestedSong = song
        if (requestedSong == null) {
            value = Color(0xFFF454B8)
        } else {
            value = withContext(Dispatchers.IO) {
                runCatching {
                    val bitmap = loadCoverBitmap(context, requestedSong, 84)
                        ?: return@runCatching Color(0xFF7042D8)
                    dominantColorFromBitmap(bitmap)
                }.getOrDefault(Color(0xFF7042D8))
            }
        }
    }
}

private fun decodeScaledBitmap(context: android.content.Context, uri: Uri, px: Int): Bitmap? {
    val resolver = context.contentResolver
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sampleSize = 1
    while (bounds.outWidth / sampleSize > px * 2 || bounds.outHeight / sampleSize > px * 2) sampleSize *= 2
    val options = BitmapFactory.Options().apply {
        inSampleSize = sampleSize
        inPreferredConfig = Bitmap.Config.RGB_565
    }
    return resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
}

private fun loadCoverBitmap(context: android.content.Context, song: Song, px: Int): Bitmap? {
    ArtCache.get(song, px)?.let { return it }
    // MediaStore's album-art URI is more reliable than requesting a thumbnail
    // for an audio-file URI, which often returns no image on recent Android.
    val albumArt = if (song.albumId > 0L) {
        runCatching { decodeScaledBitmap(context, ContentUris.withAppendedId(ArtBase, song.albumId), px) }.getOrNull()
    } else null
    val bitmap = albumArt ?: if (Build.VERSION.SDK_INT >= 29) {
        loadThumbnail(context.contentResolver, song.uri, px)
    } else null
    bitmap?.let { ArtCache.put(song, px, it) }
    return bitmap
}

private fun dominantColorFromBitmap(bitmap: Bitmap): Color {
    val source = if (bitmap.config == Bitmap.Config.HARDWARE) bitmap.copy(Bitmap.Config.ARGB_8888, false) ?: bitmap else bitmap
    var r = 0.0; var g = 0.0; var b = 0.0; var weightTotal = 0.0
    val stepX = (source.width / 18).coerceAtLeast(1)
    val stepY = (source.height / 18).coerceAtLeast(1)
    val hsv = FloatArray(3)
    for (x in 0 until source.width step stepX) for (y in 0 until source.height step stepY) {
        val pixel = source.getPixel(x, y)
        android.graphics.Color.colorToHSV(pixel, hsv)
        if (hsv[2] < 0.16f) continue
        val weight = 0.35 + hsv[1].toDouble() * 1.8 + hsv[2].toDouble() * 0.25
        r += android.graphics.Color.red(pixel) * weight
        g += android.graphics.Color.green(pixel) * weight
        b += android.graphics.Color.blue(pixel) * weight
        weightTotal += weight
    }
    if (weightTotal <= 0.0) return Color(0xFF7042D8)
    var color = android.graphics.Color.rgb((r / weightTotal).toInt().coerceIn(0, 255), (g / weightTotal).toInt().coerceIn(0, 255), (b / weightTotal).toInt().coerceIn(0, 255))
    hsv.fill(0f)
    android.graphics.Color.colorToHSV(color, hsv)
    hsv[1] = (hsv[1] * 1.28f).coerceIn(0.35f, 0.95f)
    hsv[2] = (hsv[2] * 1.08f).coerceIn(0.42f, 0.92f)
    color = android.graphics.Color.HSVToColor(hsv)
    return Color(color)
}

@Composable
private fun CoverGradientBackground(song: Song, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val coverColor by produceState(Color(0xFF4E246F), song.id) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val bitmap = loadCoverBitmap(context, song, 72) ?: return@runCatching Color(0xFF4E246F)
                dominantColorFromBitmap(bitmap)
            }.getOrDefault(Color(0xFF4E246F))
        }
    }
    Box(
        modifier.background(
            Brush.verticalGradient(
                colors = listOf(
                    blendColors(coverColor, NeonPink, 0.32f).copy(alpha = 0.94f),
                    blendColors(coverColor, NeonViolet, 0.40f).copy(alpha = 0.72f),
                    Color(0xFF17102A).copy(alpha = 0.88f),
                    Bg
                )
            )
        )
    )
}

@Composable
private fun EmptyState(title: String, message: String, action: String?, onAction: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(30.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.LibraryMusic, null, tint = Lime, modifier = Modifier.size(52.dp))
        Spacer(Modifier.height(15.dp))
        Text(title, color = TextMain, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(7.dp))
        Text(message, color = TextMuted, fontSize = 13.sp, lineHeight = 19.sp)
        if (action != null) {
            Spacer(Modifier.height(15.dp))
            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = OnLime)
            ) { Text(action, fontWeight = FontWeight.Bold) }
        }
    }
}

private fun formatTime(ms: Long): String {
    val total = (ms.coerceAtLeast(0L) / 1000L).toInt()
    return String.format(Locale.US, "%d:%02d", total / 60, total % 60)
}

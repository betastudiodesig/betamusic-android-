package com.betastudio.betamusic

import android.Manifest
import android.content.ComponentName
import android.content.ContentResolver
import android.content.ContentUris
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.LruCache
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.Image as BitmapImage
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

// ───────────────────────── Identidad visual ẞetaMusic ─────────────────────────
// Neutral AMOLED foundation inspired by Samsung Music / One UI; artwork can supply
// a temporary player accent, while library screens remain quiet and legible.
private val Bg = Color(0xFF000000)
private val SurfaceDark = Color(0xFF111114)
private val SurfaceLight = Color(0xFF222226)
private val appAccentState = mutableStateOf(Color(0xFF4B83F5))
private val manualAccentState = mutableStateOf(Color(0xFF4B83F5))
private val Lime: Color get() = appAccentState.value
private val OnLime = Color(0xFF071426)
private val TextMain = Color(0xFFF7F7F8)
private val TextMuted = Color(0xFFA5A5AD)
private val NeonViolet = Color(0xFF4B83F5)
private val NeonPink = Color(0xFF78A7FF)

private val ArtBase: Uri = Uri.parse("content://media/external/audio/albumart")

private const val SECTION_HOME = "home"
private const val SECTION_SEARCH = "search"
private const val SECTION_PROFILE = "profile"
private const val SECTION_LIBRARY = "library"
private const val SECTION_FAVORITES = "favorites"
private const val SECTION_QUEUE = "queue"
private const val SECTION_PLAYLISTS = "playlists"
private const val SECTION_SETTINGS = "settings"
private const val PREFS_SETTINGS = "betamusic_settings"
private const val PREF_ACCENT = "accent_color"
private const val PREF_SEARCH_ANIMATION = "search_animation_enabled"
private const val PREF_DYNAMIC_PLAYER_COLOR = "dynamic_player_color_enabled"
private const val PREF_BLUR_PLAYER_BACKGROUND = "blur_player_background_enabled"
private const val PREF_VISIBLE_LIBRARY_TABS = "visible_library_tabs"
private const val PREF_SONG_SORT = "song_sort_mode"

private val allLibraryTabs = listOf("Listas", "Canciones", "Álbumes", "Artistas", "Géneros", "Compositores", "Carpetas", "Favoritos", "Descargas")
private val songSortOptions = listOf("Nombre", "Artista", "Álbum", "Fecha de añadido", "Duración")

private fun readVisibleLibraryTabs(context: android.content.Context): List<String> {
    val saved = context.getSharedPreferences(PREFS_SETTINGS, android.content.Context.MODE_PRIVATE)
        .getStringSet(PREF_VISIBLE_LIBRARY_TABS, null)
    return allLibraryTabs.filter { saved == null || it in saved }.ifEmpty { listOf("Canciones") }
}

private val searchAnimationState = mutableStateOf(true)
private val dynamicPlayerColorState = mutableStateOf(true)
private val blurPlayerBackgroundState = mutableStateOf(true)

private data class LibraryGroup(
    val id: String,
    val title: String,
    val subtitle: String,
    val songs: List<Song>
) {
    val coverSong: Song? get() = songs.firstOrNull()
}

private data class MusicPlaylist(val id: String, val name: String, val songIds: List<Long>)

private data class AccentChoice(val name: String, val color: Color)

private val accentChoices = listOf(
    AccentChoice("Azul One UI", Color(0xFF4B83F5)),
    AccentChoice("Azul cielo", Color(0xFF43B4F5)),
    AccentChoice("Violeta", Color(0xFF9275F5)),
    AccentChoice("Rosa", Color(0xFFE86E9C)),
    AccentChoice("Cian", Color(0xFF36BFC8)),
    AccentChoice("Coral", Color(0xFFFF806F)),
    AccentChoice("Ámbar", Color(0xFFE9B64F))
)

private fun readPlaylists(context: android.content.Context): List<MusicPlaylist> = runCatching {
    val json = context.getSharedPreferences("betamusic", android.content.Context.MODE_PRIVATE)
        .getString("playlists_json", "[]") ?: "[]"
    val array = JSONArray(json)
    buildList {
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val ids = item.optJSONArray("songIds") ?: JSONArray()
            add(MusicPlaylist(
                id = item.optString("id", System.currentTimeMillis().toString() + i),
                name = item.optString("name", "Lista ${i + 1}"),
                songIds = buildList { for (j in 0 until ids.length()) ids.optLong(j).takeIf { it > 0L }?.let { add(it) } }.distinct()
            ))
        }
    }
}.getOrDefault(emptyList())

private fun savePlaylists(context: android.content.Context, playlists: List<MusicPlaylist>) {
    val array = JSONArray()
    playlists.forEach { playlist ->
        val ids = JSONArray()
        playlist.songIds.forEach(ids::put)
        array.put(JSONObject().put("id", playlist.id).put("name", playlist.name).put("songIds", ids))
    }
    context.getSharedPreferences("betamusic", android.content.Context.MODE_PRIVATE)
        .edit().putString("playlists_json", array.toString()).apply()
}

internal data class QueueEntry(val index: Int, val song: Song, val key: String = song.id.toString())

internal data class UiState(
    val songs: List<Song>,
    val loading: Boolean,
    val hasPermission: Boolean,
    val error: String?,
    val favorites: Set<Long>,
    val currentId: Long?,
    val isPlaying: Boolean,
    val duration: Long,
    val shuffle: Boolean,
    val repeatMode: Int,
    val queueVersion: Int,
    val message: String?
)

internal class UiActions(
    val requestPermission: () -> Unit,
    val refresh: () -> Unit,
    val play: (Song, List<Song>) -> Unit,
    val playNext: (Song) -> Unit,
    val moveQueueItem: (Int, Int) -> Unit,
    val togglePlay: () -> Unit,
    val next: () -> Unit,
    val previous: () -> Unit,
    val seek: (Long) -> Unit,
    val toggleFavorite: (Song) -> Unit,
    val toggleShuffle: () -> Unit,
    val cycleRepeat: () -> Unit,
    val playQueueItem: (Int) -> Unit,
    val readQueue: (Map<Long, Song>) -> List<QueueEntry>,
    val dismissMessage: () -> Unit
)

// ───────────────────────────── Actividad ─────────────────────────────
class MainActivity : ComponentActivity() {
    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var loadJob: Job? = null
    private var errorStreak = 0

    private val songsState = mutableStateOf<List<Song>>(emptyList())
    private val permissionState = mutableStateOf(false)
    private val loadingState = mutableStateOf(true)
    private val errorState = mutableStateOf<String?>(null)
    private val favoritesState = mutableStateOf<Set<Long>>(emptySet())
    private val currentIdState = mutableStateOf<Long?>(null)
    private val playingState = mutableStateOf(false)
    private val durationState = mutableLongStateOf(0L)
    private val positionState = mutableLongStateOf(0L)
    private val shuffleState = mutableStateOf(false)
    private val repeatState = mutableIntStateOf(Player.REPEAT_MODE_OFF)
    private val queueVersionState = mutableIntStateOf(0)
    private val messageState = mutableStateOf<String?>(null)

    private val audioPermission: String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            permissionState.value = granted
            if (granted) loadLibrary() else loadingState.value = false
        }

    private val notificationLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* sin acción: la reproducción no depende de ello */ }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            playingState.value = isPlaying
            if (isPlaying) errorStreak = 0
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            currentIdState.value = mediaItem?.mediaId?.toLongOrNull()
            syncPlayerState()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            syncPlayerState()
        }

        override fun onTimelineChanged(timeline: Timeline, reason: Int) {
            queueVersionState.intValue++
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            shuffleState.value = shuffleModeEnabled
            queueVersionState.intValue++
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            repeatState.intValue = repeatMode
        }

        override fun onPlayerError(error: PlaybackException) {
            val player = controller ?: return
            val title = player.currentMediaItem?.mediaMetadata?.title?.toString() ?: "la canción"
            errorStreak++
            messageState.value = "No se pudo reproducir «$title». Puede estar dañado o haber sido movido."
            // Se salta al siguiente archivo, con un límite para no entrar en un bucle si todos fallan.
            if (errorStreak <= 5 && player.hasNextMediaItem()) {
                player.seekToNextMediaItem()
                player.prepare()
                player.play()
            }
        }
    }

    private val actions = UiActions(
        requestPermission = { permissionLauncher.launch(audioPermission) },
        refresh = { refreshLibrary() },
        play = { song, list -> playSong(song, list) },
        playNext = { song -> insertNext(song) },
        moveQueueItem = { from, to ->
            val player = controller
            if (player != null && from in 0 until player.mediaItemCount && to in 0 until player.mediaItemCount && from != to) {
                player.moveMediaItem(from, to)
                queueVersionState.intValue++
            }
        },
        togglePlay = { togglePlay() },
        next = { controller?.seekToNext() },
        previous = { controller?.seekToPrevious() },
        seek = { ms ->
            controller?.seekTo(ms)
            positionState.longValue = ms
        },
        toggleFavorite = { toggleFavorite(it) },
        toggleShuffle = {
            controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
        },
        cycleRepeat = {
            controller?.let {
                it.repeatMode = when (it.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
            }
        },
        playQueueItem = { index ->
            controller?.let {
                it.seekTo(index, 0L)
                if (it.playbackState == Player.STATE_IDLE) it.prepare()
                it.play()
            }
        },
        readQueue = { byId -> readQueue(byId) },
        dismissMessage = { messageState.value = null }
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val appearancePrefs = getSharedPreferences(PREFS_SETTINGS, MODE_PRIVATE)
        val oldDefaultPink = Color(0xFFF454B8).toArgb()
        val modernBlue = Color(0xFF4B83F5).toArgb()
        val savedAccent = appearancePrefs.getInt(PREF_ACCENT, modernBlue).let { if (it == oldDefaultPink) modernBlue else it }
        appAccentState.value = Color(savedAccent)
        manualAccentState.value = Color(savedAccent)
        searchAnimationState.value = appearancePrefs.getBoolean(PREF_SEARCH_ANIMATION, true)
        dynamicPlayerColorState.value = appearancePrefs.getBoolean(PREF_DYNAMIC_PLAYER_COLOR, true)
        blurPlayerBackgroundState.value = appearancePrefs.getBoolean(PREF_BLUR_PLAYER_BACKGROUND, false)

        favoritesState.value =
            getSharedPreferences("betamusic", MODE_PRIVATE)
                .getStringSet("favorites", emptySet())
                ?.mapNotNull { it.toLongOrNull() }
                ?.toSet() ?: emptySet()

        if (ContextCompat.checkSelfPermission(this, audioPermission) == PackageManager.PERMISSION_GRANTED) {
            permissionState.value = true
            loadLibrary()
        } else {
            loadingState.value = false
            permissionLauncher.launch(audioPermission)
        }

        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener({
                try {
                    controller = future.get()
                    controller?.addListener(playerListener)
                    syncPlayerState()
                    queueVersionState.intValue++
                } catch (_: Exception) {
                    messageState.value = "No se pudo conectar con el servicio de reproducción."
                }
            }, ContextCompat.getMainExecutor(this))
        }

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Lime,
                    onPrimary = OnLime,
                    background = Bg,
                    surface = SurfaceDark,
                    onBackground = TextMain,
                    onSurface = TextMain
                )
            ) {
                val ui = UiState(
                    songs = songsState.value,
                    loading = loadingState.value,
                    hasPermission = permissionState.value,
                    error = errorState.value,
                    favorites = favoritesState.value,
                    currentId = currentIdState.value,
                    isPlaying = playingState.value,
                    duration = durationState.longValue,
                    shuffle = shuffleState.value,
                    repeatMode = repeatState.intValue,
                    queueVersion = queueVersionState.intValue,
                    message = messageState.value
                )
                BetaMusicScreen(
                    ui = ui,
                    position = { positionState.longValue },
                    a = actions
                )
            }
        }

        // El avance de la barra solo se actualiza mientras la app está visible y suena música.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                syncPlayerState()
                while (true) {
                    val player = controller
                    if (player != null && player.isPlaying) {
                        val pos = player.currentPosition.coerceAtLeast(0L)
                        if (pos != positionState.longValue) positionState.longValue = pos
                    }
                    delay(500)
                }
            }
        }
    }

    private fun refreshLibrary() {
        if (ContextCompat.checkSelfPermission(this, audioPermission) == PackageManager.PERMISSION_GRANTED) {
            permissionState.value = true
            loadLibrary()
        } else {
            permissionLauncher.launch(audioPermission)
        }
    }

    private fun loadLibrary() {
        loadJob?.cancel()
        loadingState.value = true
        errorState.value = null
        loadJob = lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching { MusicRepository(this@MainActivity).loadSongs() }
            }
            result
                .onSuccess { songsState.value = it }
                .onFailure {
                    errorState.value = it.message ?: "Error desconocido al leer la biblioteca."
                }
            loadingState.value = false
        }
    }

    private fun buildItem(song: Song): MediaItem {
        val metadata = MediaMetadata.Builder()
            .setTitle(song.title)
            .setArtist(song.artist)
            .setAlbumTitle(song.album)
        if (song.albumId > 0) {
            metadata.setArtworkUri(ContentUris.withAppendedId(ArtBase, song.albumId))
        }
        return MediaItem.Builder()
            .setMediaId(song.id.toString())
            .setUri(song.uri)
            .setMediaMetadata(metadata.build())
            .build()
    }

    /** La cola es la lista desde la que se tocó la canción (álbum, artista, carpeta, favoritos o búsqueda). */
    private fun playSong(song: Song, context: List<Song>) {
        val player = controller
        if (player == null) {
            messageState.value = "El reproductor se está iniciando. Inténtalo de nuevo en un momento."
            return
        }
        val list = if (context.any { it.id == song.id }) context else listOf(song)
        askNotificationsOnce()
        lifecycleScope.launch {
            val items = withContext(Dispatchers.Default) { list.map { buildItem(it) } }
            val index = list.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
            errorStreak = 0
            player.setMediaItems(items, index, 0L)
            player.prepare()
            player.play()
            currentIdState.value = song.id
        }
    }

    /** Insert a track directly after the current one, like Samsung Music's add-next action. */
    private fun insertNext(song: Song) {
        val player = controller ?: return
        if (player.mediaItemCount == 0) {
            playSong(song, songsState.value.ifEmpty { listOf(song) })
            return
        }
        val oldIndex = (0 until player.mediaItemCount).firstOrNull { index ->
            player.getMediaItemAt(index).mediaId == song.id.toString()
        }
        if (oldIndex == player.currentMediaItemIndex) {
            messageState.value = "Esta canción ya está sonando."
            return
        }
        if (oldIndex != null) player.removeMediaItem(oldIndex)
        val nextIndex = (player.currentMediaItemIndex + 1).coerceIn(0, player.mediaItemCount)
        player.addMediaItem(nextIndex, buildItem(song))
        queueVersionState.intValue++
        messageState.value = "Se reproducirá a continuación: ${song.title}"
    }

    private fun askNotificationsOnce() {
        if (Build.VERSION.SDK_INT < 33) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        ) return
        val prefs = getSharedPreferences("betamusic", MODE_PRIVATE)
        if (prefs.getBoolean("asked_notifications", false)) return
        prefs.edit().putBoolean("asked_notifications", true).apply()
        notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun togglePlay() {
        val player = controller ?: return
        if (player.mediaItemCount == 0) {
            songsState.value.firstOrNull()?.let { playSong(it, songsState.value) }
            return
        }
        if (player.isPlaying) {
            player.pause()
        } else {
            when (player.playbackState) {
                Player.STATE_IDLE -> player.prepare()
                Player.STATE_ENDED -> player.seekToDefaultPosition(0)
                else -> Unit
            }
            player.play()
        }
    }

    private fun readQueue(byId: Map<Long, Song>): List<QueueEntry> {
        val player = controller ?: return emptyList()
        val timeline = player.currentTimeline
        if (timeline.isEmpty) return emptyList()
        val shuffle = player.shuffleModeEnabled
        val out = ArrayList<QueueEntry>(timeline.windowCount)
        val occurrences = mutableMapOf<Long, Int>()
        var i = timeline.getFirstWindowIndex(shuffle)
        while (i != C.INDEX_UNSET) {
            val song = player.getMediaItemAt(i).mediaId.toLongOrNull()?.let { byId[it] }
            if (song != null) {
                val occurrence = occurrences.getOrDefault(song.id, 0)
                occurrences[song.id] = occurrence + 1
                out.add(QueueEntry(i, song, "${song.id}#$occurrence"))
            }
            i = timeline.getNextWindowIndex(i, Player.REPEAT_MODE_OFF, shuffle)
        }
        return out
    }

    private fun syncPlayerState() {
        val player = controller ?: return
        playingState.value = player.isPlaying
        durationState.longValue = player.duration.takeIf { it > 0 } ?: 0L
        positionState.longValue = player.currentPosition.coerceAtLeast(0L)
        currentIdState.value = player.currentMediaItem?.mediaId?.toLongOrNull()
        shuffleState.value = player.shuffleModeEnabled
        repeatState.intValue = player.repeatMode
    }

    private fun toggleFavorite(song: Song) {
        val next = favoritesState.value.toMutableSet().apply {
            if (!add(song.id)) remove(song.id)
        }.toSet()
        favoritesState.value = next
        getSharedPreferences("betamusic", MODE_PRIVATE)
            .edit()
            .putStringSet("favorites", next.map { it.toString() }.toSet())
            .apply()
    }

    override fun onDestroy() {
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }
}

// ───────────────────────────── Pantalla principal ─────────────────────────────
@Composable
private fun BetaMusicScreen(ui: UiState, position: () -> Long, a: UiActions) {
    var query by rememberSaveable { mutableStateOf("") }
    var section by rememberSaveable { mutableStateOf(SECTION_LIBRARY) }
    var tab by rememberSaveable { mutableStateOf("Canciones") }
    var selectedGroupId by rememberSaveable { mutableStateOf<String?>(null) }
    var showPlayer by rememberSaveable { mutableStateOf(false) }
    var selectedPlaylistId by rememberSaveable { mutableStateOf<String?>(null) }
    var showCreatePlaylist by rememberSaveable { mutableStateOf(false) }
    var showPlayerAddToPlaylist by rememberSaveable { mutableStateOf(false) }
    var playlistTargetSongId by rememberSaveable { mutableStateOf<Long?>(null) }
    var songToAddToNewPlaylist by rememberSaveable { mutableStateOf<Long?>(null) }
    var showAddSongs by rememberSaveable { mutableStateOf(false) }
    val context = LocalContext.current
    var visibleLibraryTabs by remember { mutableStateOf(readVisibleLibraryTabs(context)) }
    var sortMode by remember {
        mutableStateOf(context.getSharedPreferences(PREFS_SETTINGS, android.content.Context.MODE_PRIVATE).getString(PREF_SONG_SORT, "Nombre") ?: "Nombre")
    }
    var playlists by remember { mutableStateOf(readPlaylists(context)) }
    val persistPlaylists: (List<MusicPlaylist>) -> Unit = { updated ->
        playlists = updated
        savePlaylists(context, updated)
    }

    val songs = ui.songs
    val songsById = remember(songs) { songs.associateBy { it.id } }
    val current = ui.currentId?.let { songsById[it] }
    DynamicAccentController(current, dynamicPlayerColorState.value)
    val selectedPlaylist = playlists.firstOrNull { it.id == selectedPlaylistId }
    val playlistSongs = selectedPlaylist?.songIds.orEmpty().mapNotNull(songsById::get)
    val groups = remember(songs, tab) {
        when (tab) {
            "Artistas" -> buildGroups(songs, "Artistas")
            "Álbumes" -> buildGroups(songs, "Álbumes")
            "Géneros" -> buildGroups(songs, "Géneros")
            "Compositores" -> buildGroups(songs, "Compositores")
            "Carpetas" -> buildGroups(songs, "Carpetas")
            else -> emptyList()
        }
    }
    val selectedGroup = groups.firstOrNull { it.id == selectedGroupId }
    val filteredGroups = remember(groups, query) {
        groups.filter { group -> query.isBlank() || group.title.contains(query, true) || group.subtitle.contains(query, true) || group.songs.any { songMatches(it, query) } }
    }
    val baseSongs = selectedGroup?.songs ?: songs
    val filteredSongs = remember(baseSongs, query, sortMode) {
        val matching = baseSongs.filter { songMatches(it, query) }
        when (sortMode) {
            "Artista" -> matching.sortedWith(compareBy<Song> { it.artist.lowercase(Locale.ROOT) }.thenBy { it.title.lowercase(Locale.ROOT) })
            "Álbum" -> matching.sortedWith(compareBy<Song> { it.album.lowercase(Locale.ROOT) }.thenBy { it.title.lowercase(Locale.ROOT) })
            "Fecha de añadido" -> matching.sortedWith(compareByDescending<Song> { it.dateAddedSeconds }.thenBy { it.title.lowercase(Locale.ROOT) })
            "Duración" -> matching.sortedWith(compareBy<Song> { it.durationMs }.thenBy { it.title.lowercase(Locale.ROOT) })
            else -> matching.sortedBy { it.title.lowercase(Locale.ROOT) }
        }
    }
    val downloadSongs = remember(filteredSongs) {
        filteredSongs.filter { it.folder.contains("/download", true) || it.folder.endsWith("download", true) }
    }
    val favoriteSongs = remember(songs, ui.favorites, query) { songs.filter { it.id in ui.favorites && songMatches(it, query) } }
    val homeSongs = remember(songs, ui.currentId) {
        buildList {
            current?.let { add(it) }
            songs.filterNot { it.id == ui.currentId }.take(8).forEach(::add)
        }.take(8)
    }
    val personalMix = remember(songs, ui.favorites, ui.currentId) {
        buildPersonalMix(songs, ui.favorites, current)
    }

    LaunchedEffect(section) {
        // Migrate a saved pre-redesign Home destination to the Samsung Music-style library.
        if (section == SECTION_HOME) {
            section = SECTION_LIBRARY
            tab = "Canciones"
        }
    }
    LaunchedEffect(visibleLibraryTabs) {
        if (tab !in visibleLibraryTabs) {
            tab = visibleLibraryTabs.firstOrNull() ?: "Canciones"
            selectedGroupId = null
        }
    }
    LaunchedEffect(current == null) { if (current == null) showPlayer = false }
    LaunchedEffect(ui.message) {
        if (ui.message != null) {
            delay(3500)
            a.dismissMessage()
        }
    }

    BackHandler(enabled = showPlayer && current != null) { showPlayer = false }
    BackHandler(enabled = !showPlayer && section == SECTION_PLAYLISTS && selectedPlaylistId != null) {
        selectedPlaylistId = null
        section = SECTION_LIBRARY
        tab = "Listas"
    }
    BackHandler(enabled = !showPlayer && section == SECTION_LIBRARY && selectedGroup != null) { selectedGroupId = null }
    BackHandler(enabled = !showPlayer && section == SECTION_LIBRARY && selectedPlaylistId != null) { selectedPlaylistId = null }
    BackHandler(enabled = !showPlayer && section in listOf(SECTION_FAVORITES, SECTION_QUEUE, SECTION_SETTINGS, SECTION_PROFILE)) { section = SECTION_LIBRARY }
    BackHandler(enabled = !showPlayer && section in listOf(SECTION_SEARCH, SECTION_PLAYLISTS)) {
        section = SECTION_LIBRARY
        selectedPlaylistId = null
    }

    Column(
        Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()
    ) {
        AnimatedContent(
            targetState = showPlayer && current != null,
            modifier = Modifier.fillMaxSize(),
            transitionSpec = {
                if (targetState) {
                    (slideInVertically(initialOffsetY = { it / 3 }, animationSpec = tween(330)) +
                        fadeIn(animationSpec = tween(280)) +
                        scaleIn(initialScale = 0.975f, animationSpec = tween(330))) togetherWith
                        (fadeOut(animationSpec = tween(150)) + scaleOut(targetScale = 0.985f, animationSpec = tween(150)))
                } else {
                    (slideInVertically(initialOffsetY = { -it / 14 }, animationSpec = tween(240)) +
                        fadeIn(animationSpec = tween(220))) togetherWith
                        (slideOutVertically(targetOffsetY = { it / 5 }, animationSpec = tween(170)) + fadeOut(animationSpec = tween(150)))
                }
            },
            label = "playerScreenTransition"
        ) { playerVisible ->
        if (playerVisible && current != null) {
            NowPlayingScreen(
                song = current,
                isPlaying = ui.isPlaying,
                isFavorite = current.id in ui.favorites,
                shuffle = ui.shuffle,
                repeatMode = ui.repeatMode,
                position = position,
                duration = ui.duration,
                onBack = { showPlayer = false },
                onTogglePlay = a.togglePlay,
                onPrevious = a.previous,
                onNext = a.next,
                onSeek = a.seek,
                onToggleFavorite = { a.toggleFavorite(current) },
                onToggleShuffle = a.toggleShuffle,
                onCycleRepeat = a.cycleRepeat,
                onOpenQueue = { showPlayer = false; section = SECTION_QUEUE },
                onOpenPlaylists = { playlistTargetSongId = current.id; showPlayerAddToPlaylist = true },
                dynamicColors = dynamicPlayerColorState.value,
                blurBackground = blurPlayerBackgroundState.value
            )
        } else {
            Column(Modifier.fillMaxSize()) {
            TopHeader(
                onSearch = { section = SECTION_SEARCH; query = "" },
                onProfile = { section = SECTION_PROFILE },
                onFavorites = { section = SECTION_LIBRARY; tab = "Favoritos"; query = "" },
                onQueue = { section = SECTION_QUEUE },
                onSettings = { section = SECTION_SETTINGS },
                onRefresh = a.refresh
            )

            Box(Modifier.weight(1f).fillMaxWidth()) {
                Crossfade(targetState = section, animationSpec = tween(durationMillis = 230), label = "sectionTransition") { visibleSection ->
                when (visibleSection) {
                    SECTION_HOME -> HomePane(
                        songs = homeSongs,
                        allSongs = songs,
                        personalMix = personalMix,
                        mixUsesFavorites = songs.any { it.id in ui.favorites },
                        playlists = playlists,
                        songsById = songsById,
                        onPlay = { song, source -> a.play(song, source); showPlayer = true },
                        onOpenAll = { section = SECTION_SEARCH; query = "" },
                        onOpenLibrary = { section = SECTION_LIBRARY; tab = "Canciones" },
                        onOpenPlaylist = { playlist -> selectedPlaylistId = playlist.id; section = SECTION_PLAYLISTS }
                    )

                    SECTION_SEARCH -> Column(Modifier.fillMaxSize()) {
                        SearchField(query, animated = searchAnimationState.value) { query = it }
                        CountHeader("BÚSQUEDA", if (ui.loading) "Leyendo biblioteca…" else "${filteredSongs.size} canciones")
                        when {
                            !ui.hasPermission -> EmptyState("Permiso necesario", "Permite el acceso al audio para buscar en tu biblioteca.", "Conceder permiso", a.requestPermission)
                            ui.loading -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Lime) }
                            filteredSongs.isEmpty() -> EmptyState("No se encontraron canciones", "Prueba otro título, artista o álbum.", if (query.isNotBlank()) "Limpiar búsqueda" else null, { query = "" })
                            else -> SongList(filteredSongs, ui.currentId, ui.isPlaying, ui.favorites, { song -> a.play(song, filteredSongs); showPlayer = true }, a.toggleFavorite, Modifier.weight(1f), onAddToPlaylist = { playlistTargetSongId = it.id; showPlayerAddToPlaylist = true }, onPlayNext = a.playNext)
                        }
                    }

                    SECTION_PROFILE -> ProfilePane(
                        songCount = songs.size,
                        favoritesCount = ui.favorites.size,
                        playlistCount = playlists.size,
                        onFavorites = { section = SECTION_FAVORITES },
                        onQueue = { section = SECTION_QUEUE },
                        onSettings = { section = SECTION_SETTINGS },
                        onRefresh = a.refresh
                    )

                    SECTION_FAVORITES -> Column(Modifier.fillMaxSize()) {
                        SearchField(query, animated = searchAnimationState.value) { query = it }
                        CountHeader("TUS FAVORITOS", if (ui.loading) "Leyendo música…" else "${favoriteSongs.size} pistas")
                        if (favoriteSongs.isEmpty()) {
                            EmptyState(if (ui.favorites.isEmpty()) "Aún no hay favoritos" else "Sin resultados", if (ui.favorites.isEmpty()) "Toca el corazón de una canción para guardarla aquí." else "Prueba otra búsqueda.", if (query.isNotEmpty()) "Limpiar búsqueda" else null) { query = "" }
                        } else {
                            SongList(favoriteSongs, ui.currentId, ui.isPlaying, ui.favorites, { song -> a.play(song, favoriteSongs); showPlayer = true }, a.toggleFavorite, Modifier.weight(1f), onAddToPlaylist = { playlistTargetSongId = it.id; showPlayerAddToPlaylist = true }, onPlayNext = a.playNext)
                        }
                    }

                    SECTION_QUEUE -> QueuePane(ui = ui, songsById = songsById, a = a)

                    SECTION_PLAYLISTS -> {
                        if (selectedPlaylist == null) {
                            PlaylistsPane(playlists, songsById, { showCreatePlaylist = true }, { selectedPlaylistId = it.id }, Modifier.fillMaxSize())
                        } else {
                            PlaylistDetailPane(
                                playlist = selectedPlaylist,
                                songs = playlistSongs,
                                currentId = ui.currentId,
                                isPlaying = ui.isPlaying,
                                onBack = { selectedPlaylistId = null; section = SECTION_LIBRARY; tab = "Listas" },
                                onAddSongs = { showAddSongs = true },
                                onPlay = { song -> a.play(song, playlistSongs); showPlayer = true },
                                onRemove = { song -> persistPlaylists(playlists.map { item -> if (item.id == selectedPlaylist.id) item.copy(songIds = item.songIds.filterNot { it == song.id }) else item }) },
                                onDelete = { persistPlaylists(playlists.filterNot { it.id == selectedPlaylist.id }); selectedPlaylistId = null; section = SECTION_LIBRARY; tab = "Listas" },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }

                    SECTION_SETTINGS -> SettingsPane(
                        selectedAccent = manualAccentState.value,
                        onSelectAccent = { color ->
                            manualAccentState.value = color
                            if (!dynamicPlayerColorState.value) appAccentState.value = color
                            context.getSharedPreferences(PREFS_SETTINGS, android.content.Context.MODE_PRIVATE).edit().putInt(PREF_ACCENT, color.toArgb()).apply()
                        },
                        searchAnimationEnabled = searchAnimationState.value,
                        onSearchAnimationChange = { enabled ->
                            searchAnimationState.value = enabled
                            context.getSharedPreferences(PREFS_SETTINGS, android.content.Context.MODE_PRIVATE).edit().putBoolean(PREF_SEARCH_ANIMATION, enabled).apply()
                        },
                        dynamicPlayerColorEnabled = dynamicPlayerColorState.value,
                        onDynamicPlayerColorChange = { enabled ->
                            dynamicPlayerColorState.value = enabled
                            if (!enabled) appAccentState.value = manualAccentState.value
                            context.getSharedPreferences(PREFS_SETTINGS, android.content.Context.MODE_PRIVATE).edit().putBoolean(PREF_DYNAMIC_PLAYER_COLOR, enabled).apply()
                        },
                        blurPlayerBackgroundEnabled = blurPlayerBackgroundState.value,
                        onBlurPlayerBackgroundChange = { enabled ->
                            blurPlayerBackgroundState.value = enabled
                            context.getSharedPreferences(PREFS_SETTINGS, android.content.Context.MODE_PRIVATE).edit().putBoolean(PREF_BLUR_PLAYER_BACKGROUND, enabled).apply()
                        },
                        visibleTabs = visibleLibraryTabs,
                        onToggleTab = { label, enabled ->
                            val updated = if (enabled) (visibleLibraryTabs + label).distinct().sortedBy { allLibraryTabs.indexOf(it) }
                                          else visibleLibraryTabs.filterNot { it == label }
                            if (updated.isNotEmpty()) {
                                visibleLibraryTabs = updated
                                context.getSharedPreferences(PREFS_SETTINGS, android.content.Context.MODE_PRIVATE).edit()
                                    .putStringSet(PREF_VISIBLE_LIBRARY_TABS, updated.toSet()).apply()
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )

                    else -> Column(
                        Modifier.fillMaxSize().pointerInput(tab, visibleLibraryTabs) {
                            // Listen on the whole library area (including the tab strip), not just
                            // the animated pane, so swipes are recognized consistently.
                            var drag = 0f
                            detectHorizontalDragGestures(
                                onHorizontalDrag = { change, amount ->
                                    drag += amount
                                    change.consume()
                                },
                                onDragEnd = {
                                    if (kotlin.math.abs(drag) > 48.dp.toPx() && visibleLibraryTabs.isNotEmpty()) {
                                        val currentIndex = visibleLibraryTabs.indexOf(tab)
                                        val nextIndex = (currentIndex + if (drag < 0f) 1 else -1).coerceIn(0, visibleLibraryTabs.lastIndex)
                                        if (nextIndex != currentIndex) {
                                            tab = visibleLibraryTabs[nextIndex]
                                            selectedGroupId = null
                                            query = ""
                                        }
                                    }
                                    drag = 0f
                                },
                                onDragCancel = { drag = 0f }
                            )
                        }
                    ) {
                        LibraryTabs(tab, visibleLibraryTabs) { next -> tab = next; selectedGroupId = null; query = "" }
                        AnimatedContent(
                            targetState = tab,
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            transitionSpec = {
                                val goingForward = allLibraryTabs.indexOf(targetState) >= allLibraryTabs.indexOf(initialState)
                                (slideInHorizontally(initialOffsetX = { if (goingForward) it / 5 else -it / 5 }, animationSpec = tween(250)) + fadeIn(tween(210))) togetherWith
                                    (slideOutHorizontally(targetOffsetX = { if (goingForward) -it / 7 else it / 7 }, animationSpec = tween(180)) + fadeOut(tween(160)))
                            },
                            label = "libraryTabTransition"
                        ) { animatedTab ->
                            val paneGroups = remember(songs, animatedTab) {
                                when (animatedTab) {
                                    "Artistas" -> buildGroups(songs, "Artistas")
                                    "Álbumes" -> buildGroups(songs, "Álbumes")
                                    "Géneros" -> buildGroups(songs, "Géneros")
                                    "Compositores" -> buildGroups(songs, "Compositores")
                                    "Carpetas" -> buildGroups(songs, "Carpetas")
                                    else -> emptyList()
                                }
                            }
                            val paneSelectedGroup = paneGroups.firstOrNull { it.id == selectedGroupId }
                            val paneFilteredGroups = remember(paneGroups, query) {
                                paneGroups.filter { group -> query.isBlank() || group.title.contains(query, true) || group.subtitle.contains(query, true) || group.songs.any { songMatches(it, query) } }
                            }
                            val paneBaseSongs = paneSelectedGroup?.songs ?: songs
                            val paneFilteredSongs = remember(paneBaseSongs, query, sortMode) {
                                val matching = paneBaseSongs.filter { songMatches(it, query) }
                                when (sortMode) {
                                    "Artista" -> matching.sortedWith(compareBy<Song> { it.artist.lowercase(Locale.ROOT) }.thenBy { it.title.lowercase(Locale.ROOT) })
                                    "Álbum" -> matching.sortedWith(compareBy<Song> { it.album.lowercase(Locale.ROOT) }.thenBy { it.title.lowercase(Locale.ROOT) })
                                    "Fecha de añadido" -> matching.sortedWith(compareByDescending<Song> { it.dateAddedSeconds }.thenBy { it.title.lowercase(Locale.ROOT) })
                                    "Duración" -> matching.sortedWith(compareBy<Song> { it.durationMs }.thenBy { it.title.lowercase(Locale.ROOT) })
                                    else -> matching.sortedBy { it.title.lowercase(Locale.ROOT) }
                                }
                            }
                            val paneDownloadSongs = remember(paneFilteredSongs) {
                                paneFilteredSongs.filter { it.folder.contains("/download", true) || it.folder.endsWith("download", true) }
                            }
                            val paneFavoriteSongs = remember(songs, ui.favorites, query, sortMode) {
                                val matching = songs.filter { it.id in ui.favorites && songMatches(it, query) }
                                when (sortMode) {
                                    "Artista" -> matching.sortedWith(compareBy<Song> { it.artist.lowercase(Locale.ROOT) }.thenBy { it.title.lowercase(Locale.ROOT) })
                                    "Álbum" -> matching.sortedWith(compareBy<Song> { it.album.lowercase(Locale.ROOT) }.thenBy { it.title.lowercase(Locale.ROOT) })
                                    "Fecha de añadido" -> matching.sortedWith(compareByDescending<Song> { it.dateAddedSeconds })
                                    "Duración" -> matching.sortedBy { it.durationMs }
                                    else -> matching.sortedBy { it.title.lowercase(Locale.ROOT) }
                                }
                            }
                            Column(Modifier.fillMaxSize()) {
                                if (paneSelectedGroup != null) {
                                    Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 20.dp, top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(onClick = { selectedGroupId = null }) { Icon(Icons.Default.ArrowBack, "Volver", tint = Lime) }
                                        Column(Modifier.weight(1f)) {
                                            Text(paneSelectedGroup.title, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text(paneSelectedGroup.subtitle, color = TextMuted, fontSize = 12.sp)
                                        }
                                    }
                                    SongList(paneFilteredSongs, ui.currentId, ui.isPlaying, ui.favorites, { song -> a.play(song, paneFilteredSongs); showPlayer = true }, a.toggleFavorite, Modifier.weight(1f), onAddToPlaylist = { playlistTargetSongId = it.id; showPlayerAddToPlaylist = true }, onPlayNext = a.playNext)
                                } else {
                                    when {
                                        !ui.hasPermission -> EmptyState("Permiso necesario", "Permite el acceso al audio para mostrar tu biblioteca.", "Conceder permiso", a.requestPermission)
                                        ui.loading -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Lime) }
                                        ui.error != null -> EmptyState("No se pudo leer la biblioteca", ui.error, "Reintentar", a.refresh)
                                        animatedTab == "Listas" -> PlaylistsPane(
                                            playlists = playlists,
                                            songsById = songsById,
                                            onCreate = { showCreatePlaylist = true },
                                            onOpen = { selectedPlaylistId = it.id; section = SECTION_PLAYLISTS },
                                            modifier = Modifier.weight(1f)
                                        )
                                        animatedTab in listOf("Artistas", "Álbumes", "Géneros", "Compositores", "Carpetas") -> {
                                            val header = when (animatedTab) {
                                                "Artistas" -> "ARTISTAS"
                                                "Álbumes" -> "ÁLBUMES"
                                                "Géneros" -> "GÉNEROS"
                                                "Compositores" -> "COMPOSITORES"
                                                else -> "CARPETAS"
                                            }
                                            CountHeader(header, "${paneFilteredGroups.size} grupos")
                                            if (paneFilteredGroups.isEmpty()) EmptyState("Todavía no hay grupos", "No se encontró contenido con ese nombre.", null, {})
                                            else GroupList(paneFilteredGroups, { selectedGroupId = it.id }, Modifier.weight(1f))
                                        }
                                        animatedTab == "Favoritos" -> {
                                            CountHeader("FAVORITOS", "${paneFavoriteSongs.size} canciones")
                                            if (paneFavoriteSongs.isEmpty()) EmptyState("Sin favoritos", "Marca una canción con el corazón para verla aquí.", null, {})
                                            else SongList(paneFavoriteSongs, ui.currentId, ui.isPlaying, ui.favorites, { song -> a.play(song, paneFavoriteSongs); showPlayer = true }, a.toggleFavorite, Modifier.weight(1f), onAddToPlaylist = { playlistTargetSongId = it.id; showPlayerAddToPlaylist = true }, onPlayNext = a.playNext)
                                        }
                                        animatedTab == "Descargas" -> {
                                            CountHeader("DESCARGAS", "${paneDownloadSongs.size} canciones")
                                            if (paneDownloadSongs.isEmpty()) EmptyState("No hay música en Descargas", "Las canciones locales aparecen aquí cuando están dentro de una carpeta de descargas.", "Actualizar biblioteca", a.refresh)
                                            else SongList(paneDownloadSongs, ui.currentId, ui.isPlaying, ui.favorites, { song -> a.play(song, paneDownloadSongs); showPlayer = true }, a.toggleFavorite, Modifier.weight(1f), onAddToPlaylist = { playlistTargetSongId = it.id; showPlayerAddToPlaylist = true }, onPlayNext = a.playNext)
                                        }
                                        else -> {
                                            Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 14.dp, top = 5.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Text("CANCIONES", color = TextMuted, fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
                                                Spacer(Modifier.weight(1f))
                                                SortSongsMenu(sortMode = sortMode, onSelect = { mode ->
                                                    sortMode = mode
                                                    context.getSharedPreferences(PREFS_SETTINGS, android.content.Context.MODE_PRIVATE).edit().putString(PREF_SONG_SORT, mode).apply()
                                                })
                                            }
                                            if (paneFilteredSongs.isEmpty()) EmptyState("No hay canciones", "Añade archivos de música al teléfono y actualiza la biblioteca.", "Actualizar", a.refresh)
                                            else SongList(paneFilteredSongs, ui.currentId, ui.isPlaying, ui.favorites, { song -> a.play(song, paneFilteredSongs); showPlayer = true }, a.toggleFavorite, Modifier.weight(1f), onAddToPlaylist = { playlistTargetSongId = it.id; showPlayerAddToPlaylist = true }, onPlayNext = a.playNext)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                }

                ui.message?.let { message ->
                    Box(Modifier.align(Alignment.BottomCenter).padding(12.dp).clip(RoundedCornerShape(14.dp)).background(SurfaceLight).border(1.dp, NeonViolet.copy(alpha = .35f), RoundedCornerShape(14.dp)).padding(horizontal = 16.dp, vertical = 12.dp)) {
                        Text(message, color = TextMain, fontSize = 13.sp)
                    }
                }
            }

            if (current != null) {
                MiniPlayer(
                    song = current,
                    isPlaying = ui.isPlaying,
                    position = position,
                    duration = ui.duration,
                    onOpen = { showPlayer = true },
                    onPrevious = a.previous,
                    onTogglePlay = a.togglePlay,
                    onNext = a.next
                )
            }
            // Navigation follows Samsung Music's top category tabs. Profile, queue and settings
            // are available through the top-right overflow menu.
            }
        }
        }

        val playlistTargetSong = playlistTargetSongId?.let(songsById::get)
        if (showPlayerAddToPlaylist && playlistTargetSong != null) {
            PlayerAddToPlaylistDialog(
                song = playlistTargetSong,
                playlists = playlists,
                onDismiss = { showPlayerAddToPlaylist = false; playlistTargetSongId = null },
                onSelectPlaylist = { playlist ->
                    persistPlaylists(playlists.map { item ->
                        if (item.id == playlist.id) item.copy(songIds = (item.songIds + playlistTargetSong.id).distinct()) else item
                    })
                    showPlayerAddToPlaylist = false
                    playlistTargetSongId = null
                },
                onCreateNew = {
                    songToAddToNewPlaylist = playlistTargetSong.id
                    showPlayerAddToPlaylist = false
                    playlistTargetSongId = null
                    showCreatePlaylist = true
                }
            )
        }

        if (showCreatePlaylist) {
            CreatePlaylistDialog(
                onDismiss = { showCreatePlaylist = false; songToAddToNewPlaylist = null },
                onCreate = { name ->
                    val songId = songToAddToNewPlaylist
                    val playlist = MusicPlaylist(
                        System.currentTimeMillis().toString(),
                        name,
                        songId?.let { listOf(it) } ?: emptyList()
                    )
                    persistPlaylists(playlists + playlist)
                    if (songId == null) {
                        selectedPlaylistId = playlist.id
                        section = SECTION_PLAYLISTS
                    }
                    songToAddToNewPlaylist = null
                    showCreatePlaylist = false
                }
            )
        }
        if (showAddSongs && selectedPlaylist != null) {
            AddSongsDialog(
                songs = songs,
                selectedIds = selectedPlaylist.songIds.toSet(),
                onDismiss = { showAddSongs = false },
                onConfirm = { ids ->
                    persistPlaylists(playlists.map { item -> if (item.id == selectedPlaylist.id) item.copy(songIds = ids.toList()) else item })
                    showAddSongs = false
                }
            )
        }
    }
}

@Composable
private fun HomePane(
    songs: List<Song>,
    allSongs: List<Song>,
    personalMix: List<Song>,
    mixUsesFavorites: Boolean,
    playlists: List<MusicPlaylist>,
    songsById: Map<Long, Song>,
    onPlay: (Song, List<Song>) -> Unit,
    onOpenAll: () -> Unit,
    onOpenLibrary: () -> Unit,
    onOpenPlaylist: (MusicPlaylist) -> Unit
) {
    val featured = personalMix.firstOrNull() ?: songs.firstOrNull()
    val displaySongs = songs.take(4)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 12.dp)) {
        Row(Modifier.fillMaxWidth().padding(start = 22.dp, end = 22.dp, top = 18.dp, bottom = 9.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Vuelve a escuchar", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = onOpenAll, contentPadding = PaddingValues(horizontal = 2.dp)) { Text("Ver todo  ›", color = Lime, fontSize = 12.sp) }
        }
        if (displaySongs.isEmpty()) {
            EmptyState("Tu música te espera", "Añade archivos al teléfono y actualiza la biblioteca para empezar.", null, {})
        } else {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                displaySongs.forEach { song ->
                    Column(Modifier.width(84.dp).clickable { onPlay(song, allSongs) }) {
                        AlbumArtwork(song, Modifier.size(84.dp).clip(RoundedCornerShape(13.dp)), 30.dp)
                        Spacer(Modifier.height(7.dp))
                        Text(song.title, color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(song.artist, color = TextMuted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(start = 22.dp, end = 22.dp, top = 23.dp, bottom = 11.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Hecho para ti", color = TextMain, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("Mix personal", color = TextMuted, fontSize = 11.sp)
        }
        if (featured != null) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp).clip(RoundedCornerShape(17.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF4F1E76), Color(0xFF17133C), Color(0xFF1C1431))))
                    .border(1.dp, NeonPink.copy(alpha = .22f), RoundedCornerShape(17.dp)).clickable { onPlay(featured, personalMix.ifEmpty { allSongs }) }.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AlbumArtwork(featured, Modifier.size(112.dp).clip(RoundedCornerShape(13.dp)), 34.dp, 320)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(featured.title, color = TextMain, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(4.dp))
                    Text(featured.artist, color = Color(0xFFD8C9E9), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (mixUsesFavorites) "${personalMix.size} canciones · basado en tus favoritos"
                        else "Marca canciones con ♥ para personalizar este mix",
                        color = TextMuted, fontSize = 10.sp, maxLines = 2
                    )
                    Spacer(Modifier.height(9.dp))
                    Box(Modifier.clip(RoundedCornerShape(30.dp)).background(Brush.horizontalGradient(listOf(NeonPink, NeonViolet))).clickable { onPlay(featured, personalMix.ifEmpty { allSongs }) }.padding(horizontal = 18.dp, vertical = 8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Reproducir", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(start = 22.dp, end = 22.dp, top = 23.dp, bottom = 11.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Listas por estado de ánimo", color = TextMain, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = onOpenAll, contentPadding = PaddingValues(horizontal = 2.dp)) { Text("Ver todo  ›", color = Lime, fontSize = 12.sp) }
        }
        val moodItems = playlists.take(4)
        if (moodItems.isNotEmpty()) {
            moodItems.chunked(2).forEach { rowItems ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    rowItems.forEach { playlist ->
                        val coverSong = playlist.songIds.firstNotNullOfOrNull { songsById[it] }
                        Row(Modifier.weight(1f).height(84.dp).clip(RoundedCornerShape(13.dp)).background(SurfaceDark).clickable { onOpenPlaylist(playlist) }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (coverSong != null) AlbumArtwork(coverSong, Modifier.size(62.dp).clip(RoundedCornerShape(9.dp)), 22.dp)
                            else Box(Modifier.size(62.dp).clip(RoundedCornerShape(9.dp)).background(Brush.linearGradient(listOf(NeonViolet, NeonPink))), contentAlignment = Alignment.Center) { Icon(Icons.Default.QueueMusic, null, tint = Color.White) }
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(playlist.name, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(songsLabel(playlist.songIds.size), color = TextMuted, fontSize = 9.sp)
                            }
                        }
                    }
                    if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("Chill", "Focus").forEachIndexed { index, label ->
                    val song = displaySongs.getOrNull(index)
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(13.dp)).background(SurfaceDark).clickable { if (song != null) onPlay(song, allSongs) else onOpenLibrary() }.padding(9.dp)) {
                        if (song != null) AlbumArtwork(song, Modifier.fillMaxWidth().height(96.dp).clip(RoundedCornerShape(9.dp)), 28.dp)
                        else Box(Modifier.fillMaxWidth().height(96.dp).clip(RoundedCornerShape(9.dp)).background(Brush.linearGradient(listOf(NeonViolet, NeonPink))), contentAlignment = Alignment.Center) { Icon(Icons.Default.GraphicEq, null, tint = Color.White, modifier = Modifier.size(34.dp)) }
                        Spacer(Modifier.height(7.dp))
                        Text(label, color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Selección ẞeta", color = TextMuted, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfilePane(
    songCount: Int,
    favoritesCount: Int,
    playlistCount: Int,
    onFavorites: () -> Unit,
    onQueue: () -> Unit,
    onSettings: () -> Unit,
    onRefresh: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 14.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("TU ESPACIO", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
                Text("Tu música.", color = TextMain, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = (-.7).sp)
                Text("Tus momentos, en un solo lugar.", color = TextMuted, fontSize = 13.sp)
            }
            Box(Modifier.size(62.dp).clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFFB5D7FF).copy(alpha = .95f), Color(0xFF7B8BFF), Color(0xFFBC92F5))))
                .border(1.5.dp, Color.White.copy(alpha = .65f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Person, null, tint = Color.White, modifier = Modifier.size(31.dp))
            }
        }
        Spacer(Modifier.height(22.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(27.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF23252D), Color(0xFF16171D), Color(0xFF26202E))))
                .border(1.dp, Color.White.copy(alpha = .12f), RoundedCornerShape(27.dp))
                .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("TU BIBLIOTECA", color = Color(0xFFBFC3D0), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Spacer(Modifier.height(5.dp))
                Text("Una banda sonora\npara cada día", color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Bold, lineHeight = 25.sp)
                Spacer(Modifier.height(9.dp))
                Text("ẞetaMusic · Colección personal", color = TextMuted, fontSize = 11.sp)
            }
            Box(Modifier.size(82.dp).clip(RoundedCornerShape(22.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF5B6EE1), Color(0xFF9A76D8), Color(0xFFDBA9D2))))
                .border(1.dp, Color.White.copy(alpha = .2f), RoundedCornerShape(22.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.GraphicEq, null, tint = Color.White, modifier = Modifier.size(47.dp))
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ProfileStat("Canciones", songCount.toString(), Modifier.weight(1f), Icons.Default.MusicNote)
            ProfileStat("Favoritos", favoritesCount.toString(), Modifier.weight(1f), Icons.Default.Favorite)
            ProfileStat("Listas", playlistCount.toString(), Modifier.weight(1f), Icons.Default.QueueMusic)
        }
        Spacer(Modifier.height(26.dp))
        Text("TU MÚSICA", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(9.dp))
        ProfileAction(Icons.Default.FavoriteBorder, "Tus favoritos", "$favoritesCount canciones guardadas", onFavorites)
        ProfileAction(Icons.Default.QueueMusic, "Cola de reproducción", "Gestiona la próxima escucha", onQueue)
        ProfileAction(Icons.Default.Refresh, "Actualizar biblioteca", "Buscar audio nuevo en el dispositivo", onRefresh)
        Spacer(Modifier.height(23.dp))
        Text("PREFERENCIAS", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(9.dp))
        ProfileAction(Icons.Default.Tune, "Personalizar ẞetaMusic", "Apariencia, colores y pestañas", onSettings)
        Spacer(Modifier.height(22.dp))
        Text("Diseñada para acompañar tu día", color = TextMuted, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun ProfileStat(label: String, value: String, modifier: Modifier = Modifier, icon: androidx.compose.ui.graphics.vector.ImageVector = Icons.Default.Circle) {
    Column(
        modifier.clip(RoundedCornerShape(22.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF202129), Color(0xFF14151A))))
            .border(1.dp, Color.White.copy(alpha = .09f), RoundedCornerShape(22.dp))
            .padding(horizontal = 6.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = Color(0xFFB9C8FF), modifier = Modifier.size(18.dp))
        Spacer(Modifier.height(8.dp))
        Text(value, color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Black)
        Text(label, color = TextMuted, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun ProfileAction(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(19.dp))
            .background(Color(0xFF17181E)).border(1.dp, Color.White.copy(alpha = .065f), RoundedCornerShape(19.dp))
            .clickable(onClick = onClick).padding(horizontal = 13.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF718CFA).copy(alpha = .26f), Color(0xFFC0A5FF).copy(alpha = .15f)))), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Color(0xFFBAC8FF), modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = TextMain, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = TextMuted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Color(0xFF878B99))
    }
}

private fun buildPersonalMix(songs: List<Song>, favorites: Set<Long>, current: Song?): List<Song> {
    if (songs.isEmpty()) return emptyList()
    val likedSongs = songs.filter { it.id in favorites }
    val seeds = likedSongs.ifEmpty { listOfNotNull(current) }
    val artists = seeds.map { it.artist.trim().lowercase(Locale.ROOT) }.filter { it.isNotBlank() }.groupingBy { it }.eachCount()
    val albums = seeds.map { it.album.trim().lowercase(Locale.ROOT) }.filter { it.isNotBlank() }.groupingBy { it }.eachCount()
    val currentArtist = current?.artist?.trim()?.lowercase(Locale.ROOT)
    val currentAlbum = current?.album?.trim()?.lowercase(Locale.ROOT)
    return songs.sortedWith(
        compareByDescending<Song> { song ->
            val artist = song.artist.trim().lowercase(Locale.ROOT)
            val album = song.album.trim().lowercase(Locale.ROOT)
            (if (song.id in favorites) 1000 else 0) +
                (if (song.id == current?.id) 100 else 0) +
                (artists[artist] ?: 0) * 35 +
                (albums[album] ?: 0) * 16 +
                (if (artist.isNotBlank() && artist == currentArtist) 22 else 0) +
                (if (album.isNotBlank() && album == currentAlbum) 10 else 0)
        }.thenBy { song -> song.title.lowercase(Locale.ROOT) }
    )
}

private fun songMatches(song: Song, query: String): Boolean =
    query.isBlank() || listOf(song.title, song.artist, song.album, song.folder).any { it.contains(query, true) }

private fun songsLabel(n: Int) = if (n == 1) "1 canción" else "$n canciones"

private fun buildGroups(songs: List<Song>, tab: String): List<LibraryGroup> {
    val byTitle = compareBy<Song> { it.title.lowercase(Locale.getDefault()) }
    val grouped: List<LibraryGroup> = when (tab) {
        "Artistas" -> songs.groupBy { it.artist }.map { (name, list) ->
            val tracks = list.sortedWith(byTitle)
            LibraryGroup("artist:$name", name, songsLabel(tracks.size), tracks)
        }
        "Álbumes" -> songs.groupBy { "${it.albumId}:${it.album}" }.map { (key, list) ->
            val tracks = list.sortedWith(byTitle)
            val first = tracks.first()
            LibraryGroup("album:$key", first.album, "${first.artist} · ${songsLabel(tracks.size)}", tracks)
        }
        "Géneros" -> songs.groupBy { it.genre }.map { (name, list) ->
            val tracks = list.sortedWith(byTitle)
            LibraryGroup("genre:$name", name, songsLabel(tracks.size), tracks)
        }
        "Compositores" -> songs.groupBy { it.composer }.map { (name, list) ->
            val tracks = list.sortedWith(byTitle)
            LibraryGroup("composer:$name", name, songsLabel(tracks.size), tracks)
        }
        "Carpetas" -> songs.groupBy { it.folder }.map { (folder, list) ->
            val tracks = list.sortedWith(byTitle)
            LibraryGroup(
                "folder:$folder",
                folder.substringAfterLast('/').ifBlank { "Almacenamiento" },
                songsLabel(tracks.size),
                tracks
            )
        }
        else -> emptyList()
    }
    return grouped.sortedBy { it.title.lowercase(Locale.getDefault()) }
}

// ───────────────────────────── Componentes ─────────────────────────────
@Composable
private fun LibraryTabs(selectedTab: String, tabs: List<String>, onTabSelected: (String) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        tabs.forEach { label ->
            val selected = selectedTab == label
            val textColor by animateColorAsState(
                targetValue = if (selected) TextMain else TextMuted,
                animationSpec = tween(160),
                label = "libraryTabText_$label"
            )
            Column(
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .clickable { onTabSelected(label) }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = label,
                    color = textColor,
                    fontSize = 14.sp,
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                    maxLines = 1
                )
                Spacer(Modifier.height(7.dp))
                Box(
                    Modifier
                        .width(if (selected) 22.dp else 4.dp)
                        .height(3.dp)
                        .clip(CircleShape)
                        .background(if (selected) Lime else Color.Transparent)
                )
            }
        }
    }
}

@Composable
private fun TopHeader(
    onSearch: () -> Unit,
    onProfile: () -> Unit,
    onFavorites: () -> Unit,
    onQueue: () -> Unit,
    onSettings: () -> Unit,
    onRefresh: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 8.dp, bottom = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(31.dp).clip(CircleShape).background(Lime.copy(alpha = .16f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.MusicNote, null, tint = Lime, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(9.dp))
        Text("ẞetaMusic", color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-.45).sp)
        Spacer(Modifier.weight(1f))
        IconButton(onClick = onSearch, modifier = Modifier.size(42.dp)) {
            Icon(Icons.Default.Search, "Buscar canciones", tint = TextMain, modifier = Modifier.size(24.dp))
        }
        Box {
            IconButton(onClick = { menuExpanded = true }, modifier = Modifier.size(42.dp)) {
                Icon(Icons.Default.MoreVert, "Más opciones", tint = TextMain, modifier = Modifier.size(24.dp))
            }
            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false },
                containerColor = Color(0xEB171820),
                shape = RoundedCornerShape(18.dp),
                tonalElevation = 8.dp,
                shadowElevation = 14.dp
            ) {
                DropdownMenuItem(
                    text = { Text("Favoritos") },
                    leadingIcon = { Icon(Icons.Default.FavoriteBorder, null) },
                    onClick = { menuExpanded = false; onFavorites() }
                )
                DropdownMenuItem(
                    text = { Text("Cola de reproducción") },
                    leadingIcon = { Icon(Icons.Default.QueueMusic, null) },
                    onClick = { menuExpanded = false; onQueue() }
                )
                DropdownMenuItem(
                    text = { Text("Perfil") },
                    leadingIcon = { Icon(Icons.Default.Person, null) },
                    onClick = { menuExpanded = false; onProfile() }
                )
                HorizontalDivider(color = SurfaceLight)
                DropdownMenuItem(
                    text = { Text("Apariencia") },
                    leadingIcon = { Icon(Icons.Default.Palette, null) },
                    onClick = { menuExpanded = false; onSettings() }
                )
                DropdownMenuItem(
                    text = { Text("Actualizar biblioteca") },
                    leadingIcon = { Icon(Icons.Default.Refresh, null) },
                    onClick = { menuExpanded = false; onRefresh() }
                )
            }
        }
    }
}

@Composable
private fun SearchField(query: String, animated: Boolean = false, onChange: (String) -> Unit) {
    val transition = rememberInfiniteTransition(label = "searchFocus")
    val pulse by transition.animateFloat(
        initialValue = 0.22f,
        targetValue = if (animated) 0.94f else 0.22f,
        animationSpec = infiniteRepeatable(tween(1050), repeatMode = RepeatMode.Reverse),
        label = "searchFocusPulse"
    )
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier.padding(horizontal = 18.dp, vertical = 6.dp).fillMaxWidth().height(50.dp)
            .clip(shape)
            .background(SurfaceDark)
            .border(if (animated) 1.7.dp else 1.dp, if (animated) Lime.copy(alpha = pulse) else if (query.isNotEmpty()) Lime.copy(alpha = .62f) else Color.White.copy(alpha = .10f), shape)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Search, null, tint = if (query.isNotEmpty()) Lime else TextMuted, modifier = Modifier.size(21.dp))
        Spacer(Modifier.width(11.dp))
        BasicTextField(
            value = query,
            onValueChange = onChange,
            modifier = Modifier.weight(1f).fillMaxHeight(),
            textStyle = TextStyle(color = TextMain, fontSize = 14.sp),
            cursorBrush = SolidColor(Lime),
            singleLine = true,
            decorationBox = { innerTextField ->
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.CenterStart) {
                    if (query.isEmpty()) Text("Buscar canciones, artistas o álbumes", color = TextMuted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    innerTextField()
                }
            }
        )
        if (query.isNotEmpty()) {
            IconButton(onClick = { onChange("") }, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Close, "Limpiar búsqueda", tint = TextMuted, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun CountHeader(overline: String, count: String) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 14.dp)) {
        Text(overline, color = TextMuted, fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
        Text(count, color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SongList(
    songs: List<Song>,
    currentId: Long?,
    isPlaying: Boolean,
    favorites: Set<Long>,
    onPlay: (Song) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    modifier: Modifier = Modifier,
    onAddToPlaylist: (Song) -> Unit = {},
    onPlayNext: (Song) -> Unit = {}
) {
    LazyColumn(
        modifier,
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        items(songs, key = { it.id }) { song ->
            val active = song.id == currentId
            var menuExpanded by remember(song.id) { mutableStateOf(false) }
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                    .background(if (active) SurfaceLight else Color.Transparent)
                    .clickable { onPlay(song) }
                    .padding(start = 10.dp, top = 7.dp, bottom = 7.dp, end = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AlbumArtwork(song, Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)), 23.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(song.title, color = if (active) Lime else TextMain, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                    Spacer(Modifier.height(3.dp))
                    Text("${song.artist} · ${song.album}", color = TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
                }
                if (active && isPlaying) {
                    Icon(Icons.Default.GraphicEq, "Sonando", tint = Lime, modifier = Modifier.padding(horizontal = 4.dp).size(18.dp))
                }
                Text(formatTime(song.durationMs), color = TextMuted, fontSize = 11.sp)
                IconButton(onClick = { onToggleFavorite(song) }, modifier = Modifier.size(38.dp)) {
                    val fav = song.id in favorites
                    Icon(
                        if (fav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        if (fav) "Quitar de favoritos" else "Añadir a favoritos",
                        tint = if (fav) Lime else TextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Box {
                    IconButton(onClick = { menuExpanded = true }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.MoreVert, "Opciones de ${song.title}", tint = TextMuted, modifier = Modifier.size(20.dp))
                    }
                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false },
                        containerColor = Color(0xEC191A22),
                        shape = RoundedCornerShape(18.dp),
                        tonalElevation = 8.dp,
                        shadowElevation = 14.dp
                    ) {
                        DropdownMenuItem(
                            text = { Text("Reproducir a continuación") },
                            leadingIcon = { Icon(Icons.Default.PlaylistPlay, null) },
                            onClick = { menuExpanded = false; onPlayNext(song) }
                        )
                        DropdownMenuItem(
                            text = { Text("Añadir a lista") },
                            leadingIcon = { Icon(Icons.Default.PlaylistAdd, null) },
                            onClick = { menuExpanded = false; onAddToPlaylist(song) }
                        )
                        DropdownMenuItem(
                            text = { Text(if (song.id in favorites) "Quitar de favoritos" else "Añadir a favoritos") },
                            leadingIcon = { Icon(if (song.id in favorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null) },
                            onClick = { menuExpanded = false; onToggleFavorite(song) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GroupList(groups: List<LibraryGroup>, onOpen: (LibraryGroup) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(
        modifier,
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        items(groups, key = { it.id }) { group ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp))
                    .background(SurfaceDark).clickable { onOpen(group) }
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AlbumArtwork(group.coverSong, Modifier.size(58.dp).clip(RoundedCornerShape(12.dp)), 25.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(group.title, color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(4.dp))
                    Text(group.subtitle, color = TextMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Icon(Icons.Default.ChevronRight, null, tint = Lime)
            }
        }
    }
}

@Composable
private fun QueuePane(ui: UiState, songsById: Map<Long, Song>, a: UiActions) {
    val entries = remember(ui.queueVersion, songsById) { a.readQueue(songsById) }
    val latestEntries = rememberUpdatedState(entries)
    val listState = rememberLazyListState()
    LaunchedEffect(entries.size) {
        val idx = entries.indexOfFirst { it.song.id == ui.currentId }
        if (idx > 0) listState.scrollToItem(idx)
    }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(if (ui.shuffle) "ORDEN ALEATORIO" else "ORDEN NORMAL", color = TextMuted, fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
                Text(songsLabel(entries.size), color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
        }
        if (entries.isEmpty()) {
            EmptyState(
                title = "La cola está vacía",
                message = "Toca una canción de tu biblioteca para empezar a reproducir.",
                action = null,
                onAction = {}
            )
        } else {
            LazyColumn(
                Modifier.weight(1f),
                state = listState,
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(entries, key = { it.key }) { entry ->
                    val active = entry.song.id == ui.currentId
                    var dragOffset by remember(entry.key) { mutableFloatStateOf(0f) }
                    val reorderModifier = if (!ui.shuffle) Modifier.pointerInput(entry.key, entries.size) {
                        var dragDistance = 0f
                        val threshold = 62.dp.toPx()
                        detectDragGesturesAfterLongPress(
                            onDragStart = { dragDistance = 0f; dragOffset = 0f },
                            onDragEnd = { dragDistance = 0f; dragOffset = 0f },
                            onDragCancel = { dragDistance = 0f; dragOffset = 0f },
                            onDrag = { change, amount ->
                                change.consume()
                                dragDistance += amount.y
                                dragOffset = dragDistance
                                val steps = (dragDistance / threshold).toInt()
                                if (steps != 0) {
                                    val liveEntries = latestEntries.value
                                    val fromPosition = liveEntries.indexOfFirst { it.key == entry.key }
                                    if (fromPosition >= 0) {
                                        val targetPosition = (fromPosition + steps).coerceIn(0, (liveEntries.size - 1).coerceAtLeast(0))
                                        val target = liveEntries.getOrNull(targetPosition)
                                        val from = liveEntries.getOrNull(fromPosition)
                                        if (target != null && from != null && target.index != from.index) {
                                            // Reorder immediately when the finger crosses a row; the lazy list animates the snap.
                                            a.moveQueueItem(from.index, target.index)
                                            dragDistance -= (targetPosition - fromPosition) * threshold
                                        } else {
                                            dragDistance = dragDistance.coerceIn(-threshold * .45f, threshold * .45f)
                                        }
                                    }
                                    dragOffset = dragDistance
                                }
                            }
                        )
                    } else Modifier
                    Row(
                        Modifier.fillMaxWidth().animateItem().then(reorderModifier)
                            .graphicsLayer {
                                translationY = dragOffset
                                val isDragging = kotlin.math.abs(dragOffset) > 1f
                                scaleX = if (isDragging) 1.025f else 1f
                                scaleY = if (isDragging) 1.025f else 1f
                                shadowElevation = if (isDragging) 18.dp.toPx() else 0f
                            }
                            .clip(RoundedCornerShape(15.dp))
                            .background(if (kotlin.math.abs(dragOffset) > 1f) Color(0xFF292A35) else if (active) SurfaceLight else Color.Transparent)
                            .border(if (kotlin.math.abs(dragOffset) > 1f) 1.dp else 0.dp, Lime.copy(alpha = .45f), RoundedCornerShape(15.dp))
                            .clickable { a.playQueueItem(entry.index) }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AlbumArtwork(entry.song, Modifier.size(46.dp).clip(RoundedCornerShape(10.dp)), 20.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(entry.song.title, color = if (active) Lime else TextMain, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                            Text(entry.song.artist, color = TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
                        }
                        if (active) Icon(Icons.Default.GraphicEq, "Sonando ahora", tint = Lime, modifier = Modifier.size(18.dp))
                        if (!ui.shuffle) Icon(Icons.Default.DragHandle, "Mantén pulsado para reordenar", tint = TextMuted.copy(alpha = .72f), modifier = Modifier.padding(start = 7.dp).size(20.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomBar(section: String, onSelect: (String) -> Unit) {
    val selectedDestination = when (section) {
        SECTION_HOME -> SECTION_HOME
        SECTION_SEARCH -> SECTION_SEARCH
        SECTION_LIBRARY, SECTION_PLAYLISTS -> SECTION_LIBRARY
        else -> SECTION_PROFILE
    }
    Row(
        Modifier.fillMaxWidth().background(Bg).border(width = 0.5.dp, color = Color.White.copy(alpha = .05f)).padding(horizontal = 7.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        listOf(
            Triple(SECTION_HOME, Icons.Default.Home, "Inicio"),
            Triple(SECTION_SEARCH, Icons.Default.MusicNote, "Songs"),
            Triple(SECTION_LIBRARY, Icons.Default.Equalizer, "Biblioteca"),
            Triple(SECTION_PROFILE, Icons.Default.Person, "Perfil")
        ).forEach { (id, icon, label) ->
            val selected = selectedDestination == id
            val navTint by animateColorAsState(
                targetValue = if (selected) Lime else TextMuted,
                animationSpec = tween(durationMillis = 180),
                label = "navTint_$id"
            )
            val markerWidth by animateDpAsState(
                targetValue = if (selected) 17.dp else 0.dp,
                animationSpec = tween(durationMillis = 220),
                label = "navMarker_$id"
            )
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable { onSelect(id) }.padding(top = 5.dp, bottom = 3.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(icon, contentDescription = label, tint = navTint, modifier = Modifier.size(23.dp))
                Spacer(Modifier.height(3.dp))
                Text(label, color = navTint, fontSize = 9.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                Spacer(Modifier.height(4.dp))
                Box(Modifier.width(markerWidth).height(2.dp).clip(CircleShape).background(Brush.horizontalGradient(listOf(NeonPink, NeonViolet))))
            }
        }
    }
}

// ───────────────────────────── Portadas ─────────────────────────────
private object ArtCache {
    private val cache = object : LruCache<Long, Bitmap>(((Runtime.getRuntime().maxMemory() / 1024) / 12).toInt()) {
        override fun sizeOf(key: Long, value: Bitmap): Int = value.byteCount / 1024
    }
    private val withoutArt: MutableSet<Long> = ConcurrentHashMap.newKeySet()

    private fun key(song: Song, px: Int): Long = song.id or (px.toLong() shl 40)

    fun get(song: Song, px: Int): Bitmap? = cache.get(key(song, px))
    fun put(song: Song, px: Int, bitmap: Bitmap) { cache.put(key(song, px), bitmap) }
    fun hasNoArt(song: Song): Boolean = song.id in withoutArt
    fun markNoArt(song: Song) { withoutArt.add(song.id) }
}

@RequiresApi(29)
private fun loadThumbnail(resolver: ContentResolver, uri: Uri, px: Int): Bitmap? =
    runCatching { resolver.loadThumbnail(uri, Size(px, px), null) }.getOrNull()

@Composable
private fun AlbumArtwork(song: Song?, modifier: Modifier = Modifier, iconSize: Dp = 28.dp, px: Int = 256) {
    val context = LocalContext.current
    val bitmap by produceState<Bitmap?>(
        song?.let { ArtCache.get(it, px) },
        song?.id,
        px
    ) {
        val s = song
        if (s == null || Build.VERSION.SDK_INT < 29) {
            value = null
            return@produceState
        }
        val cached = ArtCache.get(s, px)
        if (cached != null) {
            value = cached
            return@produceState
        }
        if (!ArtCache.hasNoArt(s)) {
            // MediaStore providers differ between manufacturers/Android versions. A broken
            // album-art URI must never crash scrolling the LazyColumn.
            val bmp = runCatching {
                withContext(Dispatchers.IO) { loadCoverBitmap(context, s, px) }
            }.getOrNull()
            if (bmp != null && !bmp.isRecycled) {
                ArtCache.put(s, px, bmp)
                value = bmp
            } else {
                ArtCache.markNoArt(s)
            }
        }
    }
    // En Android 8 y 9 se usa el proveedor clásico de carátulas de álbum.
    val legacyUri = remember(song?.albumId) {
        if (Build.VERSION.SDK_INT < 29) {
            song?.albumId?.takeIf { it > 0 }?.let { ContentUris.withAppendedId(ArtBase, it) }
        } else null
    }
    Box(modifier.background(SurfaceDark), contentAlignment = Alignment.Center) {
        Icon(Icons.Default.Album, contentDescription = null, tint = Lime, modifier = Modifier.size(iconSize))
        val bmp = bitmap
        if (bmp != null) {
            BitmapImage(
                bitmap = bmp.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else if (legacyUri != null) {
            AsyncImage(
                model = legacyUri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

// ───────────────────────────── Reproductor ─────────────────────────────
@Composable
private fun MiniPlayer(
    song: Song,
    isPlaying: Boolean,
    position: () -> Long,
    duration: Long,
    onOpen: () -> Unit,
    onPrevious: () -> Unit,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit
) {
    val fraction = if (duration > 0) (position().toFloat() / duration).coerceIn(0f, 1f) else 0f
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(SurfaceDark)
            .border(1.dp, Color.White.copy(alpha = .09f), RoundedCornerShape(14.dp))
    ) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(start = 8.dp, top = 7.dp, end = 7.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AlbumArtwork(song, Modifier.size(43.dp).clip(RoundedCornerShape(9.dp)), 20.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(song.title, color = TextMain, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
                Text(song.artist, color = TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 10.sp)
            }
            IconButton(onClick = onTogglePlay, modifier = Modifier.size(40.dp)) {
                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, if (isPlaying) "Pausar" else "Reproducir", tint = Color.White, modifier = Modifier.size(25.dp))
            }
            IconButton(onClick = onOpen, modifier = Modifier.size(33.dp)) {
                Icon(Icons.Default.KeyboardArrowUp, "Abrir reproductor", tint = TextMuted, modifier = Modifier.size(22.dp))
            }
        }
        Canvas(Modifier.fillMaxWidth().height(2.dp)) {
            drawLine(SurfaceLight, Offset(0f, size.height / 2), Offset(size.width, size.height / 2), size.height)
            val endX = size.width * fraction
            if (endX > 0f) drawLine(Lime, Offset(0f, size.height / 2), Offset(endX, size.height / 2), size.height)
        }
    }
}

@Composable
private fun ProgressSection(position: () -> Long, duration: Long, onSeek: (Long) -> Unit, accent: Color = Lime) {
    var dragValue by remember { mutableStateOf<Float?>(null) }
    val current = position().coerceIn(0L, duration.coerceAtLeast(0L)).toFloat()
    val shown = (dragValue ?: current).coerceIn(0f, duration.coerceAtLeast(0L).toFloat())
    Column(Modifier.fillMaxWidth()) {
        Canvas(
            Modifier.fillMaxWidth().height(32.dp)
                .pointerInput(duration) {
                    detectTapGestures { offset ->
                        if (duration > 0 && size.width > 0) {
                            onSeek((duration * (offset.x / size.width.toFloat()).coerceIn(0f, 1f)).toLong())
                        }
                    }
                }
                .pointerInput(duration) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            if (duration > 0 && size.width > 0) dragValue = duration * (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                        },
                        onDragEnd = {
                            dragValue?.let { onSeek(it.toLong()) }
                            dragValue = null
                        },
                        onDragCancel = { dragValue = null }
                    ) { change, _ ->
                        change.consume()
                        if (duration > 0 && size.width > 0) dragValue = duration * (change.position.x / size.width.toFloat()).coerceIn(0f, 1f)
                    }
                }
        ) {
            val centerY = size.height / 2f
            val fraction = if (duration > 0L) (shown / duration.toFloat()).coerceIn(0f, 1f) else 0f
            val step = 4.dp.toPx()
            val barWidth = 2.dp.toPx()
            val count = (size.width / step).toInt().coerceAtLeast(1)
            for (index in 0 until count) {
                val x = index * step + barWidth / 2f
                val wave = (0.18f + kotlin.math.abs(kotlin.math.sin(index * 0.51f)) * 0.48f + kotlin.math.abs(kotlin.math.sin(index * 0.19f + 1.2f)) * 0.28f).coerceIn(0.18f, 1f)
                val height = (5.dp.toPx() + 23.dp.toPx() * wave)
                val active = index.toFloat() / count <= fraction
                val color = if (active) accent else SurfaceLight
                drawLine(
                    color = color,
                    start = Offset(x, centerY - height / 2f),
                    end = Offset(x, centerY + height / 2f),
                    strokeWidth = barWidth,
                    cap = StrokeCap.Round
                )
            }
            val endX = (size.width * fraction).coerceIn(0f, size.width)
            drawCircle(accent.copy(alpha = 0.10f), radius = 10.dp.toPx(), center = Offset(endX, centerY))
            drawCircle(accent, radius = 4.dp.toPx(), center = Offset(endX, centerY))
            drawCircle(Color.White, radius = 1.6.dp.toPx(), center = Offset(endX, centerY))
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(shown.toLong()), color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            Text(formatTime(duration), color = TextMuted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun GlassControlBubble(
    accent: Color,
    active: Boolean,
    size: Dp,
    onClick: () -> Unit,
    content: @Composable () -> Unit
) {
    Box(
        Modifier.size(size).clip(CircleShape)
            .background(
                Brush.linearGradient(
                    if (active) listOf(accent.copy(alpha = .25f), Color.White.copy(alpha = .08f), Color.White.copy(alpha = .035f))
                    else listOf(Color.White.copy(alpha = .115f), Color.White.copy(alpha = .035f))
                )
            )
            .border(1.dp, if (active) accent.copy(alpha = .62f) else Color.White.copy(alpha = .18f), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.fillMaxSize().padding(2.dp).clip(CircleShape).background(Brush.verticalGradient(listOf(Color.White.copy(alpha = .12f), Color.Transparent))), contentAlignment = Alignment.Center) {
            content()
        }
    }
}

@Composable
private fun SortSongsMenu(sortMode: String, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        TextButton(onClick = { expanded = true }, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 5.dp)) {
            Icon(Icons.Default.Sort, null, tint = Lime, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(5.dp))
            Text(sortMode, color = TextMain, fontSize = 12.sp, maxLines = 1)
            Icon(Icons.Default.ArrowDropDown, null, tint = TextMuted, modifier = Modifier.size(18.dp))
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            containerColor = Color(0xEC191A22),
            shape = RoundedCornerShape(18.dp),
            tonalElevation = 8.dp,
            shadowElevation = 14.dp
        ) {
            songSortOptions.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option, color = if (option == sortMode) Lime else TextMain) },
                    leadingIcon = { Icon(if (option == sortMode) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked, null, tint = if (option == sortMode) Lime else TextMuted) },
                    onClick = { expanded = false; onSelect(option) }
                )
            }
        }
    }
}

@Composable
private fun NowPlayingScreen(
    song: Song,
    isPlaying: Boolean,
    isFavorite: Boolean,
    shuffle: Boolean,
    repeatMode: Int,
    position: () -> Long,
    duration: Long,
    onBack: () -> Unit,
    onTogglePlay: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onSeek: (Long) -> Unit,
    onToggleFavorite: () -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onOpenQueue: () -> Unit,
    onOpenPlaylists: () -> Unit,
    dynamicColors: Boolean,
    blurBackground: Boolean
) {
    val dominantAccent by rememberDominantCoverColor(song)
    val targetPlayerAccent = if (dynamicColors) dominantAccent else Lime
    val playerAccent by animateColorAsState(targetPlayerAccent, animationSpec = tween(420), label = "dynamicCoverAccent")
    BoxWithConstraints(Modifier.fillMaxSize().background(Bg)) {
        if (blurBackground) {
            AlbumArtwork(song, Modifier.matchParentSize().blur(34.dp).alpha(0.52f), iconSize = 1.dp, px = 320)
            Box(Modifier.matchParentSize().background(Brush.verticalGradient(listOf(Bg.copy(alpha = 0.20f), Bg.copy(alpha = 0.62f), Bg.copy(alpha = 0.96f)))))
        } else {
            CoverGradientBackground(song, Modifier.matchParentSize())
        }
        val cover = minOf(maxWidth - 52.dp, maxOf(210.dp, maxHeight * 0.43f), 350.dp)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 5.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth().height(43.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Default.KeyboardArrowDown, "Cerrar reproductor", tint = TextMain, modifier = Modifier.size(28.dp))
                }
                Spacer(Modifier.weight(1f))
                Text("REPRODUCIENDO", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
                Spacer(Modifier.weight(1f))
                Spacer(Modifier.size(40.dp))
            }

            Spacer(Modifier.height(12.dp))
            var swipeDirection by remember { mutableIntStateOf(1) }
            var coverDragOffset by remember(song.id) { mutableFloatStateOf(0f) }
            val animatedCoverOffset by animateFloatAsState(
                targetValue = coverDragOffset,
                animationSpec = spring(dampingRatio = 0.72f, stiffness = 420f),
                label = "coverDragReturn"
            )
            val playNextWithTransition: () -> Unit = {
                swipeDirection = 1
                onNext()
            }
            val playPreviousWithTransition: () -> Unit = {
                swipeDirection = -1
                onPrevious()
            }
            Box(
                Modifier.size(cover)
                    .graphicsLayer {
                        translationX = animatedCoverOffset
                        rotationZ = if (size.width > 0f) (animatedCoverOffset / size.width * 2.3f).coerceIn(-3f, 3f) else 0f
                        alpha = if (size.width > 0f) 1f - (kotlin.math.abs(animatedCoverOffset / size.width) * 0.14f).coerceIn(0f, 0.14f) else 1f
                    }
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, Color.White.copy(alpha = .10f), RoundedCornerShape(16.dp))
                    .pointerInput(song.id) {
                        detectTapGestures(onDoubleTap = { onTogglePlay() })
                    }
                    .pointerInput(song.id) {
                        detectHorizontalDragGestures(
                            onHorizontalDrag = { change, dragAmount ->
                                change.consume()
                                coverDragOffset = (coverDragOffset + dragAmount).coerceIn(-size.width * 0.78f, size.width * 0.78f)
                            },
                            onDragEnd = {
                                val distance = coverDragOffset
                                coverDragOffset = 0f
                                if (kotlin.math.abs(distance) >= size.width * 0.18f) {
                                    if (distance < 0f) {
                                        playNextWithTransition()
                                    } else {
                                        playPreviousWithTransition()
                                    }
                                }
                            },
                            onDragCancel = { coverDragOffset = 0f }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                AnimatedContent(
                    targetState = song,
                    modifier = Modifier.fillMaxSize(),
                    transitionSpec = {
                        if (swipeDirection >= 0) {
                            (slideInHorizontally(initialOffsetX = { it / 3 }, animationSpec = tween(250)) + fadeIn(tween(220))) togetherWith
                                (slideOutHorizontally(targetOffsetX = { -it / 3 }, animationSpec = tween(190)) + fadeOut(tween(170)))
                        } else {
                            (slideInHorizontally(initialOffsetX = { -it / 3 }, animationSpec = tween(250)) + fadeIn(tween(220))) togetherWith
                                (slideOutHorizontally(targetOffsetX = { it / 3 }, animationSpec = tween(190)) + fadeOut(tween(170)))
                        }
                    },
                    label = "albumCoverSwipeTransition"
                ) { displayedSong ->
                    AlbumArtwork(
                        song = displayedSong,
                        modifier = Modifier.fillMaxSize(),
                        iconSize = 72.dp,
                        px = 640
                    )
                }
            }
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(song.title, color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis, letterSpacing = (-.25).sp)
                    Spacer(Modifier.height(4.dp))
                    Text(song.artist, color = TextMuted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Spacer(Modifier.height(14.dp))
            ProgressSection(position, duration, onSeek, playerAccent)
            Spacer(Modifier.height(12.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                GlassControlBubble(playerAccent, active = shuffle, size = 46.dp, onClick = onToggleShuffle) {
                    Icon(Icons.Default.Shuffle, if (shuffle) "Aleatorio activado" else "Aleatorio desactivado", tint = if (shuffle) playerAccent else TextMain, modifier = Modifier.size(21.dp))
                }
                Box(
                    Modifier.size(53.dp).clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Color.White.copy(alpha = .12f), Color.White.copy(alpha = .035f))))
                        .border(1.dp, Color.White.copy(alpha = .17f), CircleShape)
                        .pointerInput(song.id, duration) {
                            detectTapGestures(
                                onTap = { playPreviousWithTransition() },
                                onLongPress = { onSeek((position() - 10_000L).coerceAtLeast(0L)) }
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.SkipPrevious, "Anterior; mantén pulsado para retroceder", tint = TextMain, modifier = Modifier.size(31.dp))
                }
                Box(
                    Modifier.size(72.dp).clip(CircleShape)
                        .background(Brush.linearGradient(listOf(playerAccent.copy(alpha = .96f), blendColors(playerAccent, Color.White, 0.25f), blendColors(playerAccent, Color.Black, 0.30f))))
                        .border(1.5.dp, Color.White.copy(alpha = .48f), CircleShape)
                        .clickable(onClick = onTogglePlay),
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.fillMaxSize().padding(4.dp).clip(CircleShape).background(Brush.verticalGradient(listOf(Color.White.copy(alpha = .22f), Color.Transparent, Color.Black.copy(alpha = .07f)))), contentAlignment = Alignment.Center) {
                        Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, if (isPlaying) "Pausar" else "Reproducir", tint = Color.White, modifier = Modifier.size(37.dp))
                    }
                }
                Box(
                    Modifier.size(53.dp).clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Color.White.copy(alpha = .12f), Color.White.copy(alpha = .035f))))
                        .border(1.dp, Color.White.copy(alpha = .17f), CircleShape)
                        .pointerInput(song.id, duration) {
                            detectTapGestures(
                                onTap = { playNextWithTransition() },
                                onLongPress = { onSeek((position() + 10_000L).coerceAtMost(duration.coerceAtLeast(0L))) }
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.SkipNext, "Siguiente; mantén pulsado para avanzar", tint = TextMain, modifier = Modifier.size(31.dp))
                }
                GlassControlBubble(playerAccent, active = repeatMode != Player.REPEAT_MODE_OFF, size = 46.dp, onClick = onCycleRepeat) {
                    Icon(
                        if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                        when (repeatMode) { Player.REPEAT_MODE_ONE -> "Repetir una canción"; Player.REPEAT_MODE_ALL -> "Repetir toda la cola"; else -> "Repetición desactivada" },
                        tint = if (repeatMode == Player.REPEAT_MODE_OFF) TextMain else playerAccent,
                        modifier = Modifier.size(21.dp)
                    )
                }
            }
            Spacer(Modifier.height(28.dp))
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                PlayerAction(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorito", onToggleFavorite, if (isFavorite) playerAccent else TextMuted)
                PlayerAction(Icons.Default.PlaylistAdd, "Añadir", onOpenPlaylists, TextMuted)
                PlayerAction(Icons.Default.QueueMusic, "Cola", onOpenQueue, TextMuted)
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun PlayerAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit, tint: Color) {
    Column(
        Modifier.width(76.dp).clip(RoundedCornerShape(15.dp)).clickable(onClick = onClick).padding(vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(35.dp).clip(CircleShape)
                .background(Brush.linearGradient(listOf(SurfaceLight.copy(alpha = .92f), SurfaceDark.copy(alpha = .92f))))
                .border(1.dp, tint.copy(alpha = if (tint == TextMuted) 0.16f else 0.38f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.height(3.dp))
        Text(label, color = if (tint == TextMuted) TextMuted else tint, fontSize = 9.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
private fun PlaylistsPane(
    playlists: List<MusicPlaylist>,
    songsById: Map<Long, Song>,
    onCreate: () -> Unit,
    onOpen: (MusicPlaylist) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("TU MÚSICA, A TU MANERA", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                Text("Listas de reproducción", color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("${playlists.size} listas guardadas", color = TextMuted, fontSize = 12.sp)
            }
            FilledTonalIconButton(onClick = onCreate, colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = Lime, contentColor = OnLime)) {
                Icon(Icons.Default.Add, "Crear lista")
            }
        }
        if (playlists.isEmpty()) {
            EmptyState(
                title = "Crea tu primera lista",
                message = "Agrupa las canciones que te gustan y reprodúcelas en el orden que prefieras.",
                action = "Crear lista",
                onAction = onCreate
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                items(playlists, key = { it.id }) { playlist ->
                    val firstSong = playlist.songIds.firstNotNullOfOrNull { id -> songsById[id] }
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(SurfaceDark)
                            .border(1.dp, Color.White.copy(alpha = .035f), RoundedCornerShape(15.dp)).clickable { onOpen(playlist) }.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (firstSong != null) {
                            AlbumArtwork(firstSong, Modifier.size(70.dp).clip(RoundedCornerShape(12.dp)), 26.dp)
                        } else {
                            Box(Modifier.size(70.dp).clip(RoundedCornerShape(12.dp)).background(SurfaceLight), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.QueueMusic, null, tint = Lime, modifier = Modifier.size(30.dp))
                            }
                        }
                        Spacer(Modifier.width(13.dp))
                        Column(Modifier.weight(1f)) {
                            Text(playlist.name, color = TextMain, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.height(4.dp))
                            Text(songsLabel(playlist.songIds.count { it in songsById }), color = TextMuted, fontSize = 12.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Lime)
                    }
                }
            }
        }
    }
}

@Composable
private fun PlaylistDetailPane(
    playlist: MusicPlaylist,
    songs: List<Song>,
    currentId: Long?,
    isPlaying: Boolean,
    onBack: () -> Unit,
    onAddSongs: () -> Unit,
    onPlay: (Song) -> Unit,
    onRemove: (Song) -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    var confirmDelete by remember(playlist.id) { mutableStateOf(false) }
    Column(modifier) {
        Row(
            Modifier.fillMaxWidth().padding(start = 8.dp, end = 12.dp, top = 6.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver a las listas", tint = Lime) }
            Column(Modifier.weight(1f)) {
                Text(playlist.name, color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(songsLabel(songs.size), color = TextMuted, fontSize = 12.sp)
            }
            IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Default.DeleteOutline, "Eliminar lista", tint = TextMuted) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = onAddSongs,
                colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = OnLime),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.PlaylistAdd, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(7.dp))
                Text("Añadir canciones", maxLines = 1)
            }
            FilledTonalIconButton(
                onClick = { songs.firstOrNull()?.let(onPlay) },
                enabled = songs.isNotEmpty(),
                colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = SurfaceLight, contentColor = Lime)
            ) { Icon(Icons.Default.PlayArrow, "Reproducir lista") }
        }
        if (songs.isEmpty()) {
            EmptyState(
                title = "Esta lista está vacía",
                message = "Añade canciones de tu biblioteca para crear tu propia selección.",
                action = "Añadir canciones",
                onAction = onAddSongs
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 14.dp, end = 12.dp, top = 8.dp, bottom = 14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(songs, key = { it.id }) { song ->
                    val active = song.id == currentId
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                            .background(if (active) SurfaceLight else Color.Transparent)
                            .clickable { onPlay(song) }.padding(start = 8.dp, end = 2.dp, top = 7.dp, bottom = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AlbumArtwork(song, Modifier.size(48.dp).clip(RoundedCornerShape(11.dp)), 22.dp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(song.title, color = if (active) Lime else TextMain, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(song.artist, color = TextMuted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (active && isPlaying) Icon(Icons.Default.GraphicEq, "Sonando", tint = Lime, modifier = Modifier.size(17.dp))
                        IconButton(onClick = { onRemove(song) }) { Icon(Icons.Default.Close, "Quitar de la lista", tint = TextMuted, modifier = Modifier.size(18.dp)) }
                    }
                }
            }
        }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("¿Eliminar esta lista?") },
            text = { Text("Se eliminará «${playlist.name}». Las canciones originales no se borrarán del teléfono.") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("Eliminar", color = Color(0xFFFF7777)) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar", color = TextMuted) } },
            containerColor = SurfaceDark,
            titleContentColor = TextMain,
            textContentColor = TextMuted
        )
    }
}

@Composable
private fun PlayerAddToPlaylistDialog(
    song: Song,
    playlists: List<MusicPlaylist>,
    onDismiss: () -> Unit,
    onSelectPlaylist: (MusicPlaylist) -> Unit,
    onCreateNew: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("Añadir a una playlist", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(3.dp))
                Text(song.title, color = TextMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        },
        text = {
            Column(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(Brush.horizontalGradient(listOf(NeonPink.copy(alpha = .15f), NeonViolet.copy(alpha = .16f))))
                        .clickable(onClick = onCreateNew).padding(horizontal = 12.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(38.dp).clip(CircleShape).background(Brush.linearGradient(listOf(NeonPink, NeonViolet))), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Add, null, tint = Color.White)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Crear nueva playlist", color = TextMain, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text("La canción se añadirá automáticamente", color = TextMuted, fontSize = 10.sp)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = Lime)
                }
                Spacer(Modifier.height(12.dp))
                if (playlists.isEmpty()) {
                    Text("Todavía no tienes playlists. Crea una arriba para guardar esta canción.", color = TextMuted, fontSize = 12.sp, lineHeight = 17.sp)
                } else {
                    Text("TUS PLAYLISTS", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Spacer(Modifier.height(5.dp))
                    LazyColumn(Modifier.fillMaxWidth().heightIn(max = 290.dp)) {
                        items(playlists, key = { it.id }) { playlist ->
                            val alreadyAdded = song.id in playlist.songIds
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                    .clickable { onSelectPlaylist(playlist) }.padding(horizontal = 7.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)).background(SurfaceLight), contentAlignment = Alignment.Center) {
                                    Icon(if (alreadyAdded) Icons.Default.CheckCircle else Icons.Default.QueueMusic, null, tint = if (alreadyAdded) Lime else TextMuted, modifier = Modifier.size(20.dp))
                                }
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(playlist.name, color = TextMain, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(if (alreadyAdded) "La canción ya está añadida" else "${playlist.songIds.size} canciones", color = TextMuted, fontSize = 10.sp)
                                }
                                Icon(Icons.Default.ChevronRight, null, tint = TextMuted, modifier = Modifier.size(19.dp))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Listo", color = Lime) } },
        containerColor = SurfaceDark,
        titleContentColor = TextMain,
        textContentColor = TextMuted
    )
}

@Composable
private fun CreatePlaylistDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nueva lista de reproducción") },
        text = {
            Column {
                Text("Ponle un nombre a tu selección.", color = TextMuted, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(48) },
                    singleLine = true,
                    placeholder = { Text("Ej. Favoritas de noche") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Lime, focusedLabelColor = Lime, cursorColor = Lime)
                )
            }
        },
        confirmButton = { TextButton(onClick = { name.trim().takeIf { it.isNotEmpty() }?.let(onCreate) }, enabled = name.isNotBlank()) { Text("Crear", color = Lime) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar", color = TextMuted) } },
        containerColor = SurfaceDark,
        titleContentColor = TextMain,
        textContentColor = TextMuted
    )
}

@Composable
private fun AddSongsDialog(
    songs: List<Song>,
    selectedIds: Set<Long>,
    onDismiss: () -> Unit,
    onConfirm: (List<Long>) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    val selected = remember(selectedIds) { mutableStateOf(selectedIds.toMutableSet()) }
    val filtered = remember(songs, query) { songs.filter { songMatches(it, query) } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Añadir canciones") },
        text = {
            Column(Modifier.fillMaxWidth()) {
                TextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Buscar en la biblioteca", fontSize = 13.sp) },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = SurfaceLight,
                        unfocusedContainerColor = SurfaceLight,
                        focusedIndicatorColor = Lime,
                        unfocusedIndicatorColor = Color.Transparent,
                        cursorColor = Lime
                    )
                )
                Spacer(Modifier.height(8.dp))
                Text("${selected.value.size} seleccionadas", color = TextMuted, fontSize = 12.sp)
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 360.dp)) {
                    items(filtered, key = { it.id }) { song ->
                        val checked = song.id in selected.value
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                selected.value = selected.value.toMutableSet().apply {
                                    if (contains(song.id)) remove(song.id) else add(song.id)
                                }
                            }.padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AlbumArtwork(song, Modifier.size(38.dp).clip(RoundedCornerShape(8.dp)), 18.dp)
                            Spacer(Modifier.width(9.dp))
                            Column(Modifier.weight(1f)) {
                                Text(song.title, color = TextMain, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(song.artist, color = TextMuted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Checkbox(checked = checked, onCheckedChange = { isChecked ->
                                selected.value = selected.value.toMutableSet().apply { if (isChecked) add(song.id) else remove(song.id) }
                            }, colors = CheckboxDefaults.colors(checkedColor = Lime, checkmarkColor = OnLime))
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(selected.value.toList()) }) { Text("Guardar", color = Lime) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar", color = TextMuted) } },
        containerColor = SurfaceDark,
        titleContentColor = TextMain,
        textContentColor = TextMuted
    )
}

@Composable
private fun SettingsPane(
    selectedAccent: Color,
    onSelectAccent: (Color) -> Unit,
    searchAnimationEnabled: Boolean,
    onSearchAnimationChange: (Boolean) -> Unit,
    dynamicPlayerColorEnabled: Boolean,
    onDynamicPlayerColorChange: (Boolean) -> Unit,
    blurPlayerBackgroundEnabled: Boolean,
    onBlurPlayerBackgroundChange: (Boolean) -> Unit,
    visibleTabs: List<String>,
    onToggleTab: (String, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 12.dp)) {
        Text("APARIENCIA", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(6.dp))
        Text("Personaliza ẞetaMusic", color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text("La biblioteca usa una base neutra; puedes elegir un acento y adaptar los controles a la portada.", color = TextMuted, fontSize = 13.sp, lineHeight = 19.sp)
        Spacer(Modifier.height(22.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Palette, null, tint = Lime, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(9.dp))
            Text("Color de acento", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(6.dp))
        Text("Selecciona una paleta", color = TextMuted, fontSize = 12.sp)
        Spacer(Modifier.height(15.dp))
        accentChoices.chunked(4).forEach { rowChoices ->
            Row(Modifier.fillMaxWidth().padding(bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                rowChoices.forEach { choice ->
                    val chosen = selectedAccent == choice.color
                    Column(
                        Modifier.weight(1f).clickable { onSelectAccent(choice.color) },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier.size(48.dp).border(if (chosen) 3.dp else 1.dp, if (chosen) Color.White else SurfaceLight, CircleShape)
                                .padding(if (chosen) 4.dp else 0.dp).clip(CircleShape).background(choice.color),
                            contentAlignment = Alignment.Center
                        ) {
                            if (chosen) Icon(Icons.Default.Check, null, tint = Color(0xFF101010), modifier = Modifier.size(21.dp))
                        }
                        Spacer(Modifier.height(7.dp))
                        Text(choice.name, color = if (chosen) TextMain else TextMuted, fontSize = 11.sp, fontWeight = if (chosen) FontWeight.Bold else FontWeight.Normal)
                    }
                }
                repeat((4 - rowChoices.size).coerceAtLeast(0)) { Spacer(Modifier.weight(1f)) }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(SurfaceDark).padding(15.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(selectedAccent), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.GraphicEq, null, tint = OnLime, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Vista previa", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Tu color se guarda automáticamente", color = TextMuted, fontSize = 11.sp)
            }
            Box(Modifier.size(42.dp).clip(CircleShape).background(selectedAccent), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Check, null, tint = OnLime, modifier = Modifier.size(22.dp))
            }
        }
        Spacer(Modifier.height(25.dp))
        Text("EXPERIENCIA DEL REPRODUCTOR", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(8.dp))
        PreferenceToggle(
            title = "Animación del buscador",
            subtitle = "Animación suave al enfocar la búsqueda",
            checked = searchAnimationEnabled,
            onCheckedChange = onSearchAnimationChange
        )
        PreferenceToggle(
            title = "Colores según la portada",
            subtitle = "Adapta los controles al color dominante de la canción",
            checked = dynamicPlayerColorEnabled,
            onCheckedChange = onDynamicPlayerColorChange
        )
        PreferenceToggle(
            title = "Fondo ambiental de portada",
            subtitle = "Difumina la portada detrás del reproductor; consume más recursos",
            checked = blurPlayerBackgroundEnabled,
            onCheckedChange = onBlurPlayerBackgroundChange
        )
        Spacer(Modifier.height(24.dp))
        Text("PESTAÑAS DE LA BIBLIOTECA", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(6.dp))
        Text("Elige qué categorías aparecen en la barra de la biblioteca. Debe quedar al menos una visible.", color = TextMuted, fontSize = 12.sp, lineHeight = 17.sp)
        Spacer(Modifier.height(10.dp))
        allLibraryTabs.forEach { label ->
            PreferenceToggle(
                title = label,
                subtitle = if (label in visibleTabs) "Visible en la barra de pestañas" else "Oculta en la barra de pestañas",
                checked = label in visibleTabs,
                onCheckedChange = { enabled -> onToggleTab(label, enabled) }
            )
        }
        Spacer(Modifier.height(18.dp))
        Text("Los cambios se guardan automáticamente", color = TextMuted, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(8.dp))
        Text("ẞetaMusic · Android", color = TextMuted, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
private fun PreferenceToggle(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(16.dp))
            .background(SurfaceDark).padding(start = 14.dp, end = 10.dp, top = 12.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(3.dp))
            Text(subtitle, color = TextMuted, fontSize = 11.sp, lineHeight = 15.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Lime,
                checkedBorderColor = Lime,
                uncheckedThumbColor = TextMuted,
                uncheckedTrackColor = SurfaceLight
            )
        )
    }
}

private fun blendColors(start: Color, end: Color, fraction: Float): Color {
    val f = fraction.coerceIn(0f, 1f)
    return Color(
        red = start.red + (end.red - start.red) * f,
        green = start.green + (end.green - start.green) * f,
        blue = start.blue + (end.blue - start.blue) * f,
        alpha = start.alpha + (end.alpha - start.alpha) * f
    )
}

@Composable
private fun rememberDominantCoverColor(song: Song?): State<Color> {
    val context = LocalContext.current
    return produceState(initialValue = manualAccentState.value, key1 = song?.id) {
        val currentSong = song
        if (currentSong == null) {
            value = manualAccentState.value
            return@produceState
        }
        value = withContext(Dispatchers.IO) {
            runCatching {
                val bitmap = loadCoverBitmap(context, currentSong, 84) ?: return@runCatching manualAccentState.value
                dominantColorFromBitmap(bitmap)
            }.getOrDefault(manualAccentState.value)
        }
    }
}

@Composable
private fun DynamicAccentController(song: Song?, enabled: Boolean) {
    val coverAccent by rememberDominantCoverColor(song)
    LaunchedEffect(song?.id, enabled, coverAccent) {
        appAccentState.value = if (enabled && song != null) coverAccent else manualAccentState.value
    }
}

private fun loadCoverBitmap(context: android.content.Context, song: Song, px: Int): Bitmap? {
    ArtCache.get(song, px)?.takeUnless { it.isRecycled }?.let { return it }
    fun decodeSampled(uri: Uri): Bitmap? = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { input -> BitmapFactory.decodeStream(input, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@runCatching null
        var sampleSize = 1
        while (bounds.outWidth / sampleSize > px || bounds.outHeight / sampleSize > px) {
            sampleSize = (sampleSize * 2).coerceAtMost(1 shl 20)
            if (sampleSize >= (1 shl 20)) break
        }
        val options = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.RGB_565
        }
        context.contentResolver.openInputStream(uri)?.use { input -> BitmapFactory.decodeStream(input, null, options) }
    }.getOrNull()

    // A manufacturer-specific MediaStore album-art provider can throw SecurityException,
    // FileNotFoundException or IllegalArgumentException. Treat it as missing artwork.
    val albumArt = runCatching {
        song.albumId.takeIf { it > 0L }?.let { ContentUris.withAppendedId(ArtBase, it) }
    }.getOrNull()
    val bitmap = albumArt?.let(::decodeSampled)
        ?: if (Build.VERSION.SDK_INT >= 29) loadThumbnail(context.contentResolver, song.uri, px) else null
    if (bitmap != null && !bitmap.isRecycled) ArtCache.put(song, px, bitmap)
    return bitmap?.takeUnless { it.isRecycled }
}

private fun dominantColorFromBitmap(bitmap: Bitmap): Color {
    val source = if (bitmap.config == Bitmap.Config.HARDWARE) bitmap.copy(Bitmap.Config.ARGB_8888, false) ?: bitmap else bitmap
    var r = 0.0; var g = 0.0; var b = 0.0; var weightTotal = 0.0
    val stepX = (source.width / 18).coerceAtLeast(1)
    val stepY = (source.height / 18).coerceAtLeast(1)
    val hsv = FloatArray(3)
    for (x in 0 until source.width step stepX) for (y in 0 until source.height step stepY) {
        val pixel = source.getPixel(x, y)
        android.graphics.Color.colorToHSV(pixel, hsv)
        if (hsv[2] < 0.16f) continue
        val weight = 0.35 + hsv[1].toDouble() * 1.8 + hsv[2].toDouble() * 0.25
        r += android.graphics.Color.red(pixel) * weight
        g += android.graphics.Color.green(pixel) * weight
        b += android.graphics.Color.blue(pixel) * weight
        weightTotal += weight
    }
    if (weightTotal <= 0.0) return Color(0xFF4B83F5)
    var color = android.graphics.Color.rgb((r / weightTotal).toInt().coerceIn(0, 255), (g / weightTotal).toInt().coerceIn(0, 255), (b / weightTotal).toInt().coerceIn(0, 255))
    hsv.fill(0f)
    android.graphics.Color.colorToHSV(color, hsv)
    hsv[1] = (hsv[1] * 1.28f).coerceIn(0.35f, 0.95f)
    hsv[2] = (hsv[2] * 1.08f).coerceIn(0.42f, 0.92f)
    color = android.graphics.Color.HSVToColor(hsv)
    return Color(color)
}

@Composable
private fun CoverGradientBackground(song: Song, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val coverColor by produceState(Color(0xFF4E246F), song.id) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val bmp = if (Build.VERSION.SDK_INT >= 29) {
                    loadThumbnail(context.contentResolver, song.uri, 72)
                } else if (song.albumId > 0) {
                    val uri = ContentUris.withAppendedId(ArtBase, song.albumId)
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                    var sampleSize = 1
                    while (bounds.outWidth / sampleSize > 96 || bounds.outHeight / sampleSize > 96) sampleSize *= 2
                    val options = BitmapFactory.Options().apply {
                        inSampleSize = sampleSize
                        inPreferredConfig = Bitmap.Config.RGB_565
                    }
                    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
                } else null
                if (bmp == null) null else {
                    var red = 0L; var green = 0L; var blue = 0L; var count = 0L
                    val sx = (bmp.width / 9).coerceAtLeast(1)
                    val sy = (bmp.height / 9).coerceAtLeast(1)
                    for (x in 0 until bmp.width step sx) for (y in 0 until bmp.height step sy) {
                        val pixel = bmp.getPixel(x, y)
                        red += android.graphics.Color.red(pixel)
                        green += android.graphics.Color.green(pixel)
                        blue += android.graphics.Color.blue(pixel)
                        count++
                    }
                    if (count == 0L) null else Color(android.graphics.Color.rgb((red / count).toInt(), (green / count).toInt(), (blue / count).toInt()))
                }
            }.getOrNull() ?: Color(0xFF4E246F)
        }
    }
    Box(
        modifier.background(
            Brush.verticalGradient(
                colors = listOf(
                    blendColors(coverColor, NeonPink, 0.42f).copy(alpha = 0.94f),
                    blendColors(coverColor, NeonViolet, 0.48f).copy(alpha = 0.70f),
                    Color(0xFF17102A).copy(alpha = 0.88f),
                    Bg
                )
            )
        )
    )
}


@Composable
private fun EmptyState(title: String, message: String, action: String?, onAction: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(30.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.LibraryMusic, null, tint = Lime, modifier = Modifier.size(52.dp))
        Spacer(Modifier.height(15.dp))
        Text(title, color = TextMain, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(7.dp))
        Text(message, color = TextMuted, fontSize = 13.sp, lineHeight = 19.sp)
        if (action != null) {
            Spacer(Modifier.height(15.dp))
            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = OnLime)
            ) { Text(action, fontWeight = FontWeight.Bold) }
        }
    }
}

private fun formatTime(ms: Long): String {
    val total = (ms.coerceAtLeast(0L) / 1000L).toInt()
    return String.format(Locale.US, "%d:%02d", total / 60, total % 60)
}

package com.betastudio.betamusic

import android.Manifest
import android.content.ComponentName
import android.content.ContentResolver
import android.content.ContentUris
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.LruCache
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image as BitmapImage
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

// ───────────────────────── Identidad visual ẞetaMusic ─────────────────────────
private val Bg = Color(0xFF090B0A)
private val SurfaceDark = Color(0xFF151916)
private val SurfaceLight = Color(0xFF202620)
private val appAccentState = mutableStateOf(Color(0xFFB7F34A))
private val Lime: Color get() = appAccentState.value
private val OnLime = Color(0xFF10140D)
private val TextMain = Color(0xFFF2F5EF)
private val TextMuted = Color(0xFFA3AEA2)

private val ArtBase: Uri = Uri.parse("content://media/external/audio/albumart")

private const val SECTION_LIBRARY = "library"
private const val SECTION_FAVORITES = "favorites"
private const val SECTION_QUEUE = "queue"
private const val SECTION_PLAYLISTS = "playlists"
private const val SECTION_SETTINGS = "settings"
private const val PREFS_SETTINGS = "betamusic_settings"
private const val PREF_ACCENT = "accent_color"

private data class LibraryGroup(
    val id: String,
    val title: String,
    val subtitle: String,
    val songs: List<Song>
) {
    val coverSong: Song? get() = songs.firstOrNull()
}

private data class MusicPlaylist(val id: String, val name: String, val songIds: List<Long>)

private data class AccentChoice(val name: String, val color: Color)

private val accentChoices = listOf(
    AccentChoice("Lima", Color(0xFFB7F34A)),
    AccentChoice("Cian", Color(0xFF42D9E8)),
    AccentChoice("Azul", Color(0xFF5B8CFF)),
    AccentChoice("Violeta", Color(0xFFB18CFF)),
    AccentChoice("Rosa", Color(0xFFFF78B5)),
    AccentChoice("Coral", Color(0xFFFF8066)),
    AccentChoice("Ámbar", Color(0xFFFFC857))
)

private fun readPlaylists(context: android.content.Context): List<MusicPlaylist> = runCatching {
    val json = context.getSharedPreferences("betamusic", android.content.Context.MODE_PRIVATE)
        .getString("playlists_json", "[]") ?: "[]"
    val array = JSONArray(json)
    buildList {
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val ids = item.optJSONArray("songIds") ?: JSONArray()
            add(MusicPlaylist(
                id = item.optString("id", System.currentTimeMillis().toString() + i),
                name = item.optString("name", "Lista ${i + 1}"),
                songIds = buildList { for (j in 0 until ids.length()) ids.optLong(j).takeIf { it > 0L }?.let { add(it) } }.distinct()
            ))
        }
    }
}.getOrDefault(emptyList())

private fun savePlaylists(context: android.content.Context, playlists: List<MusicPlaylist>) {
    val array = JSONArray()
    playlists.forEach { playlist ->
        val ids = JSONArray()
        playlist.songIds.forEach(ids::put)
        array.put(JSONObject().put("id", playlist.id).put("name", playlist.name).put("songIds", ids))
    }
    context.getSharedPreferences("betamusic", android.content.Context.MODE_PRIVATE)
        .edit().putString("playlists_json", array.toString()).apply()
}

internal data class QueueEntry(val index: Int, val song: Song)

internal data class UiState(
    val songs: List<Song>,
    val loading: Boolean,
    val hasPermission: Boolean,
    val error: String?,
    val favorites: Set<Long>,
    val currentId: Long?,
    val isPlaying: Boolean,
    val duration: Long,
    val shuffle: Boolean,
    val repeatMode: Int,
    val queueVersion: Int,
    val message: String?
)

internal class UiActions(
    val requestPermission: () -> Unit,
    val refresh: () -> Unit,
    val play: (Song, List<Song>) -> Unit,
    val togglePlay: () -> Unit,
    val next: () -> Unit,
    val previous: () -> Unit,
    val seek: (Long) -> Unit,
    val toggleFavorite: (Song) -> Unit,
    val toggleShuffle: () -> Unit,
    val cycleRepeat: () -> Unit,
    val playQueueItem: (Int) -> Unit,
    val readQueue: (Map<Long, Song>) -> List<QueueEntry>,
    val dismissMessage: () -> Unit
)

// ───────────────────────────── Actividad ─────────────────────────────
class MainActivity : ComponentActivity() {
    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var loadJob: Job? = null
    private var errorStreak = 0

    private val songsState = mutableStateOf<List<Song>>(emptyList())
    private val permissionState = mutableStateOf(false)
    private val loadingState = mutableStateOf(true)
    private val errorState = mutableStateOf<String?>(null)
    private val favoritesState = mutableStateOf<Set<Long>>(emptySet())
    private val currentIdState = mutableStateOf<Long?>(null)
    private val playingState = mutableStateOf(false)
    private val durationState = mutableLongStateOf(0L)
    private val positionState = mutableLongStateOf(0L)
    private val shuffleState = mutableStateOf(false)
    private val repeatState = mutableIntStateOf(Player.REPEAT_MODE_OFF)
    private val queueVersionState = mutableIntStateOf(0)
    private val messageState = mutableStateOf<String?>(null)

    private val audioPermission: String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            permissionState.value = granted
            if (granted) loadLibrary() else loadingState.value = false
        }

    private val notificationLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* sin acción: la reproducción no depende de ello */ }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            playingState.value = isPlaying
            if (isPlaying) errorStreak = 0
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            currentIdState.value = mediaItem?.mediaId?.toLongOrNull()
            syncPlayerState()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            syncPlayerState()
        }

        override fun onTimelineChanged(timeline: Timeline, reason: Int) {
            queueVersionState.intValue++
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            shuffleState.value = shuffleModeEnabled
            queueVersionState.intValue++
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            repeatState.intValue = repeatMode
        }

        override fun onPlayerError(error: PlaybackException) {
            val player = controller ?: return
            val title = player.currentMediaItem?.mediaMetadata?.title?.toString() ?: "la canción"
            errorStreak++
            messageState.value = "No se pudo reproducir «$title». Puede estar dañado o haber sido movido."
            // Se salta al siguiente archivo, con un límite para no entrar en un bucle si todos fallan.
            if (errorStreak <= 5 && player.hasNextMediaItem()) {
                player.seekToNextMediaItem()
                player.prepare()
                player.play()
            }
        }
    }

    private val actions = UiActions(
        requestPermission = { permissionLauncher.launch(audioPermission) },
        refresh = { refreshLibrary() },
        play = { song, list -> playSong(song, list) },
        togglePlay = { togglePlay() },
        next = { controller?.seekToNext() },
        previous = { controller?.seekToPrevious() },
        seek = { ms ->
            controller?.seekTo(ms)
            positionState.longValue = ms
        },
        toggleFavorite = { toggleFavorite(it) },
        toggleShuffle = {
            controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
        },
        cycleRepeat = {
            controller?.let {
                it.repeatMode = when (it.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
            }
        },
        playQueueItem = { index ->
            controller?.let {
                it.seekTo(index, 0L)
                if (it.playbackState == Player.STATE_IDLE) it.prepare()
                it.play()
            }
        },
        readQueue = { byId -> readQueue(byId) },
        dismissMessage = { messageState.value = null }
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val savedAccent = getSharedPreferences(PREFS_SETTINGS, MODE_PRIVATE)
            .getInt(PREF_ACCENT, Color(0xFFB7F34A).toArgb())
        appAccentState.value = Color(savedAccent)

        favoritesState.value =
            getSharedPreferences("betamusic", MODE_PRIVATE)
                .getStringSet("favorites", emptySet())
                ?.mapNotNull { it.toLongOrNull() }
                ?.toSet() ?: emptySet()

        if (ContextCompat.checkSelfPermission(this, audioPermission) == PackageManager.PERMISSION_GRANTED) {
            permissionState.value = true
            loadLibrary()
        } else {
            loadingState.value = false
            permissionLauncher.launch(audioPermission)
        }

        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener({
                try {
                    controller = future.get()
                    controller?.addListener(playerListener)
                    syncPlayerState()
                    queueVersionState.intValue++
                } catch (_: Exception) {
                    messageState.value = "No se pudo conectar con el servicio de reproducción."
                }
            }, ContextCompat.getMainExecutor(this))
        }

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Lime,
                    onPrimary = OnLime,
                    background = Bg,
                    surface = SurfaceDark,
                    onBackground = TextMain,
                    onSurface = TextMain
                )
            ) {
                val ui = UiState(
                    songs = songsState.value,
                    loading = loadingState.value,
                    hasPermission = permissionState.value,
                    error = errorState.value,
                    favorites = favoritesState.value,
                    currentId = currentIdState.value,
                    isPlaying = playingState.value,
                    duration = durationState.longValue,
                    shuffle = shuffleState.value,
                    repeatMode = repeatState.intValue,
                    queueVersion = queueVersionState.intValue,
                    message = messageState.value
                )
                BetaMusicScreen(
                    ui = ui,
                    position = { positionState.longValue },
                    a = actions
                )
            }
        }

        // El avance de la barra solo se actualiza mientras la app está visible y suena música.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                syncPlayerState()
                while (true) {
                    val player = controller
                    if (player != null && player.isPlaying) {
                        val pos = player.currentPosition.coerceAtLeast(0L)
                        if (pos != positionState.longValue) positionState.longValue = pos
                    }
                    delay(500)
                }
            }
        }
    }

    private fun refreshLibrary() {
        if (ContextCompat.checkSelfPermission(this, audioPermission) == PackageManager.PERMISSION_GRANTED) {
            permissionState.value = true
            loadLibrary()
        } else {
            permissionLauncher.launch(audioPermission)
        }
    }

    private fun loadLibrary() {
        loadJob?.cancel()
        loadingState.value = true
        errorState.value = null
        loadJob = lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching { MusicRepository(this@MainActivity).loadSongs() }
            }
            result
                .onSuccess { songsState.value = it }
                .onFailure {
                    errorState.value = it.message ?: "Error desconocido al leer la biblioteca."
                }
            loadingState.value = false
        }
    }

    private fun buildItem(song: Song): MediaItem {
        val metadata = MediaMetadata.Builder()
            .setTitle(song.title)
            .setArtist(song.artist)
            .setAlbumTitle(song.album)
        if (song.albumId > 0) {
            metadata.setArtworkUri(ContentUris.withAppendedId(ArtBase, song.albumId))
        }
        return MediaItem.Builder()
            .setMediaId(song.id.toString())
            .setUri(song.uri)
            .setMediaMetadata(metadata.build())
            .build()
    }

    /** La cola es la lista desde la que se tocó la canción (álbum, artista, carpeta, favoritos o búsqueda). */
    private fun playSong(song: Song, context: List<Song>) {
        val player = controller
        if (player == null) {
            messageState.value = "El reproductor se está iniciando. Inténtalo de nuevo en un momento."
            return
        }
        val list = if (context.any { it.id == song.id }) context else listOf(song)
        askNotificationsOnce()
        lifecycleScope.launch {
            val items = withContext(Dispatchers.Default) { list.map { buildItem(it) } }
            val index = list.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
            errorStreak = 0
            player.setMediaItems(items, index, 0L)
            player.prepare()
            player.play()
            currentIdState.value = song.id
        }
    }

    private fun askNotificationsOnce() {
        if (Build.VERSION.SDK_INT < 33) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        ) return
        val prefs = getSharedPreferences("betamusic", MODE_PRIVATE)
        if (prefs.getBoolean("asked_notifications", false)) return
        prefs.edit().putBoolean("asked_notifications", true).apply()
        notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun togglePlay() {
        val player = controller ?: return
        if (player.mediaItemCount == 0) {
            songsState.value.firstOrNull()?.let { playSong(it, songsState.value) }
            return
        }
        if (player.isPlaying) {
            player.pause()
        } else {
            when (player.playbackState) {
                Player.STATE_IDLE -> player.prepare()
                Player.STATE_ENDED -> player.seekToDefaultPosition(0)
                else -> Unit
            }
            player.play()
        }
    }

    private fun readQueue(byId: Map<Long, Song>): List<QueueEntry> {
        val player = controller ?: return emptyList()
        val timeline = player.currentTimeline
        if (timeline.isEmpty) return emptyList()
        val shuffle = player.shuffleModeEnabled
        val out = ArrayList<QueueEntry>(timeline.windowCount)
        var i = timeline.getFirstWindowIndex(shuffle)
        while (i != C.INDEX_UNSET) {
            val song = player.getMediaItemAt(i).mediaId.toLongOrNull()?.let { byId[it] }
            if (song != null) out.add(QueueEntry(i, song))
            i = timeline.getNextWindowIndex(i, Player.REPEAT_MODE_OFF, shuffle)
        }
        return out
    }

    private fun syncPlayerState() {
        val player = controller ?: return
        playingState.value = player.isPlaying
        durationState.longValue = player.duration.takeIf { it > 0 } ?: 0L
        positionState.longValue = player.currentPosition.coerceAtLeast(0L)
        currentIdState.value = player.currentMediaItem?.mediaId?.toLongOrNull()
        shuffleState.value = player.shuffleModeEnabled
        repeatState.intValue = player.repeatMode
    }

    private fun toggleFavorite(song: Song) {
        val next = favoritesState.value.toMutableSet().apply {
            if (!add(song.id)) remove(song.id)
        }.toSet()
        favoritesState.value = next
        getSharedPreferences("betamusic", MODE_PRIVATE)
            .edit()
            .putStringSet("favorites", next.map { it.toString() }.toSet())
            .apply()
    }

    override fun onDestroy() {
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }
}

// ───────────────────────────── Pantalla principal ─────────────────────────────
@Composable
private fun BetaMusicScreen(ui: UiState, position: () -> Long, a: UiActions) {
    var query by rememberSaveable { mutableStateOf("") }
    var section by rememberSaveable { mutableStateOf(SECTION_LIBRARY) }
    var tab by rememberSaveable { mutableStateOf("Canciones") }
    var selectedGroupId by rememberSaveable { mutableStateOf<String?>(null) }
    var showPlayer by rememberSaveable { mutableStateOf(false) }
    var selectedPlaylistId by rememberSaveable { mutableStateOf<String?>(null) }
    var showCreatePlaylist by rememberSaveable { mutableStateOf(false) }
    var showAddSongs by rememberSaveable { mutableStateOf(false) }
    val context = LocalContext.current
    var playlists by remember { mutableStateOf(readPlaylists(context)) }
    val persistPlaylists: (List<MusicPlaylist>) -> Unit = { updated ->
        playlists = updated
        savePlaylists(context, updated)
    }

    val songs = ui.songs
    val songsById = remember(songs) { songs.associateBy { it.id } }
    val current = ui.currentId?.let { songsById[it] }
    val selectedPlaylist = playlists.firstOrNull { it.id == selectedPlaylistId }
    val playlistSongs = selectedPlaylist?.songIds.orEmpty().mapNotNull(songsById::get)

    val groups = remember(songs, tab) { buildGroups(songs, tab) }
    val selectedGroup = groups.firstOrNull { it.id == selectedGroupId }
    val filteredGroups = remember(groups, query) {
        groups.filter { group ->
            query.isBlank() ||
                group.title.contains(query, true) || group.subtitle.contains(query, true) ||
                group.songs.any { songMatches(it, query) }
        }
    }
    val baseSongs = selectedGroup?.songs ?: songs
    val filteredSongs = remember(baseSongs, query) { baseSongs.filter { songMatches(it, query) } }
    val favoriteSongs = remember(songs, ui.favorites, query) {
        songs.filter { it.id in ui.favorites && songMatches(it, query) }
    }

    LaunchedEffect(current == null) { if (current == null) showPlayer = false }
    LaunchedEffect(ui.message) {
        if (ui.message != null) {
            delay(3500)
            a.dismissMessage()
        }
    }

    BackHandler(enabled = showPlayer && current != null) { showPlayer = false }
    BackHandler(enabled = !showPlayer && section == SECTION_PLAYLISTS && selectedPlaylistId != null) { selectedPlaylistId = null }
    BackHandler(enabled = !showPlayer && section == SECTION_LIBRARY && selectedGroup != null) { selectedGroupId = null }
    BackHandler(enabled = !showPlayer && section != SECTION_LIBRARY && !(section == SECTION_PLAYLISTS && selectedPlaylistId != null)) {
        section = SECTION_LIBRARY
        selectedPlaylistId = null
    }

    Column(
        Modifier.fillMaxSize()
            .background(Bg)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        if (showPlayer && current != null) {
            NowPlayingScreen(
                song = current,
                isPlaying = ui.isPlaying,
                isFavorite = current.id in ui.favorites,
                shuffle = ui.shuffle,
                repeatMode = ui.repeatMode,
                position = position,
                duration = ui.duration,
                onBack = { showPlayer = false },
                onTogglePlay = a.togglePlay,
                onPrevious = a.previous,
                onNext = a.next,
                onSeek = a.seek,
                onToggleFavorite = { a.toggleFavorite(current) },
                onToggleShuffle = a.toggleShuffle,
                onCycleRepeat = a.cycleRepeat,
                onOpenQueue = {
                    showPlayer = false
                    section = SECTION_QUEUE
                }
            )
        } else {
            TopHeader(
                subtitle = when (section) {
                    SECTION_FAVORITES -> "TUS FAVORITOS"
                    SECTION_QUEUE -> "COLA DE REPRODUCCIÓN"
                    SECTION_PLAYLISTS -> if (selectedPlaylist != null) "LISTA DE REPRODUCCIÓN" else "TUS LISTAS PERSONALES"
                    SECTION_SETTINGS -> "PERSONALIZA TU EXPERIENCIA"
                    else -> "TU MÚSICA. TU ESPACIO."
                },
                onRefresh = if (section == SECTION_LIBRARY) a.refresh else null
            )

            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (section) {
                    SECTION_FAVORITES -> Column(Modifier.fillMaxSize()) {
                        SearchField(query) { query = it }
                        CountHeader("TUS FAVORITOS", if (ui.loading) "Leyendo música…" else "${favoriteSongs.size} pistas")
                        if (favoriteSongs.isEmpty()) {
                            EmptyState(
                                title = if (ui.favorites.isEmpty()) "Aún no hay favoritos" else "Sin resultados",
                                message = if (ui.favorites.isEmpty()) "Toca el corazón de una canción para guardarla aquí." else "Prueba otra búsqueda.",
                                action = if (query.isNotEmpty()) "Limpiar búsqueda" else null,
                                onAction = { query = "" }
                            )
                        } else {
                            SongList(
                                songs = favoriteSongs,
                                currentId = ui.currentId,
                                isPlaying = ui.isPlaying,
                                favorites = ui.favorites,
                                onPlay = { song ->
                                    a.play(song, favoriteSongs)
                                    showPlayer = true
                                },
                                onToggleFavorite = a.toggleFavorite,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    SECTION_QUEUE -> QueuePane(
                        ui = ui,
                        songsById = songsById,
                        a = a
                    )

                    SECTION_PLAYLISTS -> {
                        if (selectedPlaylist == null) {
                            PlaylistsPane(
                                playlists = playlists,
                                songsById = songsById,
                                onCreate = { showCreatePlaylist = true },
                                onOpen = { selectedPlaylistId = it.id },
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            PlaylistDetailPane(
                                playlist = selectedPlaylist,
                                songs = playlistSongs,
                                currentId = ui.currentId,
                                isPlaying = ui.isPlaying,
                                onBack = { selectedPlaylistId = null },
                                onAddSongs = { showAddSongs = true },
                                onPlay = { song -> a.play(song, playlistSongs); showPlayer = true },
                                onRemove = { song ->
                                    persistPlaylists(playlists.map { item ->
                                        if (item.id == selectedPlaylist.id) item.copy(songIds = item.songIds.filterNot { it == song.id }) else item
                                    })
                                },
                                onDelete = {
                                    persistPlaylists(playlists.filterNot { it.id == selectedPlaylist.id })
                                    selectedPlaylistId = null
                                },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }

                    SECTION_SETTINGS -> SettingsPane(
                        selectedAccent = appAccentState.value,
                        onSelectAccent = { color ->
                            appAccentState.value = color
                            context.getSharedPreferences(PREFS_SETTINGS, android.content.Context.MODE_PRIVATE)
                                .edit().putInt(PREF_ACCENT, color.toArgb()).apply()
                        },
                        modifier = Modifier.fillMaxSize()
                    )

                    else -> Column(Modifier.fillMaxSize()) {
                        SearchField(query) { query = it }
                        Spacer(Modifier.height(12.dp))
                        TabChips(tab) {
                            tab = it
                            selectedGroupId = null
                        }
                        if (selectedGroup != null) {
                            Row(
                                Modifier.fillMaxWidth().padding(start = 12.dp, end = 20.dp, top = 10.dp, bottom = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(onClick = { selectedGroupId = null }) {
                                    Icon(Icons.Default.ArrowBack, "Volver a $tab", tint = Lime)
                                }
                                Column(Modifier.weight(1f)) {
                                    Text(selectedGroup.title, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(selectedGroup.subtitle, color = TextMuted, fontSize = 12.sp)
                                }
                            }
                        } else {
                            CountHeader(
                                overline = when (tab) {
                                    "Artistas" -> "TU COLECCIÓN DE ARTISTAS"
                                    "Álbumes" -> "TUS ÁLBUMES"
                                    "Carpetas" -> "TUS CARPETAS"
                                    else -> "TU BIBLIOTECA"
                                },
                                count = when {
                                    ui.loading -> "Leyendo música…"
                                    tab == "Canciones" -> "${filteredSongs.size} pistas"
                                    else -> "${filteredGroups.size} elementos"
                                }
                            )
                        }

                        when {
                            !ui.hasPermission -> EmptyState(
                                title = "Permiso necesario",
                                message = "Permite el acceso al audio para mostrar tu biblioteca.",
                                action = "Conceder permiso",
                                onAction = a.requestPermission
                            )
                            ui.loading -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = Lime)
                            }
                            ui.error != null -> EmptyState(
                                title = "No se pudo leer la biblioteca",
                                message = ui.error,
                                action = "Reintentar",
                                onAction = a.refresh
                            )
                            tab != "Canciones" && selectedGroup == null && filteredGroups.isEmpty() -> EmptyState(
                                title = if (songs.isEmpty()) "No hay música" else "No hay elementos",
                                message = if (songs.isEmpty()) "Añade archivos de música al teléfono y vuelve a intentarlo." else "No se encontraron ${tab.lowercase(Locale.getDefault())} con ese filtro.",
                                action = if (songs.isEmpty()) "Actualizar" else "Limpiar búsqueda",
                                onAction = { if (songs.isEmpty()) a.refresh() else query = "" }
                            )
                            tab == "Canciones" && filteredSongs.isEmpty() -> EmptyState(
                                title = if (songs.isEmpty()) "No hay canciones" else "Sin resultados",
                                message = if (songs.isEmpty()) "Añade archivos de música al teléfono y vuelve a intentarlo." else "Prueba otra búsqueda.",
                                action = if (songs.isEmpty()) "Actualizar" else "Limpiar búsqueda",
                                onAction = { if (songs.isEmpty()) a.refresh() else query = "" }
                            )
                            selectedGroup != null && filteredSongs.isEmpty() -> EmptyState(
                                title = "No hay canciones aquí",
                                message = "Prueba otra búsqueda o vuelve a la lista anterior.",
                                action = "Volver",
                                onAction = { selectedGroupId = null; query = "" }
                            )
                            tab != "Canciones" && selectedGroup == null -> GroupList(
                                groups = filteredGroups,
                                onOpen = { selectedGroupId = it.id },
                                modifier = Modifier.weight(1f)
                            )
                            else -> SongList(
                                songs = filteredSongs,
                                currentId = ui.currentId,
                                isPlaying = ui.isPlaying,
                                favorites = ui.favorites,
                                onPlay = { song ->
                                    a.play(song, filteredSongs)
                                    showPlayer = true
                                },
                                onToggleFavorite = a.toggleFavorite,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                val message = ui.message
                if (message != null) {
                    Box(
                        Modifier.align(Alignment.BottomCenter).padding(12.dp)
                            .clip(RoundedCornerShape(14.dp)).background(SurfaceLight)
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        Text(message, color = TextMain, fontSize = 13.sp)
                    }
                }
            }

            if (current != null) {
                MiniPlayer(
                    song = current,
                    isPlaying = ui.isPlaying,
                    position = position,
                    duration = ui.duration,
                    onOpen = { showPlayer = true },
                    onPrevious = a.previous,
                    onTogglePlay = a.togglePlay,
                    onNext = a.next
                )
            }

            BottomBar(section) { destination ->
                if (destination != SECTION_PLAYLISTS || section == SECTION_PLAYLISTS) selectedPlaylistId = null
                section = destination
            }
        }

        if (showCreatePlaylist) {
            CreatePlaylistDialog(
                onDismiss = { showCreatePlaylist = false },
                onCreate = { name ->
                    val playlist = MusicPlaylist(System.currentTimeMillis().toString(), name, emptyList())
                    persistPlaylists(playlists + playlist)
                    selectedPlaylistId = playlist.id
                    section = SECTION_PLAYLISTS
                    showCreatePlaylist = false
                }
            )
        }
        if (showAddSongs && selectedPlaylist != null) {
            AddSongsDialog(
                songs = songs,
                selectedIds = selectedPlaylist.songIds.toSet(),
                onDismiss = { showAddSongs = false },
                onConfirm = { ids ->
                    persistPlaylists(playlists.map { item -> if (item.id == selectedPlaylist.id) item.copy(songIds = ids.toList()) else item })
                    showAddSongs = false
                }
            )
        }
    }
}

private fun songMatches(song: Song, query: String): Boolean =
    query.isBlank() || listOf(song.title, song.artist, song.album, song.folder).any { it.contains(query, true) }

private fun songsLabel(n: Int) = if (n == 1) "1 canción" else "$n canciones"

private fun buildGroups(songs: List<Song>, tab: String): List<LibraryGroup> {
    val byTitle = compareBy<Song> { it.title.lowercase(Locale.getDefault()) }
    val grouped: List<LibraryGroup> = when (tab) {
        "Artistas" -> songs.groupBy { it.artist }.map { (name, list) ->
            val tracks = list.sortedWith(byTitle)
            LibraryGroup("artist:$name", name, songsLabel(tracks.size), tracks)
        }
        "Álbumes" -> songs.groupBy { "${it.albumId}:${it.album}" }.map { (key, list) ->
            val tracks = list.sortedWith(byTitle)
            val first = tracks.first()
            LibraryGroup("album:$key", first.album, "${first.artist} · ${songsLabel(tracks.size)}", tracks)
        }
        "Carpetas" -> songs.groupBy { it.folder }.map { (folder, list) ->
            val tracks = list.sortedWith(byTitle)
            LibraryGroup(
                "folder:$folder",
                folder.substringAfterLast('/').ifBlank { "Almacenamiento" },
                songsLabel(tracks.size),
                tracks
            )
        }
        else -> emptyList()
    }
    return grouped.sortedBy { it.title.lowercase(Locale.getDefault()) }
}

// ───────────────────────────── Componentes ─────────────────────────────
@Composable
private fun TopHeader(subtitle: String, onRefresh: (() -> Unit)?) {
    Row(
        Modifier.fillMaxWidth().padding(start = 22.dp, end = 10.dp, top = 12.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("ẞetaMusic", color = TextMain, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = (-1).sp)
            Text(subtitle, color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        }
        if (onRefresh != null) {
            IconButton(onClick = onRefresh) {
                Icon(Icons.Default.Refresh, "Actualizar biblioteca", tint = Lime)
            }
        }
    }
}

@Composable
private fun SearchField(query: String, onChange: (String) -> Unit) {
    Row(
        Modifier.padding(horizontal = 18.dp).fillMaxWidth()
            .clip(RoundedCornerShape(16.dp)).background(SurfaceDark).padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Search, null, tint = TextMuted)
        Spacer(Modifier.width(10.dp))
        TextField(
            value = query,
            onValueChange = onChange,
            modifier = Modifier.weight(1f),
            placeholder = { Text("Buscar canciones, artistas, álbumes…", color = TextMuted, fontSize = 14.sp) },
            singleLine = true,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                cursorColor = Lime
            )
        )
        if (query.isNotEmpty()) {
            IconButton(onClick = { onChange("") }) {
                Icon(Icons.Default.Close, "Limpiar búsqueda", tint = TextMuted)
            }
        }
    }
}

@Composable
private fun TabChips(selectedTab: String, onSelect: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        listOf("Canciones", "Artistas", "Álbumes", "Carpetas").forEach { item ->
            val selected = selectedTab == item
            Box(
                Modifier.weight(1f).heightIn(min = 44.dp).clip(RoundedCornerShape(50))
                    .background(if (selected) Lime else SurfaceDark)
                    .clickable(role = Role.Tab) { onSelect(item) }
                    .padding(horizontal = 3.dp, vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    item,
                    color = if (selected) OnLime else TextMuted,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun CountHeader(overline: String, count: String) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 14.dp)) {
        Text(overline, color = TextMuted, fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
        Text(count, color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SongList(
    songs: List<Song>,
    currentId: Long?,
    isPlaying: Boolean,
    favorites: Set<Long>,
    onPlay: (Song) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier,
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        items(songs, key = { it.id }) { song ->
            val active = song.id == currentId
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                    .background(if (active) SurfaceLight else Color.Transparent)
                    .clickable { onPlay(song) }
                    .padding(start = 10.dp, top = 7.dp, bottom = 7.dp, end = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AlbumArtwork(song, Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)), 23.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(song.title, color = if (active) Lime else TextMain, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                    Spacer(Modifier.height(3.dp))
                    Text("${song.artist} · ${song.album}", color = TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
                }
                if (active && isPlaying) {
                    Icon(Icons.Default.GraphicEq, "Sonando", tint = Lime, modifier = Modifier.padding(horizontal = 4.dp).size(18.dp))
                }
                Text(formatTime(song.durationMs), color = TextMuted, fontSize = 11.sp)
                IconButton(onClick = { onToggleFavorite(song) }) {
                    val fav = song.id in favorites
                    Icon(
                        if (fav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        if (fav) "Quitar de favoritos" else "Añadir a favoritos",
                        tint = if (fav) Lime else TextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun GroupList(groups: List<LibraryGroup>, onOpen: (LibraryGroup) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(
        modifier,
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        items(groups, key = { it.id }) { group ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp))
                    .background(SurfaceDark).clickable { onOpen(group) }
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AlbumArtwork(group.coverSong, Modifier.size(58.dp).clip(RoundedCornerShape(12.dp)), 25.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(group.title, color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(4.dp))
                    Text(group.subtitle, color = TextMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Icon(Icons.Default.ChevronRight, null, tint = Lime)
            }
        }
    }
}

@Composable
private fun QueuePane(ui: UiState, songsById: Map<Long, Song>, a: UiActions) {
    val entries = remember(ui.queueVersion, songsById) { a.readQueue(songsById) }
    val listState = rememberLazyListState()
    LaunchedEffect(entries.size) {
        val idx = entries.indexOfFirst { it.song.id == ui.currentId }
        if (idx > 0) listState.scrollToItem(idx)
    }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(if (ui.shuffle) "ORDEN ALEATORIO" else "ORDEN NORMAL", color = TextMuted, fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
                Text(songsLabel(entries.size), color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
        }
        if (entries.isEmpty()) {
            EmptyState(
                title = "La cola está vacía",
                message = "Toca una canción de tu biblioteca para empezar a reproducir.",
                action = null,
                onAction = {}
            )
        } else {
            LazyColumn(
                Modifier.weight(1f),
                state = listState,
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(entries, key = { it.index }) { entry ->
                    val active = entry.song.id == ui.currentId
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                            .background(if (active) SurfaceLight else Color.Transparent)
                            .clickable { a.playQueueItem(entry.index) }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AlbumArtwork(entry.song, Modifier.size(46.dp).clip(RoundedCornerShape(10.dp)), 20.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(entry.song.title, color = if (active) Lime else TextMain, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                            Text(entry.song.artist, color = TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
                        }
                        if (active) Icon(Icons.Default.GraphicEq, "Sonando ahora", tint = Lime, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomBar(section: String, onSelect: (String) -> Unit) {
    NavigationBar(
        containerColor = SurfaceDark,
        contentColor = TextMain,
        windowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp)
    ) {
        listOf(
            Triple(SECTION_LIBRARY, Icons.Default.LibraryMusic, "Música"),
            Triple(SECTION_FAVORITES, Icons.Default.Favorite, "Favoritos"),
            Triple(SECTION_PLAYLISTS, Icons.Default.PlaylistPlay, "Listas"),
            Triple(SECTION_QUEUE, Icons.Default.QueueMusic, "Cola"),
            Triple(SECTION_SETTINGS, Icons.Default.Settings, "Ajustes")
        ).forEach { (id, icon, label) ->
            NavigationBarItem(
                selected = section == id,
                onClick = { onSelect(id) },
                icon = { Icon(icon, contentDescription = null) },
                label = { Text(label, fontSize = 10.sp, maxLines = 1) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = OnLime,
                    selectedTextColor = Lime,
                    indicatorColor = Lime,
                    unselectedIconColor = TextMuted,
                    unselectedTextColor = TextMuted
                )
            )
        }
    }
}

// ───────────────────────────── Portadas ─────────────────────────────
private object ArtCache {
    private val cache = object : LruCache<Long, Bitmap>(((Runtime.getRuntime().maxMemory() / 1024) / 12).toInt()) {
        override fun sizeOf(key: Long, value: Bitmap): Int = value.byteCount / 1024
    }
    private val withoutArt: MutableSet<Long> = ConcurrentHashMap.newKeySet()

    private fun key(song: Song, px: Int): Long = song.id or (px.toLong() shl 40)

    fun get(song: Song, px: Int): Bitmap? = cache.get(key(song, px))
    fun put(song: Song, px: Int, bitmap: Bitmap) { cache.put(key(song, px), bitmap) }
    fun hasNoArt(song: Song): Boolean = song.id in withoutArt
    fun markNoArt(song: Song) { withoutArt.add(song.id) }
}

@RequiresApi(29)
private fun loadThumbnail(resolver: ContentResolver, uri: Uri, px: Int): Bitmap? =
    runCatching { resolver.loadThumbnail(uri, Size(px, px), null) }.getOrNull()

@Composable
private fun AlbumArtwork(song: Song?, modifier: Modifier = Modifier, iconSize: Dp = 28.dp, px: Int = 256) {
    val context = LocalContext.current
    val bitmap by produceState<Bitmap?>(
        song?.let { ArtCache.get(it, px) },
        song?.id,
        px
    ) {
        val s = song
        if (s == null || Build.VERSION.SDK_INT < 29) {
            value = null
            return@produceState
        }
        val cached = ArtCache.get(s, px)
        if (cached != null) {
            value = cached
            return@produceState
        }
        if (!ArtCache.hasNoArt(s)) {
            val bmp = withContext(Dispatchers.IO) { loadThumbnail(context.contentResolver, s.uri, px) }
            if (bmp != null) {
                ArtCache.put(s, px, bmp)
                value = bmp
            } else {
                ArtCache.markNoArt(s)
            }
        }
    }
    // En Android 8 y 9 se usa el proveedor clásico de carátulas de álbum.
    val legacyUri = remember(song?.albumId) {
        if (Build.VERSION.SDK_INT < 29) {
            song?.albumId?.takeIf { it > 0 }?.let { ContentUris.withAppendedId(ArtBase, it) }
        } else null
    }
    Box(modifier.background(SurfaceDark), contentAlignment = Alignment.Center) {
        Icon(Icons.Default.Album, contentDescription = null, tint = Lime, modifier = Modifier.size(iconSize))
        val bmp = bitmap
        if (bmp != null) {
            BitmapImage(
                bitmap = bmp.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else if (legacyUri != null) {
            AsyncImage(
                model = legacyUri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

// ───────────────────────────── Reproductor ─────────────────────────────
@Composable
private fun MiniPlayer(
    song: Song,
    isPlaying: Boolean,
    position: () -> Long,
    duration: Long,
    onOpen: () -> Unit,
    onPrevious: () -> Unit,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit
) {
    val fraction = if (duration > 0) (position().toFloat() / duration).coerceIn(0f, 1f) else 0f
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(18.dp)).background(SurfaceLight)
    ) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(start = 10.dp, top = 8.dp, end = 4.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AlbumArtwork(song, Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)), 20.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(song.title, color = TextMain, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
                Text(song.artist, color = TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
            }
            IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, "Anterior", tint = TextMain) }
            IconButton(onClick = onTogglePlay) {
                Icon(
                    if (isPlaying) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled,
                    if (isPlaying) "Pausar" else "Reproducir",
                    tint = Lime,
                    modifier = Modifier.size(34.dp)
                )
            }
            IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, "Siguiente", tint = TextMain) }
        }
        LinearProgressIndicator(
            progress = { fraction },
            modifier = Modifier.fillMaxWidth().height(3.dp),
            color = Lime,
            trackColor = SurfaceDark
        )
    }
}

@Composable
private fun ProgressSection(position: () -> Long, duration: Long, onSeek: (Long) -> Unit) {
    var dragValue by remember { mutableStateOf<Float?>(null) }
    val current = position().coerceIn(0L, duration.coerceAtLeast(0L)).toFloat()
    val shown = (dragValue ?: current).coerceIn(0f, duration.coerceAtLeast(0L).toFloat())
    Column(Modifier.fillMaxWidth()) {
        Canvas(
            Modifier.fillMaxWidth().height(32.dp)
                .pointerInput(duration) {
                    detectTapGestures { offset ->
                        if (duration > 0 && size.width > 0) {
                            onSeek((duration * (offset.x / size.width.toFloat()).coerceIn(0f, 1f)).toLong())
                        }
                    }
                }
                .pointerInput(duration) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            if (duration > 0 && size.width > 0) dragValue = duration * (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                        },
                        onDragEnd = {
                            dragValue?.let { onSeek(it.toLong()) }
                            dragValue = null
                        },
                        onDragCancel = { dragValue = null }
                    ) { change, _ ->
                        change.consume()
                        if (duration > 0 && size.width > 0) dragValue = duration * (change.position.x / size.width.toFloat()).coerceIn(0f, 1f)
                    }
                }
        ) {
            val centerY = size.height / 2f
            val barHeight = 7.dp.toPx()
            val fraction = if (duration > 0L) (shown / duration.toFloat()).coerceIn(0f, 1f) else 0f
            val endX = size.width * fraction
            drawLine(SurfaceLight, Offset(0f, centerY), Offset(size.width, centerY), barHeight, cap = StrokeCap.Round)
            if (endX > 0f) drawLine(Lime, Offset(0f, centerY), Offset(endX, centerY), barHeight, cap = StrokeCap.Round)
            drawCircle(Color.White.copy(alpha = 0.12f), radius = 12.dp.toPx(), center = Offset(endX, centerY))
            drawCircle(Lime, radius = 7.dp.toPx(), center = Offset(endX, centerY))
            drawCircle(Color.White, radius = 2.3.dp.toPx(), center = Offset(endX, centerY))
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(shown.toLong()), color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text("−${formatTime((duration - shown.toLong()).coerceAtLeast(0L))}", color = TextMuted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun NowPlayingScreen(
    song: Song,
    isPlaying: Boolean,
    isFavorite: Boolean,
    shuffle: Boolean,
    repeatMode: Int,
    position: () -> Long,
    duration: Long,
    onBack: () -> Unit,
    onTogglePlay: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onSeek: (Long) -> Unit,
    onToggleFavorite: () -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onOpenQueue: () -> Unit
) {
    BoxWithConstraints(Modifier.fillMaxSize().background(Bg)) {
        CoverGradientBackground(song, Modifier.matchParentSize())
        // La portada se adapta al espacio disponible para que los controles siempre queden visibles.
        val cover = minOf(maxWidth - 56.dp, maxOf(140.dp, maxHeight - 420.dp), 340.dp)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver a la biblioteca", tint = TextMain) }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("REPRODUCIENDO", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    Text("ẞetaMusic", color = Lime, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                IconButton(onClick = onToggleFavorite) {
                    Icon(
                        if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        if (isFavorite) "Quitar de favoritos" else "Añadir a favoritos",
                        tint = if (isFavorite) Lime else TextMuted
                    )
                }
            }

            Spacer(Modifier.height(14.dp))
            AlbumArtwork(
                song = song,
                modifier = Modifier.size(cover).clip(RoundedCornerShape(26.dp)),
                iconSize = 72.dp,
                px = 640
            )
            Spacer(Modifier.height(20.dp))
            Text(song.title, color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(6.dp))
            Text(song.artist, color = Lime, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(song.album, color = TextMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(14.dp))

            ProgressSection(position, duration, onSeek)
            Spacer(Modifier.height(8.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onToggleShuffle) {
                    Icon(
                        Icons.Default.Shuffle,
                        if (shuffle) "Aleatorio activado" else "Aleatorio desactivado",
                        tint = if (shuffle) Lime else TextMuted
                    )
                }
                IconButton(onClick = onPrevious, modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Default.SkipPrevious, "Anterior", tint = TextMain, modifier = Modifier.size(36.dp))
                }
                FilledIconButton(
                    onClick = onTogglePlay,
                    modifier = Modifier.size(72.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = Lime, contentColor = OnLime)
                ) {
                    Icon(
                        if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        if (isPlaying) "Pausar" else "Reproducir",
                        modifier = Modifier.size(40.dp)
                    )
                }
                IconButton(onClick = onNext, modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Default.SkipNext, "Siguiente", tint = TextMain, modifier = Modifier.size(36.dp))
                }
                IconButton(onClick = onCycleRepeat) {
                    Icon(
                        if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                        when (repeatMode) {
                            Player.REPEAT_MODE_ONE -> "Repetir una canción"
                            Player.REPEAT_MODE_ALL -> "Repetir toda la cola"
                            else -> "Repetición desactivada"
                        },
                        tint = if (repeatMode == Player.REPEAT_MODE_OFF) TextMuted else Lime
                    )
                }
            }

            Spacer(Modifier.height(6.dp))
            TextButton(onClick = onOpenQueue) {
                Icon(Icons.Default.QueueMusic, null, tint = Lime, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("Cola de reproducción", color = Lime)
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun PlaylistsPane(
    playlists: List<MusicPlaylist>,
    songsById: Map<Long, Song>,
    onCreate: () -> Unit,
    onOpen: (MusicPlaylist) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("TU MÚSICA, A TU MANERA", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                Text("Listas de reproducción", color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("${playlists.size} listas guardadas", color = TextMuted, fontSize = 12.sp)
            }
            FilledTonalIconButton(onClick = onCreate, colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = Lime, contentColor = OnLime)) {
                Icon(Icons.Default.Add, "Crear lista")
            }
        }
        if (playlists.isEmpty()) {
            EmptyState(
                title = "Crea tu primera lista",
                message = "Agrupa las canciones que te gustan y reprodúcelas en el orden que prefieras.",
                action = "Crear lista",
                onAction = onCreate
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                items(playlists, key = { it.id }) { playlist ->
                    val firstSong = playlist.songIds.firstNotNullOfOrNull { id -> songsById[id] }
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(SurfaceDark)
                            .clickable { onOpen(playlist) }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (firstSong != null) {
                            AlbumArtwork(firstSong, Modifier.size(62.dp).clip(RoundedCornerShape(14.dp)), 26.dp)
                        } else {
                            Box(Modifier.size(62.dp).clip(RoundedCornerShape(14.dp)).background(SurfaceLight), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.QueueMusic, null, tint = Lime, modifier = Modifier.size(30.dp))
                            }
                        }
                        Spacer(Modifier.width(13.dp))
                        Column(Modifier.weight(1f)) {
                            Text(playlist.name, color = TextMain, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.height(4.dp))
                            Text(songsLabel(playlist.songIds.count { it in songsById }), color = TextMuted, fontSize = 12.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Lime)
                    }
                }
            }
        }
    }
}

@Composable
private fun PlaylistDetailPane(
    playlist: MusicPlaylist,
    songs: List<Song>,
    currentId: Long?,
    isPlaying: Boolean,
    onBack: () -> Unit,
    onAddSongs: () -> Unit,
    onPlay: (Song) -> Unit,
    onRemove: (Song) -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    var confirmDelete by remember(playlist.id) { mutableStateOf(false) }
    Column(modifier) {
        Row(
            Modifier.fillMaxWidth().padding(start = 8.dp, end = 12.dp, top = 6.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver a las listas", tint = Lime) }
            Column(Modifier.weight(1f)) {
                Text(playlist.name, color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(songsLabel(songs.size), color = TextMuted, fontSize = 12.sp)
            }
            IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Default.DeleteOutline, "Eliminar lista", tint = TextMuted) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = onAddSongs,
                colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = OnLime),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.PlaylistAdd, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(7.dp))
                Text("Añadir canciones", maxLines = 1)
            }
            FilledTonalIconButton(
                onClick = { songs.firstOrNull()?.let(onPlay) },
                enabled = songs.isNotEmpty(),
                colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = SurfaceLight, contentColor = Lime)
            ) { Icon(Icons.Default.PlayArrow, "Reproducir lista") }
        }
        if (songs.isEmpty()) {
            EmptyState(
                title = "Esta lista está vacía",
                message = "Añade canciones de tu biblioteca para crear tu propia selección.",
                action = "Añadir canciones",
                onAction = onAddSongs
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 14.dp, end = 12.dp, top = 8.dp, bottom = 14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(songs, key = { it.id }) { song ->
                    val active = song.id == currentId
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                            .background(if (active) SurfaceLight else Color.Transparent)
                            .clickable { onPlay(song) }.padding(start = 8.dp, end = 2.dp, top = 7.dp, bottom = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AlbumArtwork(song, Modifier.size(48.dp).clip(RoundedCornerShape(11.dp)), 22.dp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(song.title, color = if (active) Lime else TextMain, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(song.artist, color = TextMuted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (active && isPlaying) Icon(Icons.Default.GraphicEq, "Sonando", tint = Lime, modifier = Modifier.size(17.dp))
                        IconButton(onClick = { onRemove(song) }) { Icon(Icons.Default.Close, "Quitar de la lista", tint = TextMuted, modifier = Modifier.size(18.dp)) }
                    }
                }
            }
        }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("¿Eliminar esta lista?") },
            text = { Text("Se eliminará «${playlist.name}». Las canciones originales no se borrarán del teléfono.") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("Eliminar", color = Color(0xFFFF7777)) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar", color = TextMuted) } },
            containerColor = SurfaceDark,
            titleContentColor = TextMain,
            textContentColor = TextMuted
        )
    }
}

@Composable
private fun CreatePlaylistDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nueva lista de reproducción") },
        text = {
            Column {
                Text("Ponle un nombre a tu selección.", color = TextMuted, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(48) },
                    singleLine = true,
                    placeholder = { Text("Ej. Favoritas de noche") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Lime, focusedLabelColor = Lime, cursorColor = Lime)
                )
            }
        },
        confirmButton = { TextButton(onClick = { name.trim().takeIf { it.isNotEmpty() }?.let(onCreate) }, enabled = name.isNotBlank()) { Text("Crear", color = Lime) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar", color = TextMuted) } },
        containerColor = SurfaceDark,
        titleContentColor = TextMain,
        textContentColor = TextMuted
    )
}

@Composable
private fun AddSongsDialog(
    songs: List<Song>,
    selectedIds: Set<Long>,
    onDismiss: () -> Unit,
    onConfirm: (List<Long>) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    val selected = remember(selectedIds) { mutableStateOf(selectedIds.toMutableSet()) }
    val filtered = remember(songs, query) { songs.filter { songMatches(it, query) } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Añadir canciones") },
        text = {
            Column(Modifier.fillMaxWidth()) {
                TextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Buscar en la biblioteca", fontSize = 13.sp) },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = SurfaceLight,
                        unfocusedContainerColor = SurfaceLight,
                        focusedIndicatorColor = Lime,
                        unfocusedIndicatorColor = Color.Transparent,
                        cursorColor = Lime
                    )
                )
                Spacer(Modifier.height(8.dp))
                Text("${selected.value.size} seleccionadas", color = TextMuted, fontSize = 12.sp)
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 360.dp)) {
                    items(filtered, key = { it.id }) { song ->
                        val checked = song.id in selected.value
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                selected.value = selected.value.toMutableSet().apply {
                                    if (contains(song.id)) remove(song.id) else add(song.id)
                                }
                            }.padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AlbumArtwork(song, Modifier.size(38.dp).clip(RoundedCornerShape(8.dp)), 18.dp)
                            Spacer(Modifier.width(9.dp))
                            Column(Modifier.weight(1f)) {
                                Text(song.title, color = TextMain, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(song.artist, color = TextMuted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Checkbox(checked = checked, onCheckedChange = { isChecked ->
                                selected.value = selected.value.toMutableSet().apply { if (isChecked) add(song.id) else remove(song.id) }
                            }, colors = CheckboxDefaults.colors(checkedColor = Lime, checkmarkColor = OnLime))
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(selected.value.toList()) }) { Text("Guardar", color = Lime) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar", color = TextMuted) } },
        containerColor = SurfaceDark,
        titleContentColor = TextMain,
        textContentColor = TextMuted
    )
}

@Composable
private fun SettingsPane(
    selectedAccent: Color,
    onSelectAccent: (Color) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 12.dp)) {
        Text("PERSONALIZACIÓN", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(6.dp))
        Text("Dale tu color a ẞetaMusic", color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text("El color se aplica a botones, controles, selección y detalles de la interfaz.", color = TextMuted, fontSize = 13.sp, lineHeight = 19.sp)
        Spacer(Modifier.height(22.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Palette, null, tint = Lime, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(9.dp))
            Text("Color de acento", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(6.dp))
        Text("Selecciona una paleta", color = TextMuted, fontSize = 12.sp)
        Spacer(Modifier.height(15.dp))
        accentChoices.chunked(4).forEach { rowChoices ->
            Row(Modifier.fillMaxWidth().padding(bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                rowChoices.forEach { choice ->
                    val chosen = selectedAccent == choice.color
                    Column(
                        Modifier.weight(1f).clickable { onSelectAccent(choice.color) },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier.size(48.dp).border(if (chosen) 3.dp else 1.dp, if (chosen) Color.White else SurfaceLight, CircleShape)
                                .padding(if (chosen) 4.dp else 0.dp).clip(CircleShape).background(choice.color),
                            contentAlignment = Alignment.Center
                        ) {
                            if (chosen) Icon(Icons.Default.Check, null, tint = Color(0xFF101010), modifier = Modifier.size(21.dp))
                        }
                        Spacer(Modifier.height(7.dp))
                        Text(choice.name, color = if (chosen) TextMain else TextMuted, fontSize = 11.sp, fontWeight = if (chosen) FontWeight.Bold else FontWeight.Normal)
                    }
                }
                repeat((4 - rowChoices.size).coerceAtLeast(0)) { Spacer(Modifier.weight(1f)) }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(SurfaceDark).padding(15.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(selectedAccent), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.GraphicEq, null, tint = OnLime, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Vista previa", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Tu color se guarda automáticamente", color = TextMuted, fontSize = 11.sp)
            }
            Box(Modifier.size(42.dp).clip(CircleShape).background(selectedAccent), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Check, null, tint = OnLime, modifier = Modifier.size(22.dp))
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("ẞetaMusic · Android", color = TextMuted, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
private fun CoverGradientBackground(song: Song, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val coverColor by produceState(Color(0xFF29331E), song.id) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val bmp = if (Build.VERSION.SDK_INT >= 29) {
                    loadThumbnail(context.contentResolver, song.uri, 72)
                } else if (song.albumId > 0) {
                    val uri = ContentUris.withAppendedId(ArtBase, song.albumId)
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                    var sampleSize = 1
                    while (bounds.outWidth / sampleSize > 96 || bounds.outHeight / sampleSize > 96) sampleSize *= 2
                    val options = BitmapFactory.Options().apply {
                        inSampleSize = sampleSize
                        inPreferredConfig = Bitmap.Config.RGB_565
                    }
                    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
                } else null
                if (bmp == null) null else {
                    var red = 0L; var green = 0L; var blue = 0L; var count = 0L
                    val sx = (bmp.width / 9).coerceAtLeast(1)
                    val sy = (bmp.height / 9).coerceAtLeast(1)
                    for (x in 0 until bmp.width step sx) for (y in 0 until bmp.height step sy) {
                        val pixel = bmp.getPixel(x, y)
                        red += android.graphics.Color.red(pixel)
                        green += android.graphics.Color.green(pixel)
                        blue += android.graphics.Color.blue(pixel)
                        count++
                    }
                    if (count == 0L) null else Color(android.graphics.Color.rgb((red / count).toInt(), (green / count).toInt(), (blue / count).toInt()))
                }
            }.getOrNull() ?: Color(0xFF29331E)
        }
    }
    Box(
        modifier.background(
            Brush.verticalGradient(
                colors = listOf(coverColor.copy(alpha = 0.92f), coverColor.copy(alpha = 0.52f), Color(0xFF111510), Bg)
            )
        )
    )
}


@Composable
private fun EmptyState(title: String, message: String, action: String?, onAction: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(30.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.LibraryMusic, null, tint = Lime, modifier = Modifier.size(52.dp))
        Spacer(Modifier.height(15.dp))
        Text(title, color = TextMain, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(7.dp))
        Text(message, color = TextMuted, fontSize = 13.sp, lineHeight = 19.sp)
        if (action != null) {
            Spacer(Modifier.height(15.dp))
            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = OnLime)
            ) { Text(action, fontWeight = FontWeight.Bold) }
        }
    }
}

private fun formatTime(ms: Long): String {
    val total = (ms.coerceAtLeast(0L) / 1000L).toInt()
    return String.format(Locale.US, "%d:%02d", total / 60, total % 60)
}

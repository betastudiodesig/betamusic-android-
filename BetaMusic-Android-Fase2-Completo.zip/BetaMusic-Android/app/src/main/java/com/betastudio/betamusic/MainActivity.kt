package com.betastudio.betamusic

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.pm.PackageManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateColorAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

private val Bg = Color(0xFF090B0A)
private val SurfaceDark = Color(0xFF151916)
private val SurfaceLight = Color(0xFF202620)
private val Lime = Color(0xFFB7F34A)
private val TextMain = Color(0xFFF2F5EF)
private val TextMuted = Color(0xFF9CA69B)

private data class MusicPlaylist(val name: String, val songIds: List<Long>)

private data class LibraryGroup(
    val id: String,
    val title: String,
    val subtitle: String,
    val songs: List<Song>
) {
    val coverSong: Song? get() = songs.firstOrNull()
}

class MainActivity : ComponentActivity() {
    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private val songsState = mutableStateOf<List<Song>>(emptyList())
    private val permissionState = mutableStateOf(false)
    private val loadingState = mutableStateOf(true)
    private val favoritesState = mutableStateOf<Set<Long>>(emptySet())
    private val currentIdState = mutableStateOf<Long?>(null)
    private val playingState = mutableStateOf(false)
    private val durationState = mutableLongStateOf(0L)
    private val positionState = mutableLongStateOf(0L)
    private val playlistsState = mutableStateOf<List<MusicPlaylist>>(emptyList())
    private val lyricsState = mutableStateOf<Map<Long, String>>(emptyMap())
    private val accentState = mutableStateOf(0xFFB7F34AL)

    private val lyricsPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            lifecycleScope.launch {
                val text = withContext(Dispatchers.IO) {
                    runCatching { contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.getOrNull()
                }
                val id = currentIdState.value
                if (id != null && !text.isNullOrBlank()) {
                    val next = lyricsState.value.toMutableMap().apply { put(id, text) }.toMap()
                    lyricsState.value = next
                    saveLyrics(next)
                }
            }
        }
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            permissionState.value = granted
            if (granted) loadLibrary() else loadingState.value = false
        }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            playingState.value = isPlaying
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            currentIdState.value = mediaItem?.mediaId?.toLongOrNull()
            syncPlayerState()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            syncPlayerState()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        favoritesState.value =
            getSharedPreferences("betamusic", MODE_PRIVATE)
                .getStringSet("favorites", emptySet())
                ?.mapNotNull { it.toLongOrNull() }
                ?.toSet() ?: emptySet()
        playlistsState.value = loadPlaylists()
        lyricsState.value = loadLyrics()
        accentState.value = getSharedPreferences("betamusic", MODE_PRIVATE).getLong("accent", 0xFFB7F34AL)

        val permission = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            permissionState.value = true
            loadLibrary()
        } else {
            loadingState.value = false
            permissionLauncher.launch(permission)
        }

        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener({
                try {
                    controller = future.get()
                    controller?.addListener(playerListener)
                    syncPlayerState()
                } catch (_: Exception) {
                    // The screen remains usable; playback controls become active when the service connects.
                }
            }, ContextCompat.getMainExecutor(this))
        }

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Lime,
                    background = Bg,
                    surface = SurfaceDark,
                    onBackground = TextMain,
                    onSurface = TextMain
                )
            ) {
                BetaMusicScreen(
                    songs = songsState.value,
                    loading = loadingState.value,
                    hasPermission = permissionState.value,
                    favorites = favoritesState.value,
                    currentId = currentIdState.value,
                    isPlaying = playingState.value,
                    position = positionState.longValue,
                    duration = durationState.longValue,
                    onRequestPermission = { permissionLauncher.launch(permission) },
                    onPlay = { playSong(it) },
                    onPlayPlaylist = { list -> playSongs(list) },
                    onTogglePlay = { togglePlay() },
                    onNext = { controller?.seekToNextMediaItem() },
                    onPrevious = { controller?.seekToPreviousMediaItem() },
                    onSeek = { controller?.seekTo(it) },
                    onToggleFavorite = { toggleFavorite(it) },
                    playlists = playlistsState.value,
                    lyrics = lyricsState.value,
                    accent = Color(accentState.value.toULong()),
                    onCreatePlaylist = { createPlaylist(it) },
                    onAddToPlaylist = { playlistName, song -> addToPlaylist(playlistName, song) },
                    onDeletePlaylist = { deletePlaylist(it) },
                    onImportLyrics = { lyricsPicker.launch(arrayOf("text/*", "application/octet-stream")) },
                    onChangeAccent = { color -> accentState.value = color; getSharedPreferences("betamusic", MODE_PRIVATE).edit().putLong("accent", color).apply() }
                )
            }
        }

        lifecycleScope.launch {
            while (true) {
                syncPlayerState()
                kotlinx.coroutines.delay(500)
            }
        }
    }

    private fun loadLibrary() {
        loadingState.value = true
        lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) {
                runCatching { MusicRepository(this@MainActivity).loadSongs() }
                    .getOrDefault(emptyList())
            }
            songsState.value = list
            loadingState.value = false
        }
    }

    private fun playSong(song: Song) {
        val list = songsState.value
        val index = list.indexOfFirst { it.id == song.id }
        if (index >= 0) playSongs(list, index)
    }

    private fun playSongs(list: List<Song>, startIndex: Int = 0) {
        val player = controller ?: return
        if (list.isEmpty()) return
        val items = list.map { item ->
            val artwork = item.albumId.takeIf { it > 0 }?.let {
                ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), it)
            }
            MediaItem.Builder()
                .setMediaId(item.id.toString())
                .setUri(item.uri)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(item.title)
                        .setArtist(item.artist)
                        .setAlbumTitle(item.album)
                        .setArtworkUri(artwork)
                        .setExtras(Bundle().apply { putLong("song_id", item.id) })
                        .build()
                )
                .build()
        }
        val index = startIndex.coerceIn(0, items.lastIndex)
        player.setMediaItems(items, index, 0L)
        player.prepare()
        player.play()
        currentIdState.value = list[index].id
        playingState.value = true
    }

    private fun togglePlay() {
        val player = controller ?: return
        if (player.mediaItemCount == 0) {
            songsState.value.firstOrNull()?.let {
                playSong(it)
                return
            }
        }
        if (player.isPlaying) player.pause() else player.play()
    }

    private fun syncPlayerState() {
        val player = controller ?: return
        playingState.value = player.isPlaying
        durationState.longValue = player.duration.takeIf { it > 0 } ?: 0L
        positionState.longValue = player.currentPosition.coerceAtLeast(0L)
        currentIdState.value = player.currentMediaItem?.mediaId?.toLongOrNull()
    }

    private fun toggleFavorite(song: Song) {
        val next = favoritesState.value.toMutableSet().apply {
            if (!add(song.id)) remove(song.id)
        }.toSet()
        favoritesState.value = next
        getSharedPreferences("betamusic", MODE_PRIVATE)
            .edit()
            .putStringSet("favorites", next.map { it.toString() }.toSet())
            .apply()
    }

    private fun loadPlaylists(): List<MusicPlaylist> = runCatching {
        val raw = getSharedPreferences("betamusic", MODE_PRIVATE).getString("playlists", "[]") ?: "[]"
        val array = JSONArray(raw)
        (0 until array.length()).mapNotNull { i ->
            val item = array.optJSONObject(i) ?: return@mapNotNull null
            val ids = item.optJSONArray("ids") ?: JSONArray()
            MusicPlaylist(item.optString("name", "Lista"), (0 until ids.length()).map { ids.optLong(it) })
        }
    }.getOrDefault(emptyList())

    private fun savePlaylists(value: List<MusicPlaylist>) {
        val array = JSONArray()
        value.forEach { playlist ->
            val ids = JSONArray()
            playlist.songIds.forEach(ids::put)
            array.put(JSONObject().put("name", playlist.name).put("ids", ids))
        }
        getSharedPreferences("betamusic", MODE_PRIVATE).edit().putString("playlists", array.toString()).apply()
    }

    private fun loadLyrics(): Map<Long, String> = runCatching {
        val raw = getSharedPreferences("betamusic", MODE_PRIVATE).getString("lyrics", "{}") ?: "{}"
        val json = JSONObject(raw)
        buildMap { json.keys().forEach { key -> put(key.toLong(), json.optString(key)) } }
    }.getOrDefault(emptyMap())

    private fun saveLyrics(value: Map<Long, String>) {
        val json = JSONObject()
        value.forEach { (id, text) -> json.put(id.toString(), text) }
        getSharedPreferences("betamusic", MODE_PRIVATE).edit().putString("lyrics", json.toString()).apply()
    }

    private fun createPlaylist(name: String) {
        val clean = name.trim().take(48)
        if (clean.isEmpty() || playlistsState.value.any { it.name.equals(clean, true) }) return
        val next = playlistsState.value + MusicPlaylist(clean, emptyList())
        playlistsState.value = next
        savePlaylists(next)
    }

    private fun addToPlaylist(name: String, song: Song) {
        val next = playlistsState.value.map { playlist ->
            if (playlist.name == name && song.id !in playlist.songIds) playlist.copy(songIds = playlist.songIds + song.id) else playlist
        }
        playlistsState.value = next
        savePlaylists(next)
    }

    private fun deletePlaylist(name: String) {
        val next = playlistsState.value.filterNot { it.name == name }
        playlistsState.value = next
        savePlaylists(next)
    }

    override fun onDestroy() {
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }
}

@Composable
private fun BetaMusicScreen(
    songs: List<Song>,
    loading: Boolean,
    hasPermission: Boolean,
    favorites: Set<Long>,
    currentId: Long?,
    isPlaying: Boolean,
    position: Long,
    duration: Long,
    onRequestPermission: () -> Unit,
    onPlay: (Song) -> Unit,
    onPlayPlaylist: (List<Song>) -> Unit,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    playlists: List<MusicPlaylist>,
    lyrics: Map<Long, String>,
    accent: Color,
    onCreatePlaylist: (String) -> Unit,
    onAddToPlaylist: (String, Song) -> Unit,
    onDeletePlaylist: (String) -> Unit,
    onImportLyrics: () -> Unit,
    onChangeAccent: (Long) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf("Canciones") }
    var showFavorites by remember { mutableStateOf(false) }
    var selectedGroupId by remember { mutableStateOf<String?>(null) }
    var showPlayer by remember { mutableStateOf(false) }
    var showCreatePlaylist by remember { mutableStateOf(false) }
    var playlistName by remember { mutableStateOf("") }
    var playlistForSong by remember { mutableStateOf<Song?>(null) }
    var showThemeDialog by remember { mutableStateOf(false) }

    val groups = remember(songs, tab) {
        val grouped: List<Pair<String, List<Song>>> = when (tab) {
            "Artistas" -> songs.groupBy { it.artist }
                .map { (name, tracks) -> "artist:$name" to tracks.sortedBy { it.title.lowercase(Locale.getDefault()) } }
            "Álbumes" -> songs.groupBy { "${it.albumId}:${it.album}" }
                .map { (key, tracks) -> "album:$key" to tracks.sortedBy { it.title.lowercase(Locale.getDefault()) } }
            "Carpetas" -> songs.groupBy { it.folder }
                .map { (folder, tracks) -> "folder:$folder" to tracks.sortedBy { it.title.lowercase(Locale.getDefault()) } }
            else -> emptyList()
        }
        grouped.map { (id, tracks) ->
            val first = tracks.first()
            when (tab) {
                "Artistas" -> LibraryGroup(id, first.artist, "${tracks.size} canciones", tracks)
                "Álbumes" -> LibraryGroup(id, first.album, "${first.artist} · ${tracks.size} canciones", tracks)
                else -> LibraryGroup(id, first.folder.substringAfterLast('/').ifBlank { "Almacenamiento" }, "${tracks.size} canciones", tracks)
            }
        }.sortedBy { it.title.lowercase(Locale.getDefault()) }
    }

    val selectedGroup = groups.firstOrNull { it.id == selectedGroupId }
    val current = songs.firstOrNull { it.id == currentId }

    val filteredGroups = remember(groups, query, showFavorites, favorites) {
        groups.filter { group ->
            val matchesQuery = query.isBlank() ||
                group.title.contains(query, true) || group.subtitle.contains(query, true) ||
                group.songs.any { it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true) }
            val matchesFavorites = !showFavorites || group.songs.any { it.id in favorites }
            matchesQuery && matchesFavorites
        }
    }

    val baseSongs = if (selectedGroup != null) selectedGroup.songs else songs
    val filteredSongs = remember(baseSongs, query, showFavorites, favorites, tab, selectedGroupId) {
        baseSongs.filter { song ->
            val matchesQuery = query.isBlank() ||
                listOf(song.title, song.artist, song.album, song.folder).any { it.contains(query, true) }
            val matchesFavorites = !showFavorites || song.id in favorites
            matchesQuery && matchesFavorites
        }
    }

    fun playAndOpen(song: Song) {
        onPlay(song)
        showPlayer = true
    }

    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF111711), Bg, Color(0xFF070807))))
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Crossfade(
            targetState = showPlayer && current != null,
            animationSpec = tween(240),
            label = "main-screen-transition"
        ) { showNowPlaying ->
            if (showNowPlaying && current != null) {
            NowPlayingScreen(
                song = current,
                isPlaying = isPlaying,
                isFavorite = current.id in favorites,
                position = position,
                duration = duration,
                onBack = { showPlayer = false },
                onTogglePlay = onTogglePlay,
                onPrevious = onPrevious,
                onNext = onNext,
                onSeek = onSeek,
                onToggleFavorite = { onToggleFavorite(current) },
                lyricsText = lyrics[current.id].orEmpty(),
                onImportLyrics = onImportLyrics,
                accent = accent,
                onAddToPlaylist = { playlistForSong = current }
            )
        } else {
            Row(
                Modifier.fillMaxWidth().padding(start = 22.dp, end = 18.dp, top = 14.dp, bottom = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("ẞetaMusic", color = TextMain, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = (-1).sp)
                    Text("TU MÚSICA. TU ESPACIO.", color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                }
                Box(
                    Modifier.size(46.dp).clip(CircleShape)
                        .background(Brush.linearGradient(listOf(accent.copy(alpha = 0.22f), SurfaceLight)))
                        .border(1.dp, accent.copy(alpha = 0.34f), CircleShape)
                        .clickable { showThemeDialog = true },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.GraphicEq, contentDescription = "Audio", tint = accent, modifier = Modifier.size(25.dp))
                }
            }

            Row(
                Modifier.padding(horizontal = 18.dp).fillMaxWidth()
                    .clip(RoundedCornerShape(17.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF1A211A), SurfaceDark)))
                    .border(1.dp, accent.copy(alpha = 0.18f), RoundedCornerShape(17.dp))
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Search, null, tint = TextMuted)
                Spacer(Modifier.width(10.dp))
                TextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Buscar canciones, artistas, álbumes…", color = TextMuted) },
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        cursorColor = accent,
                        focusedTextColor = TextMain,
                        unfocusedTextColor = TextMain
                    )
                )
                if (query.isNotEmpty()) {
                    IconButton(onClick = { query = "" }) {
                        Icon(Icons.Default.Close, "Limpiar", tint = TextMuted)
                    }
                }
            }

            Spacer(Modifier.height(13.dp))

            LibraryHero(
                current = current,
                songCount = songs.size,
                isPlaying = isPlaying,
                accent = accent,
                onOpenPlayer = { if (current != null) showPlayer = true else songs.firstOrNull()?.let { playAndOpen(it) } }
            )

            Spacer(Modifier.height(15.dp))

            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                listOf("Canciones", "Artistas", "Álbumes", "Carpetas", "Listas").forEach { item ->
                    val selected = tab == item
                    val chipColor by animateColorAsState(
                        targetValue = if (selected) accent else SurfaceDark,
                        animationSpec = tween(220), label = "tab-color"
                    )
                    Box(
                        Modifier.animateContentSize(tween(220)).clip(RoundedCornerShape(50))
                            .background(chipColor)
                            .border(1.dp, if (selected) accent else Color.White.copy(alpha = 0.05f), RoundedCornerShape(50))
                            .clickable {
                                tab = item
                                selectedGroupId = null
                                showFavorites = false
                            }
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            item,
                            color = if (selected) Color(0xFF10140D) else TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            if (selectedGroup != null) {
                Row(
                    Modifier.fillMaxWidth().padding(start = 12.dp, end = 20.dp, top = 12.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { selectedGroupId = null }) {
                        Icon(Icons.Default.ArrowBack, "Volver a $tab", tint = accent)
                    }
                    Column(Modifier.weight(1f)) {
                        Text(selectedGroup.title, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(selectedGroup.subtitle, color = TextMuted, fontSize = 11.sp)
                    }
                }
            } else {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 15.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(if (showFavorites) "TUS FAVORITOS" else when (tab) {
                            "Artistas" -> "TU COLECCIÓN DE ARTISTAS"
                            "Álbumes" -> "TUS ÁLBUMES"
                            "Carpetas" -> "TUS CARPETAS"
                            else -> "TU BIBLIOTECA"
                        }, color = TextMuted, fontSize = 9.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
                        val countText = when {
                            loading -> "Leyendo música…"
                            tab == "Canciones" -> "${filteredSongs.size} pistas"
                            tab == "Listas" -> "${playlists.size} listas"
                            else -> "${filteredGroups.size} elementos"
                        }
                        Text(countText, color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                    if (tab == "Listas") {
                        TextButton(onClick = { playlistName = ""; showCreatePlaylist = true }) {
                            Icon(Icons.Default.Add, null, tint = accent)
                            Text("Nueva", color = accent)
                        }
                    }
                    TextButton(onClick = { showFavorites = !showFavorites }) {
                        Icon(if (showFavorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = accent, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(5.dp))
                        Text(if (showFavorites) "Todo" else "Favoritos", color = accent)
                    }
                }
            }

            when {
                !hasPermission -> EmptyState(
                    title = "Permiso necesario",
                    message = "Permite el acceso al audio para mostrar tu biblioteca.",
                    action = "Conceder permiso",
                    onAction = onRequestPermission
                )
                loading -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Lime)
                }
                tab == "Listas" -> LazyColumn(
                    Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(playlists, key = { it.name }) { playlist ->
                        val playlistSongs = playlist.songIds.mapNotNull { id -> songs.firstOrNull { it.id == id } }
                        Row(Modifier.fillMaxWidth().animateContentSize(tween(220)).clip(RoundedCornerShape(17.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFF1C241C), SurfaceDark)))
                            .border(1.dp, accent.copy(alpha = 0.10f), RoundedCornerShape(17.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.QueueMusic, null, tint = accent, modifier = Modifier.size(34.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(playlist.name, color = TextMain, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${playlistSongs.size} canciones", color = TextMuted, fontSize = 11.sp)
                                if (playlistSongs.isNotEmpty()) TextButton(onClick = { onPlayPlaylist(playlistSongs); showPlayer = true }) { Text("Reproducir", color = accent) }
                            }
                            IconButton(onClick = { onDeletePlaylist(playlist.name) }) { Icon(Icons.Default.DeleteOutline, "Eliminar lista", tint = TextMuted) }
                        }
                    }
                    if (playlists.isEmpty()) item { EmptyState("Crea tu primera lista", "Organiza tus canciones en listas personales.", "Crear lista", { showCreatePlaylist = true }) }
                }
                tab != "Canciones" && selectedGroup == null && filteredGroups.isEmpty() -> EmptyState(
                    title = "No hay elementos",
                    message = "No se encontraron ${tab.lowercase(Locale.getDefault())} con ese filtro.",
                    action = "Limpiar búsqueda",
                    onAction = { query = ""; showFavorites = false }
                )
                tab == "Canciones" && filteredSongs.isEmpty() -> EmptyState(
                    title = if (songs.isEmpty()) "No hay canciones" else "Sin resultados",
                    message = if (songs.isEmpty()) "Añade archivos de música al teléfono y vuelve a intentarlo." else "Prueba otra búsqueda o cambia el filtro.",
                    action = if (songs.isEmpty()) "Actualizar" else "Limpiar búsqueda",
                    onAction = { if (songs.isEmpty()) onRequestPermission() else { query = ""; showFavorites = false } }
                )
                selectedGroup != null && filteredSongs.isEmpty() -> EmptyState(
                    title = "No hay canciones aquí",
                    message = "Prueba otra búsqueda o vuelve a la lista anterior.",
                    action = "Volver",
                    onAction = { selectedGroupId = null; query = "" }
                )
                tab != "Canciones" && selectedGroup == null -> LazyColumn(
                    Modifier.weight(1f),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    items(filteredGroups, key = { it.id }) { group ->
                        Row(
                            Modifier.fillMaxWidth().animateContentSize(tween(220)).clip(RoundedCornerShape(16.dp))
                                .background(Brush.horizontalGradient(listOf(Color(0xFF1A211A), SurfaceDark)))
                                .border(1.dp, Color.White.copy(alpha = 0.045f), RoundedCornerShape(16.dp))
                                .clickable { selectedGroupId = group.id }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AlbumArtwork(
                                song = group.coverSong,
                                modifier = Modifier.size(58.dp).clip(RoundedCornerShape(12.dp)),
                                iconSize = 25.dp
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(group.title, color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.height(4.dp))
                                Text(group.subtitle, color = TextMuted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Icon(Icons.Default.ChevronRight, null, tint = accent)
                        }
                    }
                }
                else -> LazyColumn(
                    Modifier.weight(1f),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(filteredSongs, key = { it.id }) { song ->
                        val active = song.id == currentId
                        val rowColor by animateColorAsState(
                            targetValue = if (active) accent.copy(alpha = 0.11f) else Color.Transparent,
                            animationSpec = tween(240), label = "track-row"
                        )
                        Row(
                            Modifier.fillMaxWidth().animateContentSize(tween(180)).clip(RoundedCornerShape(15.dp))
                                .background(rowColor)
                                .border(1.dp, if (active) accent.copy(alpha = 0.35f) else Color.Transparent, RoundedCornerShape(15.dp))
                                .clickable { playAndOpen(song) }
                                .padding(horizontal = 10.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AlbumArtwork(
                                song = song,
                                modifier = Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)),
                                iconSize = 23.dp
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(song.title, color = if (active) accent else TextMain, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                                Spacer(Modifier.height(3.dp))
                                Text("${song.artist} · ${song.album}", color = TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp)
                            }
                            IconButton(onClick = { playlistForSong = song }) { Icon(Icons.Default.PlaylistAdd, "Añadir a lista", tint = TextMuted, modifier = Modifier.size(20.dp)) }
                            IconButton(onClick = { onToggleFavorite(song) }) {
                                Icon(if (song.id in favorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorito", tint = if (song.id in favorites) accent else TextMuted, modifier = Modifier.size(19.dp))
                            }
                        }
                    }
                }
            }

            if (current != null) {
                MiniPlayer(
                    song = current,
                    isPlaying = isPlaying,
                    position = position,
                    duration = duration,
                    onOpen = { showPlayer = true },
                    onPrevious = onPrevious,
                    onTogglePlay = onTogglePlay,
                    onNext = onNext,
                    onSeek = onSeek,
                    accent = accent
                )
            }
            }
        }
    }

    if (showCreatePlaylist) {
        AlertDialog(
            onDismissRequest = { showCreatePlaylist = false },
            title = { Text("Nueva lista") },
            text = { OutlinedTextField(value = playlistName, onValueChange = { playlistName = it }, label = { Text("Nombre de la lista") }, singleLine = true) },
            confirmButton = { TextButton(onClick = { onCreatePlaylist(playlistName); showCreatePlaylist = false; tab = "Listas" }) { Text("Crear") } },
            dismissButton = { TextButton(onClick = { showCreatePlaylist = false }) { Text("Cancelar") } }
        )
    }
    if (playlistForSong != null) {
        AlertDialog(
            onDismissRequest = { playlistForSong = null },
            title = { Text("Añadir a una lista") },
            text = {
                if (playlists.isEmpty()) Text("Primero crea una lista desde la pestaña Listas.")
                else Column { playlists.forEach { list -> TextButton(onClick = { onAddToPlaylist(list.name, playlistForSong!!); playlistForSong = null }) { Text(list.name) } } }
            },
            confirmButton = { TextButton(onClick = { playlistForSong = null }) { Text("Cerrar") } }
        )
    }
    if (showThemeDialog) {
        AlertDialog(
            onDismissRequest = { showThemeDialog = false },
            title = { Text("Color de acento") },
            text = { Column { listOf(0xFFB7F34AL, 0xFF64D8FFL, 0xFFFF7AB6L, 0xFFB69CFFL, 0xFFFFB454L, 0xFFFFFFFFL).forEach { color ->
                TextButton(onClick = { onChangeAccent(color); showThemeDialog = false }) {
                    Box(Modifier.size(18.dp).clip(CircleShape).background(Color(color.toULong())))
                    Spacer(Modifier.width(10.dp))
                    Text(when (color) { 0xFFB7F34AL -> "Lima"; 0xFF64D8FFL -> "Azul"; 0xFFFF7AB6L -> "Rosa"; 0xFFB69CFFL -> "Violeta"; 0xFFFFB454L -> "Ámbar"; else -> "Blanco" })
                }
            } } },
            confirmButton = { TextButton(onClick = { showThemeDialog = false }) { Text("Cerrar") } }
        )
    }
}

@Composable
private fun AlbumArtwork(song: Song?, modifier: Modifier = Modifier, iconSize: Dp = 28.dp, accent: Color = Lime) {
    val artUri = remember(song?.albumId) {
        song?.albumId?.takeIf { it > 0 }?.let {
            ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), it)
        }
    }
    Box(
        modifier.background(Brush.linearGradient(listOf(accent.copy(alpha = 0.23f), Color(0xFF202820), Color(0xFF101310)))),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Default.Album, contentDescription = null, tint = accent.copy(alpha = 0.88f), modifier = Modifier.size(iconSize))
        if (artUri != null) {
            AsyncImage(
                model = artUri,
                contentDescription = "Portada de ${song?.album ?: song?.title.orEmpty()}",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
private fun LibraryHero(
    current: Song?,
    songCount: Int,
    isPlaying: Boolean,
    accent: Color,
    onOpenPlayer: () -> Unit
) {
    Row(
        Modifier.padding(horizontal = 18.dp).fillMaxWidth()
            .clip(RoundedCornerShape(23.dp))
            .background(Brush.linearGradient(listOf(accent.copy(alpha = 0.17f), Color(0xFF1B211B), Color(0xFF121512))))
            .border(1.dp, accent.copy(alpha = 0.22f), RoundedCornerShape(23.dp))
            .clickable(onClick = onOpenPlayer)
            .padding(15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(76.dp).clip(RoundedCornerShape(17.dp))
            .background(Brush.linearGradient(listOf(accent.copy(alpha = 0.22f), Color(0xFF202820))))
            .border(1.dp, accent.copy(alpha = 0.4f), RoundedCornerShape(17.dp))) {
            if (current != null) {
                AlbumArtwork(current, Modifier.fillMaxSize(), 34.dp, accent)
            } else {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.GraphicEq, null, tint = accent, modifier = Modifier.size(38.dp))
                }
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(if (current == null) "TU ESPACIO MUSICAL" else if (isPlaying) "REPRODUCIENDO AHORA" else "ÚLTIMA REPRODUCCIÓN",
                color = accent, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.2.sp)
            Spacer(Modifier.height(5.dp))
            Text(current?.title ?: "Tu música, a tu manera", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(3.dp))
            Text(current?.artist ?: "$songCount canciones en tu biblioteca", color = TextMuted, fontSize = 11.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(9.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(if (current == null) Icons.Default.LibraryMusic else Icons.Default.PlayArrow, null, tint = accent, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text(if (current == null) "EXPLORAR COLECCIÓN" else "ABRIR REPRODUCTOR", color = TextMain, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
            }
        }
        if (current != null && isPlaying) {
            Spacer(Modifier.width(5.dp))
            PlaybackBars(isPlaying = true, accent = accent)
        }
    }
}

@Composable
private fun PlaybackBars(isPlaying: Boolean, accent: Color) {
    if (!isPlaying) {
        Row(Modifier.height(24.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            repeat(3) {
                Box(Modifier.width(3.dp).height(5.dp).clip(CircleShape).background(accent.copy(alpha = 0.75f)))
            }
        }
        return
    }
    val transition = rememberInfiniteTransition(label = "playback-bars")
    val first by transition.animateFloat(0.25f, 1f, infiniteRepeatable(tween(380), RepeatMode.Reverse), label = "bar-one")
    val second by transition.animateFloat(1f, 0.3f, infiniteRepeatable(tween(510), RepeatMode.Reverse), label = "bar-two")
    val third by transition.animateFloat(0.4f, 1f, infiniteRepeatable(tween(440), RepeatMode.Reverse), label = "bar-three")
    Row(Modifier.height(24.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        listOf(first, second, third).forEach { level ->
            Box(Modifier.width(3.dp).height(if (isPlaying) (5f + 17f * level).dp else 5.dp)
                .clip(CircleShape).background(accent))
        }
    }
}

@Composable
private fun MiniPlayer(
    song: Song,
    isPlaying: Boolean,
    position: Long,
    duration: Long,
    onOpen: () -> Unit,
    onPrevious: () -> Unit,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onSeek: (Long) -> Unit,
    accent: Color = Lime
) {
    Column(Modifier.fillMaxWidth().animateContentSize(tween(200))
        .background(Brush.verticalGradient(listOf(Color(0xFF1B211B), Color(0xFF101310))))
        .border(1.dp, accent.copy(alpha = 0.17f), RoundedCornerShape(topStart = 19.dp, topEnd = 19.dp))
        .padding(horizontal = 16.dp, vertical = 9.dp)) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onOpen),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(45.dp).clip(RoundedCornerShape(11.dp)).border(1.dp, accent.copy(alpha = 0.30f), RoundedCornerShape(11.dp))) {
                AlbumArtwork(song, Modifier.fillMaxSize(), 20.dp, accent)
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(song.title, color = TextMain, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
                Text(song.artist, color = TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp)
            }
            IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, "Anterior", tint = TextMain) }
            Box(Modifier.size(42.dp).clip(CircleShape).background(accent.copy(alpha = 0.15f)).border(1.dp, accent.copy(alpha = 0.5f), CircleShape), contentAlignment = Alignment.Center) {
                IconButton(onClick = onTogglePlay) {
                    Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Reproducir o pausar", tint = accent, modifier = Modifier.size(28.dp))
                }
            }
            IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, "Siguiente", tint = TextMain) }
        }
        Slider(
            value = if (duration > 0) position.coerceAtMost(duration).toFloat() else 0f,
            onValueChange = { onSeek(it.toLong()) },
            valueRange = 0f..duration.coerceAtLeast(1L).toFloat(),
            modifier = Modifier.height(20.dp),
            colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent, inactiveTrackColor = SurfaceLight)
        )
    }
}

@Composable
private fun NowPlayingScreen(
    song: Song,
    isPlaying: Boolean,
    isFavorite: Boolean,
    position: Long,
    duration: Long,
    onBack: () -> Unit,
    onTogglePlay: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onSeek: (Long) -> Unit,
    onToggleFavorite: () -> Unit,
    lyricsText: String,
    onImportLyrics: () -> Unit,
    accent: Color,
    onAddToPlaylist: () -> Unit
) {
    var showLyrics by remember { mutableStateOf(false) }
    val coverScale by animateFloatAsState(
        targetValue = if (isPlaying) 1.018f else 1f,
        animationSpec = tween(500), label = "playing-cover-scale"
    )
    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.12f), Bg, Color(0xFF080908))) )
            .verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver a la biblioteca", tint = TextMain) }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("REPRODUCIENDO", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Text("ẞetaMusic", color = accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            IconButton(onClick = onToggleFavorite) {
                Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorito", tint = if (isFavorite) accent else TextMuted)
            }
        }

        Spacer(Modifier.height(22.dp))
        Box(
            Modifier.fillMaxWidth().heightIn(max = 330.dp).aspectRatio(1f)
                .graphicsLayer { scaleX = coverScale; scaleY = coverScale }
                .clip(RoundedCornerShape(28.dp))
                .background(Brush.linearGradient(listOf(accent.copy(alpha = 0.25f), Color(0xFF202820), Color(0xFF0D100D))))
                .border(1.dp, accent.copy(alpha = 0.45f), RoundedCornerShape(28.dp))
                .padding(5.dp)
        ) {
            AlbumArtwork(song, Modifier.fillMaxSize().clip(RoundedCornerShape(24.dp)), 72.dp, accent)
            Box(Modifier.align(Alignment.BottomEnd).padding(13.dp).clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.62f)).border(1.dp, accent.copy(alpha = 0.45f), CircleShape).padding(horizontal = 11.dp, vertical = 7.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PlaybackBars(isPlaying = isPlaying, accent = accent)
                    Spacer(Modifier.width(6.dp))
                    Text(if (isPlaying) "EN REPRODUCCIÓN" else "EN PAUSA", color = TextMain, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.6.sp)
                }
            }
        }
        Spacer(Modifier.height(25.dp))
        Text(song.title, color = TextMain, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis, letterSpacing = (-0.35).sp)
        Spacer(Modifier.height(7.dp))
        Text(song.artist, color = accent, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(song.album, color = TextMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(23.dp))

        Slider(
            value = if (duration > 0) position.coerceAtMost(duration).toFloat() else 0f,
            onValueChange = { onSeek(it.toLong()) },
            valueRange = 0f..duration.coerceAtLeast(1L).toFloat(),
            colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent, inactiveTrackColor = SurfaceLight)
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(position), color = TextMuted, fontSize = 11.sp)
            Text(formatTime(duration), color = TextMuted, fontSize = 11.sp)
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onAddToPlaylist) {
                Icon(Icons.Default.PlaylistAdd, null, tint = accent)
                Spacer(Modifier.width(5.dp))
                Text("Añadir a lista", color = accent)
            }
            TextButton(onClick = { showLyrics = !showLyrics }) {
                Icon(Icons.Default.MusicNote, null, tint = accent)
                Spacer(Modifier.width(5.dp))
                Text(if (showLyrics) "Ocultar letras" else "Letras", color = accent)
            }
            IconButton(onClick = onImportLyrics) { Icon(Icons.Default.UploadFile, "Importar letras", tint = TextMuted) }
        }
        AnimatedVisibility(
            visible = showLyrics,
            enter = fadeIn(tween(180)) + expandVertically(tween(220)),
            exit = fadeOut(tween(140)) + shrinkVertically(tween(180))
        ) {
            Column(Modifier.fillMaxWidth().animateContentSize(tween(200)).clip(RoundedCornerShape(19.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF1B221B), SurfaceDark)))
                .border(1.dp, accent.copy(alpha = 0.18f), RoundedCornerShape(19.dp)).padding(16.dp)) {
                Text("LETRAS", color = accent, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.2.sp)
                Spacer(Modifier.height(8.dp))
                if (lyricsText.isBlank()) {
                    Text("No hay letras guardadas para esta canción. Pulsa el icono de importar para abrir un archivo .lrc o .txt.", color = TextMuted, fontSize = 14.sp, lineHeight = 22.sp)
                } else {
                    val lyricLines = remember(lyricsText) { parseLyrics(lyricsText) }
                    val activeLine = lyricLines.lastOrNull { it.first <= position }
                    if (lyricLines.isNotEmpty()) {
                        Text(activeLine?.second.orEmpty(), color = accent, fontWeight = FontWeight.Bold, fontSize = 18.sp, lineHeight = 26.sp)
                        Spacer(Modifier.height(10.dp))
                        lyricLines.forEach { line ->
                            Text(line.second, color = if (line == activeLine) accent else TextMuted, fontSize = 14.sp, lineHeight = 22.sp)
                        }
                    } else {
                        Text(lyricsText, color = TextMain, fontSize = 14.sp, lineHeight = 22.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(18.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(54.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.055f))
                .clickable(onClick = onPrevious), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.SkipPrevious, "Anterior", tint = TextMain, modifier = Modifier.size(30.dp))
            }
            Box(Modifier.size(78.dp).clip(CircleShape)
                .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.78f))))
                .border(3.dp, accent.copy(alpha = 0.20f), CircleShape)
                .clickable(onClick = onTogglePlay), contentAlignment = Alignment.Center) {
                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Reproducir o pausar", tint = Color(0xFF10140D), modifier = Modifier.size(39.dp))
            }
            Box(Modifier.size(54.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.055f))
                .clickable(onClick = onNext), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.SkipNext, "Siguiente", tint = TextMain, modifier = Modifier.size(30.dp))
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.MusicNote, null, tint = TextMuted, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(7.dp))
            Text("Tu música, sin conexión", color = TextMuted, fontSize = 12.sp)
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun EmptyState(title: String, message: String, action: String, onAction: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(30.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.LibraryMusic, null, tint = Lime, modifier = Modifier.size(52.dp))
        Spacer(Modifier.height(15.dp))
        Text(title, color = TextMain, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(7.dp))
        Text(message, color = TextMuted, fontSize = 13.sp, lineHeight = 19.sp)
        Spacer(Modifier.height(15.dp))
        Button(
            onClick = onAction,
            colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Color(0xFF11150D))
        ) { Text(action, fontWeight = FontWeight.Bold) }
    }
}

private fun parseLyrics(raw: String): List<Pair<Long, String>> {
    val pattern = Regex("\\[(\\d{1,2}):(\\d{2})(?:\\.(\\d{1,3}))?]\\s*(.*)")
    return raw.lineSequence().mapNotNull { line ->
        val match = pattern.find(line) ?: return@mapNotNull null
        val minutes = match.groupValues[1].toLongOrNull() ?: 0L
        val seconds = match.groupValues[2].toLongOrNull() ?: 0L
        val fraction = match.groupValues[3].padEnd(3, '0').take(3).toLongOrNull() ?: 0L
        (minutes * 60_000L + seconds * 1_000L + fraction) to match.groupValues[4].trim()
    }.sortedBy { it.first }.toList()
}

private fun formatTime(ms: Long): String {
    val total = (ms.coerceAtLeast(0L) / 1000L).toInt()
    return String.format(Locale.US, "%d:%02d", total / 60, total % 60)
}

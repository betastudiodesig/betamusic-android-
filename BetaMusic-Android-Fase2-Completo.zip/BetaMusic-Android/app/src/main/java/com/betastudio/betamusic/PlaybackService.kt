package com.betastudio.betamusic

import android.app.PendingIntent
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class PlaybackService : MediaSessionService() {
    private var mediaSession: MediaSession? = null
    private val widgetHandler = Handler(Looper.getMainLooper())
    private val widgetProgressTick = object : Runnable {
        override fun run() {
            val activePlayer = mediaSession?.player ?: return
            if (!activePlayer.isPlaying || !WidgetUpdater.hasWidgets(this@PlaybackService)) return
            WidgetUpdater.updateAll(this@PlaybackService, activePlayer)
            widgetHandler.postDelayed(this, 2000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttributes, /* handleAudioFocus = */ true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
                WidgetUpdater.updateAll(this@PlaybackService, mediaSession?.player ?: player)
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                widgetHandler.removeCallbacks(widgetProgressTick)
                WidgetUpdater.updateAll(this@PlaybackService, mediaSession?.player ?: player)
                if (isPlaying && WidgetUpdater.hasWidgets(this@PlaybackService)) {
                    widgetHandler.postDelayed(widgetProgressTick, 2000L)
                }
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                WidgetUpdater.updateAll(this@PlaybackService, mediaSession?.player ?: player)
            }
            override fun onMediaMetadataChanged(mediaMetadata: androidx.media3.common.MediaMetadata) {
                getSharedPreferences("betamusic_widget", MODE_PRIVATE).edit()
                    .putString("title", mediaMetadata.title?.toString().orEmpty())
                    .putString("artist", mediaMetadata.artist?.toString().orEmpty()).apply()
                WidgetUpdater.updateAll(this@PlaybackService, mediaSession?.player ?: player)
            }
            override fun onPositionDiscontinuity(oldPosition: Player.PositionInfo, newPosition: Player.PositionInfo, reason: Int) {
                WidgetUpdater.updateAll(this@PlaybackService, mediaSession?.player ?: player)
            }
        })
        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(openApp)
            .build()
        WidgetUpdater.updateAll(this, player)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    // Si el usuario cierra la app desde recientes: se detiene el servicio solo si no hay nada sonando.
    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        widgetHandler.removeCallbacks(widgetProgressTick)
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        super.onDestroy()
    }
}

# ẞetaMusic Android 2.6.0 — Biblioteca dinámica y controles glass

Aplicación Android nativa construida con Kotlin, Jetpack Compose y AndroidX Media3. Esta versión amplía la navegación de la biblioteca y renueva el reproductor y el perfil sin reemplazar el motor de reproducción.

## Cambios de esta versión

- Desliza hacia la izquierda o la derecha dentro de Biblioteca para cambiar entre pestañas, con transiciones laterales suaves.
- Pestaña explícita de **Canciones**, además de Listas, Artistas, Álbumes y Descargas.
- Ajustes para mostrar u ocultar cada pestaña; se conserva al menos una visible.
- Color de acento adaptativo: intenta leer primero la carátula del álbum y actualiza el color global de la interfaz cuando cambia la canción.
- Eliminado el botón de tres puntos sobre la portada en el reproductor; la cola sigue accesible desde el acceso inferior «Cola».
- Reordenamiento de la cola con arrastre, desplazamiento visual inmediato y animación de acoplamiento al cambiar la posición.
- Orden de canciones configurable: nombre A–Z/Z–A, artista, álbum, fecha añadida (nuevas o antiguas) y duración.
- Borde animado más visible en el buscador.
- Botones de aleatorio, anterior, reproducir/pausar, siguiente y repetir con superficies circulares translúcidas, brillos y contornos claros.
- Menús contextuales renovados para ordenar la biblioteca y actuar sobre cada canción.
- Perfil reconstruido con tarjetas translúcidas, estadísticas e iconografía de estilo iOS.
- Se retiraron los contadores generales de canciones de la vista principal de canciones y de los resultados de búsqueda.

## Requisitos

- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Android SDK 35

## Compilar

Abre esta carpeta (`BetaMusic-Android`) en Android Studio y ejecuta `assembleDebug`, o sube el proyecto a GitHub y ejecuta el flujo `Compilar BetaMusic Android APK`.

## Estado de validación

Se comprobó la integridad estructural del ZIP original y se revisó la sintaxis superficial de los archivos modificados. Esta sesión no tiene Android SDK ni Gradle local, por lo que **la APK de esta versión no se ha compilado ni probado en un dispositivo**. Debe confirmarse la compilación mediante Android Studio o GitHub Actions antes de distribuirla.

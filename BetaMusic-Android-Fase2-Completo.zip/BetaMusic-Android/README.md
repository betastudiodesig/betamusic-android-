# ẞetaMusic Android 3.0.1 — mejoras One UI / navegación y Glass

Aplicación Android nativa escrita en Kotlin, Jetpack Compose y AndroidX Media3. Esta versión reorganiza la interfaz completa hacia un reproductor local de música limpio, oscuro y táctil, tomando como referencia funcional a Samsung Music y como referencia visual del reproductor del sistema algunos patrones reportados para One UI 9.

> **Importante:** ẞetaMusic no es un producto oficial de Samsung ni una copia píxel por píxel de su aplicación. Los recursos, iconos y textos propietarios de Samsung no se incluyen. El resultado es una implementación propia basada en patrones de interfaz observables y funciones documentadas. One UI 9 también modifica el reproductor del sistema/bloqueo, cuyo aspecto final depende de Android y del dispositivo; la aplicación no puede controlar cada píxel de esa interfaz del sistema.

## Funciones principales

- Lectura de música local mediante MediaStore y permiso de audio de Android.
- Biblioteca con pestañas configurables de Listas, Canciones, Álbumes, Artistas, Géneros, Compositores, Carpetas, Favoritos y Descargas; admite deslizar horizontalmente entre secciones con transición suave.
- Reproductor completo y mini reproductor, con portada, título, artista, duración, posición y controles de reproducción.
- Cola real de Media3; las canciones se pueden añadir para reproducirse a continuación y reordenar con pulsación larga, arrastre en tiempo real y animación de acoplamiento cuando el modo aleatorio está desactivado.
- Aleatorio, repetición desactivada/repetir todo/repetir una, búsqueda y favoritos.
- Crear y eliminar listas, añadir canciones a listas existentes o crear una lista desde la canción actual.
- Ordenación persistente por nombre, artista, álbum, fecha de incorporación a MediaStore o duración.
- Menús translúcidos, controles de reproducción con apariencia de cristal, campo de búsqueda animado y perfil rediseñado con tarjetas de estilo moderno.
- Doble toque en la portada para reproducir/pausar; deslizamiento horizontal para cambiar de pista con transición de portada.
- Barra de progreso con interacción táctil y representación visual tipo onda cuyo color deriva de la portada. Es una visualización estilizada, no un análisis de la amplitud real del audio.
- Color de acento configurable y paleta dinámica derivada de la carátula activa para el conjunto de la interfaz y el reproductor. El fondo desenfocado es opcional y queda desactivado por defecto para priorizar fluidez.
- Servicio Media3 y MediaSession para reproducción en segundo plano y exponer metadatos/controles a la notificación y al reproductor del sistema.
- Preferencias y listas guardadas localmente.

## Arquitectura

- `app/src/main/java/com/betastudio/betamusic/MainActivity.kt`: interfaz Compose, navegación, controles y conexión al reproductor.
- `MusicRepository.kt`: lectura de la biblioteca mediante MediaStore, incluidos género y compositor cuando están disponibles.
- `Song.kt`: modelo de canción.
- `PlaybackService.kt`: ExoPlayer, MediaSession y reproducción en segundo plano.

## Compilación

Requisitos usados por el proyecto:

- JDK 17
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Android SDK Platform 35
- Gradle 8.9

En Android Studio, abre la carpeta `BetaMusic-Android` y ejecuta `assembleDebug`. También se incluye el workflow `.github/workflows/android-apk.yml`, que compila el proyecto desde la raíz si se sube directamente el contenido de esta carpeta a un repositorio. El workflow de la carpeta externa permite compilar si se conserva la estructura del ZIP completo.

El APK de depuración, si la compilación termina correctamente, se genera en `app/build/outputs/apk/debug/app-debug.apk`.

## Validación y límites de esta entrega

Se revisaron las rutas de código modificadas, se actualizó la documentación y se comprobó la estructura del ZIP. **La compilación Android completa no se pudo ejecutar en este entorno** porque no hay Android SDK ni distribución de Gradle disponibles y no hay conectividad de red para instalarlos. No se afirma que el APK compile hasta que el workflow de GitHub Actions o Android Studio termine correctamente.

Las animaciones exactas de Samsung varían por versión y dispositivo. Para una comparación realmente píxel a píxel se necesitan capturas de la versión de Samsung Music instalada en el Galaxy objetivo, además de medir dimensiones/espaciados en el dispositivo. La interfaz del sistema en la pantalla de bloqueo y en el panel rápido la renderiza One UI; ẞetaMusic puede enviar metadatos correctos mediante MediaSession, pero no imponer el diseño completo del sistema.


## Versión 3.1.0
Interfaz de inicio renovada y widget nativo de reproducción para la pantalla de inicio. Consulta `CAMBIOS-3.1.0.md`.

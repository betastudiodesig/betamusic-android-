# ẞetaMusic Android — Fase 2

Proyecto Android nativo en Kotlin y Jetpack Compose.

## Funciones de esta fase

- Pantalla de reproducción con portada, progreso y controles principales.
- Biblioteca local de canciones, artistas, álbumes y carpetas.
- Reproducción mediante AndroidX Media3 con `MediaSessionService` para controles multimedia del sistema.
- Notificación y controles de reproducción del sistema mediante la sesión multimedia.
- Favoritos persistentes.
- Listas de reproducción locales: crear, añadir canciones, reproducir y eliminar.
- Importación manual de letras `.lrc` y `.txt`; las líneas con marcas de tiempo LRC se presentan según la posición de reproducción.
- Color de acento personalizable y persistente.
- Versión de la app: 2.2.0 (versionCode 4).

## Requisitos

- JDK 17.
- Android SDK con API 35.
- Gradle 8.9 o compatible con Android Gradle Plugin 8.7.3.

## Compilar

Desde esta carpeta de proyecto:

```bash
gradle --no-daemon assembleDebug
```

El APK de depuración se genera en `app/build/outputs/apk/debug/app-debug.apk`.

## Notas de validación

Este ZIP contiene el código fuente completo. La compilación final debe ejecutarse en GitHub Actions o en un entorno con Android SDK y JDK configurados. Después de instalarlo, comprueba los permisos de música, reproducción en segundo plano, listas, importación de letras y selección de color en un dispositivo real.

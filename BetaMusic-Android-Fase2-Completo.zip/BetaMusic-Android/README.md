# ẞetaMusic Android 2.4.0 — Interfaz inspirada en la referencia visual

Proyecto Android nativo en Kotlin, Jetpack Compose y AndroidX Media3. Esta versión rediseña la interfaz de la aplicación siguiendo la referencia visual del usuario, manteniendo el motor de audio y los datos locales del proyecto de la Fase 3.

## Requisitos
- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Android SDK 35

## Compilar el APK
Abre la carpeta `BetaMusic-Android` en Android Studio y ejecuta `assembleDebug`, o sube el proyecto a GitHub y ejecuta el flujo `Compilar BetaMusic Android APK` en Actions. El artefacto resultante se llama `BetaMusic-Android-debug`.

## Cambios de interfaz en esta versión
- Identidad visual AMOLED en negro, magenta neón y violeta; esquinas redondeadas y acentos con degradados.
- Navegación inferior de cuatro destinos: Inicio, Buscar, Biblioteca y Perfil.
- Inicio con saludo, portadas horizontales, tarjeta destacada y listas personales.
- Biblioteca con pestañas de listas, artistas, álbumes y descargas/archivos locales.
- Pantalla de reproducción rediseñada con portada prominente, fondo dinámico inspirado en el color de la carátula, progreso táctil, aleatorio, anterior, reproducir/pausar, siguiente y repetición.
- Mini reproductor compacto encima de la navegación inferior.
- Perfil con accesos a favoritos, cola, actualización de biblioteca y ajustes.
- Opción de compartir canción mediante el menú nativo de Android.

## Funciones conservadas
- Reproducción en segundo plano con Media3 y controles de notificación.
- Lectura de canciones locales, carátulas, búsqueda, favoritos y cola real.
- Crear, editar y eliminar listas personales sin borrar archivos de música.
- Ajustes de color persistentes. El acento rosa neón es el predeterminado; las demás paletas siguen disponibles.

## Validación
Se revisó la sintaxis del archivo Kotlin con el compilador local: no aparecieron errores de análisis sintáctico. No fue posible completar una compilación Android ni una prueba en dispositivo porque este entorno no dispone del Android SDK, dependencias Android ni Gradle instalados. La compilación final debe confirmarse con Android Studio o GitHub Actions.

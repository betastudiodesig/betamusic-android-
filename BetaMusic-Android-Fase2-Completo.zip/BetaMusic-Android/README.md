# ẞetaMusic Android 2.2.0 — Fase 2 (estabilización + interfaz rediseñada)

Proyecto Android nativo en Kotlin, Jetpack Compose y AndroidX Media3.

## Requisitos de compilación
- JDK 17 · Gradle 8.9 · Android Gradle Plugin 8.7.3 · Android SDK 35

## Compilar con GitHub Actions
1. Sube el contenido del ZIP a la raíz del repositorio (`.github/workflows/compilar-apk.yml` y la carpeta `BetaMusic-Android/`).
2. Pestaña **Actions** → **Compilar BetaMusic Android APK** → **Run workflow**.
3. Descarga el artefacto `BetaMusic-Android-debug` (contiene `app-debug.apk`).

## Funciones reales de esta versión
- Biblioteca (MediaStore): Canciones, Álbumes, Artistas, Carpetas, búsqueda y botón Actualizar.
- Favoritos persistentes (sección propia).
- Reproducción Media3 en segundo plano, notificación multimedia, foco de audio y pausa al desconectar auriculares.
- Cola real (la lista desde la que se toca la canción), aleatorio, repetición (off/toda/una), selección en la cola.
- Pantalla de reproducción, mini reproductor, botón Atrás del sistema coherente.

## Todavía NO implementado
Listas de reproducción, letras (LRC/TXT), ecualizador, ajustes, temas, reordenar o quitar de la cola, persistencia de la cola tras cerrar el proceso.

## Estado de verificación
No se ha podido compilar ni probar en dispositivo en el entorno de desarrollo. Ver `LEEME-FASE2.txt`.

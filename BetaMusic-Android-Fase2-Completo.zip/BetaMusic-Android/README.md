# ẞetaMusic Android 2.3.0 — Reproductor, listas y personalización

Proyecto Android nativo en Kotlin, Jetpack Compose y AndroidX Media3.

## Requisitos de compilación
- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Android SDK 35

## Compilar el APK con GitHub Actions
Este ZIP contiene el proyecto dentro de `BetaMusic-Android/` y un flujo de trabajo en la carpeta raíz `.github/workflows/compilar-apk.yml`.

1. Sube al repositorio el contenido del ZIP, conservando la carpeta `BetaMusic-Android/`.
2. Abre **Actions** y ejecuta **Compilar BetaMusic Android APK**.
3. Descarga el artefacto `BetaMusic-Android-debug`; contiene `app-debug.apk`.

También puedes abrir directamente `BetaMusic-Android/` en Android Studio y compilar `app`.

## Funciones
- Biblioteca de audio local: canciones, álbumes, artistas y carpetas.
- Reproducción en segundo plano, notificación multimedia, control de foco de audio y pausa al desconectar auriculares.
- Pantalla de reproducción renovada, fondo degradado basado en el color medio de la portada y barra de progreso personalizada con búsqueda táctil.
- Controles de aleatorio y repetición (desactivado, repetir cola y repetir canción).
- Favoritos persistentes y cola de reproducción real.
- Listas personales: crear, guardar, reproducir, añadir y quitar canciones, y eliminar listas sin borrar los archivos originales.
- Ajustes de color con siete acentos; la selección se aplica a la interfaz y se conserva al volver a abrir la aplicación.
- Mini reproductor, búsqueda y navegación inferior.

## Estado de validación
Se revisó la estructura del proyecto y la sintaxis del archivo Kotlin. Este entorno no dispone de Android SDK/Gradle ni acceso a los repositorios de dependencias, por lo que **no se pudo ejecutar una compilación Android real ni una prueba en dispositivo**. Usa GitHub Actions o Android Studio para confirmar la compilación final.

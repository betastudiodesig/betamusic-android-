# ẞetaMusic Android 2.5.0 — Personalización y animaciones

Proyecto Android nativo en Kotlin, Jetpack Compose y AndroidX Media3. Esta versión rediseña la interfaz de la aplicación siguiendo la referencia visual del usuario, manteniendo el motor de audio y los datos locales del proyecto de la Fase 3.

## Requisitos
- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Android SDK 35

## Compilar el APK
Abre la carpeta `BetaMusic-Android` en Android Studio y ejecuta `assembleDebug`, o sube el proyecto a GitHub y ejecuta el flujo `Compilar BetaMusic Android APK` en Actions. El artefacto resultante se llama `BetaMusic-Android-debug`.

## Cambios de interfaz en esta versión
- Identidad visual AMOLED en negro, magenta neón y violeta; esquinas redondeadas y acentos con degradados.
- Navegación inferior de cuatro destinos: Inicio, Songs, Biblioteca y Perfil.
- Inicio sin saludo introductorio, portadas horizontales, listas personales y mezcla «Hecho para ti» que prioriza canciones favoritas y artistas/álbumes relacionados. Si aún no hay favoritos, la tarjeta invita a marcar canciones con ♥.
- Biblioteca con pestañas de listas, artistas, álbumes y descargas/archivos locales.
- Pantalla de reproducción rediseñada con portada prominente, fondo dinámico inspirado en el color de la carátula, progreso táctil, aleatorio, anterior, reproducir/pausar, siguiente y repetición.
- Mini reproductor compacto encima de la navegación inferior.
- Perfil con accesos a favoritos, cola, actualización de biblioteca y ajustes.
- Opción de compartir canción mediante el menú nativo de Android.
- Transición suave de fundido entre secciones, buscador compacto con borde neón animado opcional y controles del reproductor que pueden heredar el color dominante de la portada.
- Fondo de portada ampliado y desenfocado opcional en el reproductor, configurable desde Perfil → Ajustes.

## Funciones conservadas
- Reproducción en segundo plano con Media3 y controles de notificación.
- Lectura de canciones locales, carátulas, búsqueda, favoritos y cola real.
- Crear, editar y eliminar listas personales sin borrar archivos de música.
- Ajustes persistentes de color, animación neón del buscador, color dominante de portada en los controles del reproductor y fondo desenfocado opcional. Cada efecto puede activarse o desactivarse por separado.

## Validación
Se revisó la sintaxis del archivo Kotlin con el compilador local: no aparecieron errores de análisis sintáctico. El compilador de Kotlin no reportó errores de sintaxis, pero no pudo hacer una compilación tipada completa al faltar las dependencias Android/Compose en el classpath. No fue posible completar una compilación Android ni una prueba en dispositivo porque este entorno no dispone del Android SDK ni Gradle instalados. La compilación final debe confirmarse con Android Studio o GitHub Actions.

## Versión 2.6.0 — mejoras de experiencia
- Buscador más redondeado, con un brillo neón suave y sin borde giratorio.
- Icono musical en la pestaña Songs.
- Acciones del reproductor reducidas a Favorito, Añadir y Cola, con estilo más compacto; se eliminó Compartir.
- El botón Añadir permite seleccionar una playlist existente o crear una nueva que incluye automáticamente la canción actual.
- En la portada: doble toque para reproducir/pausar y deslizamiento horizontal para cambiar de canción con transición lateral.
- Apertura/cierre del reproductor con transición de deslizamiento y fundido.
- El perfil agrupa estos ajustes bajo Configuración y la entrada se llama Apariencia.

# ẞetaMusic Android 3.0.4 — Reproductor Liquid Glass y letras integradas

Cambios sobre la base 3.0.3 con la corrección de Experimental Material 3:

- Controles del reproductor rediseñados según la referencia: controles laterales minimalistas y botón central Play/Pause translúcido, con brillo, contorno y animación entre iconos.
- Barra de progreso de línea continua con degradado menta/amarillo, tiempos legibles y mando de aspecto translúcido.
- Distribución vertical del reproductor ajustada para dejar la tarjeta/asa de la cola anclada en la parte inferior, separada de los controles. La carátula se adapta a la altura disponible.
- Al tocar una vez la carátula se siguen mostrando las letras; ahora se leen las letras incrustadas en etiquetas ID3v2 de la propia canción (USLT/ULT y SYLT/SLT), incluidas letras sincronizadas. Esta vista no busca letras en Internet ni lee archivos .lrc/.txt externos.
- La etiqueta de versión pasa a 3.0.4 (versionCode 13).

Limitaciones de letras integradas: el lector implementado cubre ID3v2 (habitual en MP3). Las letras almacenadas en formatos de etiquetas distintos, como ciertos FLAC/Vorbis o MP4/M4A, pueden no ser detectadas todavía. Los frames ID3 cifrados o comprimidos no se interpretan.

Verificación realizada: integridad del ZIP original, revisión estática del código y prueba aislada del parser de tags ID3 con ejemplos sintéticos. No se ejecutó una compilación Android completa ni pruebas en dispositivo porque este entorno no dispone de Android SDK/Gradle.

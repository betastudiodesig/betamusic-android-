# ẞetaMusic Android 3.1.0 — interfaz renovada y widget

## Cambios
- Inicio reorganizado con saludo, encabezado, filtros All / New Release / Trending / Top Songs y tarjeta destacada con acento lavanda.
- Barra inferior flotante translúcida con Inicio, Mi música, Listas y Espacio; el cuarto acceso abre Configuración.
- Reproductor con portada circular y escala algo más contenida para dejar más aire vertical, manteniendo las acciones de reproducción y el gesto de deslizar.
- Widget nativo de pantalla de inicio con portada, título, artista, progreso y botones anterior / reproducir-pausar / siguiente. Los controles usan la sesión Media3 del servicio.
- Actualización periódica del progreso del widget cada 2 segundos solo cuando hay un widget colocado y la música está sonando.

## Importante
- El diseño está inspirado en las referencias visuales proporcionadas; no es una copia píxel por píxel.
- No se pudo ejecutar una compilación Gradle/Android SDK en el entorno de edición. Debe ejecutarse GitHub Actions antes de instalar el APK.

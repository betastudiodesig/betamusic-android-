# ẞetaMusic Android 3.0.2 — correcciones de estabilidad

Base de trabajo: `BetaMusic-Android-3.0.0-OneUI9.zip`. Esta versión conserva los cambios de interfaz de la 3.0.1 y añade protecciones de estabilidad.

## Correcciones incluidas
- Protegida la carga de carátulas contra excepciones lanzadas por proveedores MediaStore específicos del fabricante. La carga de una portada fallida ahora cae a la carátula de reserva en lugar de dejar escapar la excepción desde una corrutina de un elemento visible.
- Comprobación de bitmaps nulos/reciclados antes de almacenarlos o devolverlos.
- Decodificación de portadas con captura de errores y límite defensivo del factor de muestreo.
- Gesto horizontal escuchado en toda el área de Biblioteca, no solamente dentro del contenido animado; umbral reducido para que el cambio de pestaña sea más fácil de activar.
- Versión Android actualizada a 3.0.2 (versionCode 11).

## Auditoría ejecutada
- Integridad del ZIP de entrada y de salida.
- Revisión estática de la carga de carátulas, estados de Compose, pestañas, ordenación y cola.
- Revisión de manifiesto y archivos Gradle.
- Verificación de que la estructura del proyecto y las fuentes principales permanecen dentro del ZIP.

## Limitaciones conocidas de esta revisión
Este entorno no tiene Android SDK ni Gradle instalados y no se ejecutó una compilación Kotlin/Android ni pruebas instrumentadas en un dispositivo. Por tanto, no se afirma que todos los fallos estén descartados. Si la app aún se cierra, hace falta el registro de bloqueo (Logcat) para identificar la causa exacta en el teléfono.
